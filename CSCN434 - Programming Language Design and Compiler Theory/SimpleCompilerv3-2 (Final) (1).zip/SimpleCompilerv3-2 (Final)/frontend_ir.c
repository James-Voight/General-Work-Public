#include "stdio.h"
#include "frontend_parsetree.c"
#include <string.h>
#include "symboltable.h"

int funcCodeSymbolIndex = 0;
int ssaIndex = 1;


void returnValue(FILE *prog) {
    fseek(prog, 0, SEEK_END); // go to the end of the file
    fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4 ;loading return value \n", ssaIndex, ssaIndex-1);
    fprintf(prog, "    ret i32 %%%d\n", ssaIndex); // return value
    fprintf(prog, "\n}"); //this is the end parentheses from the main function
}

void funcCode(FILE *prog, ParseTree *parseTree, struct SymbolTable * symbolTable) {

    if (parseTree->type == FUNC) {
        printf("frontend_ir.c funcValue: %s\n", parseTree->string);

        for(int x = 0; x < symbolTable->totalEntries; ++x)
        {
            if(!strcmp(symbolTable[x].symbolName, parseTree->string))
            {
                printf("frontend_ir.c found variable in symbol table: %d\n", x);
                fseek(prog, 0, SEEK_SET); //reset to beginning of file.
                fprintf(prog, "define i32 @%s() {\n", symbolTable[x].symbolName);  // **** Need to remove the "Final" for assignment #2
            }
        }

    } 
    
    else if (parseTree->type == INT) {
        printf("frontend_ir.c constantValue: %d\n", parseTree->constantValue);
        fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
        fprintf(prog, "    store i32 %d, i32* %%%d, align 4\n\n", parseTree->constantValue, ssaIndex);
        ssaIndex++;

    }  
    else if (parseTree->type == STRING) {
        printf("frontend_ir.c stringValue: %s\n", parseTree->string);
        for(int x = 0; x < symbolTable->totalEntries; ++x)
        {
            if(!strcmp(symbolTable[x].symbolName, parseTree->string))
            {
                // TO DO
                fprintf(prog, "    %%\"%d.reload.%d\" = load i32, i32* %%%d, align 4\n\n", ssaIndex, symbolTable[x].symbolLocation, symbolTable[x].symbolLocation);

                fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);

                fprintf(prog, "    store i32 %%\"%d.reload.%d\", i32* %%%d, align 4\n\n", ssaIndex, symbolTable[x].symbolLocation, ssaIndex);

                ssaIndex++;
                break;
            }
        }

    }  
    else if (parseTree->type == BINOP) {
        BinOpExpr *binOpExpr = parseTree->binExpr;

        if (binOpExpr->BinOpType == ADDITION) {

            // TODO
            funcCode(prog, binOpExpr->rOperand, symbolTable);
            funcCode(prog, binOpExpr->lOperand, symbolTable);

            fprintf(prog, "    ; loading values for binary operation\n\n");

            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 1);
            ssaIndex++;
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 3);
            ssaIndex++;

            // add
            fprintf(prog, "    %%%d = add i32 %%%d, %%%d\n", ssaIndex, ssaIndex - 2, ssaIndex - 1);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; storing the answer\n\n", ssaIndex - 1, ssaIndex);
            ssaIndex++;
        }
        else if (binOpExpr->BinOpType == SUBTRACTION) {
            
            // TO DO
            funcCode(prog, binOpExpr->rOperand, symbolTable);
            funcCode(prog, binOpExpr->lOperand, symbolTable);

            fprintf(prog, "    ; loading values for binary operation\n\n");

            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 1);
            ssaIndex++;
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 3);
            ssaIndex++;

            // subtract
            fprintf(prog, "    %%%d = sub i32 %%%d, %%%d\n", ssaIndex, ssaIndex - 1, ssaIndex - 2);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; storing the answer\n\n", ssaIndex - 1, ssaIndex);
            ssaIndex++;
        }
        else if (binOpExpr->BinOpType == MULTIPLICATION) {
            
            // TO DO
            funcCode(prog, binOpExpr->rOperand, symbolTable);
            funcCode(prog, binOpExpr->lOperand, symbolTable);

            fprintf(prog, "    ; loading values for binary operation\n\n");

            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 1);
            ssaIndex++;
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 3);
            ssaIndex++;

            // multiply
            fprintf(prog, "    %%%d = mul i32 %%%d, %%%d\n", ssaIndex, ssaIndex - 2, ssaIndex - 1);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; storing the answer\n\n", ssaIndex - 1, ssaIndex);
            ssaIndex++;
        }

    } else if (parseTree->type == UNOP) {
        UnOpExpr *unOpExpr = parseTree->unExpr;

        if (unOpExpr->UnOpType == LOGICALNEGATION) {
            
            // TO DO

            // ssaIndex     = operand value
            // ssaIndex+1   = compare eq 0 (i1)
            // ssaIndex+2   = convert i1 to i32 (0 or 1)
            // ssaIndex+3   = result

            funcCode(prog, unOpExpr->rOperand, symbolTable);

            fprintf(prog, "    ; loading value for unary operation\n\n");
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex-1);
            ssaIndex++;

            fprintf(prog, "    %%%d = icmp eq i32 %%%d, 0\n\n", ssaIndex, ssaIndex-1);
            ssaIndex++;

            fprintf(prog, "    %%%d = zext i1 %%%d to i32\n\n", ssaIndex, ssaIndex-1);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; storing the answer\n\n", ssaIndex-1, ssaIndex);
            ssaIndex++;
        }
        else if (unOpExpr->UnOpType == DECLASSIGN) {
            
            // TO DO
            funcCode(prog, unOpExpr->rOperand, symbolTable);

            /*
            * ssaIndex     = load value
            * ssaIndex+1   = variable slot   (alloca i32)
            * store ssaIndex -> ssaIndex+1
            */

            fprintf(prog, "    ; declassign load\n\n");
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex-1);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);

            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; init var\n\n", ssaIndex-1, ssaIndex);

            // binding
            symbolTable[funcCodeSymbolIndex].symbolLocation = ssaIndex;
            symbolTable[funcCodeSymbolIndex].size = 4;  // i32 = 4 bytes
            funcCodeSymbolIndex++;                      // go to the next symbol
            ssaIndex++;
        
        }

        else if (unOpExpr->UnOpType == STORETOSTACK) {
            // Assignment to an existing variable, variable name lives in parseTree->string
            int idx = -1;
            for (int x = 0; x < symbolTable->totalEntries; ++x) {
                if (!strcmp(symbolTable[x].symbolName, parseTree->string)) { idx = x; break; }
            }

            if (idx >= 0) {
                // Load it, then store
                fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex-1);
                ssaIndex++;
                fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4\n\n", ssaIndex-1, symbolTable[idx].symbolLocation);
            } else {
                fprintf(stderr, "STORETOSTACK: unknown identifier %s\n", parseTree->string);
            }

        }

        else if (unOpExpr->UnOpType == RET) {
            ParseTree *val = unOpExpr->rOperand;

            if (val->type == INT) {
                // return <constant>;
                fprintf(prog, "    ret i32 %d\n", val->constantValue);
            } else {
                // For STRING or any expression:
                // funcCode(...) will emit IR that ends with a fresh alloca slot at %%(ssaIndex-1).
                funcCode(prog, val, symbolTable);
                int valPtr = ssaIndex - 1;                 // i32* where the value lives
                fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n", ssaIndex, valPtr);
                fprintf(prog, "    ret i32 %%%d\n", ssaIndex);
                ssaIndex++;
            }

            fprintf(prog, "}\n");  // close function
            return;
        }



    }
}