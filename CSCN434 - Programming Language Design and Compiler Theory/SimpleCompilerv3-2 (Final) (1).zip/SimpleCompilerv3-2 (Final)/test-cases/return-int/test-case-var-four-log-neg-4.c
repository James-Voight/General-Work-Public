int myFunction() 
{
   int x = 30;
   int y = 0;
   int z = 10;
   int a = 0;

   return !a;
}