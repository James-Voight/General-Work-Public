int myFunction() 
{
   return !100;
}