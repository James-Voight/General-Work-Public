int myFunction() 
{
   int x = 30;
   int y = 20;
   int z = 10;

   return x + z;
}