int myFunction() 
{
   int x = 10;

   return 5 * x;
}