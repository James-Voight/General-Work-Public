int myFunction() 
{
   return 50 - 2;
}