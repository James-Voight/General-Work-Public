#!/bin/bash

set -e

for FILE in ./test-cases/return-int/test-case-*.c
do
    make prog=$FILE type=return-int
    read -n 1 -s -r -p "Press any key to continue"
    make clean
    tests_performed=$((tests_performed+1))
done

echo
echo
echo " Tests performed: $tests_performed "
echo " ***** ALL TESTS PASSED!! ***** "
echo
echo