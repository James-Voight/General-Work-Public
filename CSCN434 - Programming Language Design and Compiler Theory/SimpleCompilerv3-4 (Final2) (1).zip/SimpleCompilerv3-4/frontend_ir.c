#include "stdio.h"
#include "frontend_parsetree.c"
#include <string.h>
#include "symboltable.h"

int ssaIndex = 1;
int hasFunctionParam = 0;
char functionParamName[64] = {0};
int loopCounter = 0;


void returnValue(FILE *prog) {
    fseek(prog, 0, SEEK_END); // go to the end of the file
    fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4 ;loading return value \n", ssaIndex, ssaIndex-1);
    fprintf(prog, "    ret i32 %%%d\n", ssaIndex); // return value
    fprintf(prog, "\n}"); //this is the end parentheses from the main function
}

void funcCode(FILE *prog, ParseTree *parseTree, struct SymbolTable * symbolTable) {

    if (parseTree->type == FUNC) {
        printf("frontend_ir.c funcValue: %s\n", parseTree->string);

        for(int x = 0; x < symbolTable->totalEntries; ++x)
        {
            if(!strcmp(symbolTable[x].symbolName, parseTree->string))
            {
                printf("frontend_ir.c found variable in symbol table: %d\n", x);
                fseek(prog, 0, SEEK_SET); //reset to beginning of file.
                if (hasFunctionParam) {
                    fprintf(prog, "define i32 @%sFinal(i32 %%%s) {\n", symbolTable[x].symbolName, functionParamName);
                } else {
                    fprintf(prog, "define i32 @%sFinal() {\n", symbolTable[x].symbolName);
                }
            }
        }

        hasFunctionParam = 0; // function header emitted; reset flag

    } 
    
    else if (parseTree->type == INT) {
        printf("frontend_ir.c constantValue: %d\n", parseTree->constantValue);
        fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
        fprintf(prog, "    store i32 %d, i32* %%%d, align 4\n\n", parseTree->constantValue, ssaIndex);
        ssaIndex++;

    }  
    else if (parseTree->type == STRING) {
        printf("frontend_ir.c stringValue: %s\n", parseTree->string);
        for(int x = 0; x < symbolTable->totalEntries; ++x)
        {
            if(!strcmp(symbolTable[x].symbolName, parseTree->string))
            {
                // TO DO
                fprintf(prog, "    %%\"%d.reload.%d\" = load i32, i32* %%%d, align 4\n\n", ssaIndex, symbolTable[x].symbolLocation, symbolTable[x].symbolLocation);

                fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);

                fprintf(prog, "    store i32 %%\"%d.reload.%d\", i32* %%%d, align 4\n\n", ssaIndex, symbolTable[x].symbolLocation, ssaIndex);

                ssaIndex++;
                break;
            }
        }

    }  
    else if (parseTree->type == BLOCK) {
        // Walk each statement in order and emit code for it.
        BlockExpr *block = parseTree->blockExpr;
        BlockStmtList *cur = block->head;
        while (cur) {
            funcCode(prog, cur->stmt, symbolTable);
            cur = cur->next;
        }
    }  
    else if (parseTree->type == DOWHILE) {
        DoWhileExpr *dw = parseTree->doWhileExpr;

        int loopId = loopCounter++;

        fprintf(prog, "    br label %%do.body.%d\n\n", loopId);
        fprintf(prog, "do.body.%d:\n", loopId);

        // Emit loop body
        funcCode(prog, dw->body, symbolTable);

        fprintf(prog, "    br label %%do.cond.%d\n\n", loopId);
        fprintf(prog, "do.cond.%d:\n", loopId);

        // Emit condition expression
        funcCode(prog, dw->cond, symbolTable);

        // Load the condition result and compare against zero
        fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n", ssaIndex, ssaIndex - 1);
        int condVal = ssaIndex++;

        fprintf(prog, "    %%%d = icmp ne i32 %%%d, 0\n", ssaIndex, condVal);
        int condBool = ssaIndex++;

        fprintf(prog, "    br i1 %%%d, label %%do.body.%d, label %%do.end.%d\n\n", condBool, loopId, loopId);
        fprintf(prog, "do.end.%d:\n", loopId);
    }

    else if (parseTree->type == BINOP) {
        BinOpExpr *binOpExpr = parseTree->binExpr;

        if (binOpExpr->BinOpType == ADDITION) {

            // TODO
            funcCode(prog, binOpExpr->rOperand, symbolTable);
            funcCode(prog, binOpExpr->lOperand, symbolTable);

            fprintf(prog, "    ; loading values for binary operation\n\n");

            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 1);
            ssaIndex++;
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 3);
            ssaIndex++;

            // add
            fprintf(prog, "    %%%d = add i32 %%%d, %%%d\n", ssaIndex, ssaIndex - 2, ssaIndex - 1);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; storing the answer\n\n", ssaIndex - 1, ssaIndex);
            ssaIndex++;
        }
        else if (binOpExpr->BinOpType == LESS_THAN ||
                 binOpExpr->BinOpType == GREATER_THAN ||
                 binOpExpr->BinOpType == LESS_EQUAL ||
                 binOpExpr->BinOpType == GREATER_EQUAL ||
                 binOpExpr->BinOpType == EQUAL_TO ||
                 binOpExpr->BinOpType == NOT_EQUAL_TO) {

            funcCode(prog, binOpExpr->rOperand, symbolTable);
            funcCode(prog, binOpExpr->lOperand, symbolTable);

            fprintf(prog, "    ; loading values for comparison operation\n\n");

            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 1);
            ssaIndex++;
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 3);
            ssaIndex++;

            const char *predicate = NULL;
            switch (binOpExpr->BinOpType) {
                case LESS_THAN:      predicate = "slt"; break;
                case GREATER_THAN:   predicate = "sgt"; break;
                case LESS_EQUAL:     predicate = "sle"; break;
                case GREATER_EQUAL:  predicate = "sge"; break;
                case EQUAL_TO:       predicate = "eq";  break;
                case NOT_EQUAL_TO:   predicate = "ne";  break;
                default:             predicate = "eq";  break;
            }

            fprintf(prog, "    %%%d = icmp %s i32 %%%d, %%%d\n", ssaIndex, predicate, ssaIndex - 2, ssaIndex - 1);
            ssaIndex++;

            fprintf(prog, "    %%%d = zext i1 %%%d to i32\n", ssaIndex, ssaIndex - 1);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; storing comparison result\n\n", ssaIndex - 1, ssaIndex);
            ssaIndex++;
        }
        else if (binOpExpr->BinOpType == SUBTRACTION) {
            
            // TO DO
            funcCode(prog, binOpExpr->rOperand, symbolTable);
            funcCode(prog, binOpExpr->lOperand, symbolTable);

            fprintf(prog, "    ; loading values for binary operation\n\n");

            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 1);
            ssaIndex++;
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 3);
            ssaIndex++;

            // subtract
            fprintf(prog, "    %%%d = sub i32 %%%d, %%%d\n", ssaIndex, ssaIndex - 1, ssaIndex - 2);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; storing the answer\n\n", ssaIndex - 1, ssaIndex);
            ssaIndex++;
        }
        else if (binOpExpr->BinOpType == MULTIPLICATION) {
            
            // TO DO
            funcCode(prog, binOpExpr->rOperand, symbolTable);
            funcCode(prog, binOpExpr->lOperand, symbolTable);

            fprintf(prog, "    ; loading values for binary operation\n\n");

            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 1);
            ssaIndex++;
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 3);
            ssaIndex++;

            // multiply
            fprintf(prog, "    %%%d = mul i32 %%%d, %%%d\n", ssaIndex, ssaIndex - 2, ssaIndex - 1);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; storing the answer\n\n", ssaIndex - 1, ssaIndex);
            ssaIndex++;
        }

    } else if (parseTree->type == UNOP) {
        UnOpExpr *unOpExpr = parseTree->unExpr;

        if (unOpExpr->UnOpType == LOGICALNEGATION) {
            
            // TO DO

            // ssaIndex     = operand value
            // ssaIndex+1   = compare eq 0 (i1)
            // ssaIndex+2   = convert i1 to i32 (0 or 1)
            // ssaIndex+3   = result

            funcCode(prog, unOpExpr->rOperand, symbolTable);

            fprintf(prog, "    ; loading value for unary operation\n\n");
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex-1);
            ssaIndex++;

            fprintf(prog, "    %%%d = icmp eq i32 %%%d, 0\n\n", ssaIndex, ssaIndex-1);
            ssaIndex++;

            fprintf(prog, "    %%%d = zext i1 %%%d to i32\n\n", ssaIndex, ssaIndex-1);
            ssaIndex++;

            fprintf(prog, "    %%%d = alloca i32, align 4\n", ssaIndex);
            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; storing the answer\n\n", ssaIndex-1, ssaIndex);
            ssaIndex++;
        }
        else if (unOpExpr->UnOpType == DECLASSIGN) {
            const char *dstName = unOpExpr->target;
            ParseTree *src = unOpExpr->rOperand;

            funcCode(prog, src, symbolTable);

            fprintf(prog, "    ; declassign load\n\n");
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, ssaIndex - 1);
            int rightVal = ssaIndex++;

            int idx = -1;
            for (int i = 0; i < symbolTable->totalEntries; ++i) {
                if (!strcmp(symbolTable[i].symbolName, dstName)) { idx = i; break; }
            }

            if (idx == -1) {
                idx = symbolTable->totalEntries++;
                strcpy(symbolTable[idx].symbolName, dstName);
            }

            int needsAlloc = 0;
            if (strcmp(symbolTable[idx].entryType, "ARG") != 0) {
                if (strcmp(symbolTable[idx].entryType, "VAR") != 0) {
                    needsAlloc = 1;
                }
                strcpy(symbolTable[idx].entryType, "VAR");
                strcpy(symbolTable[idx].symbolType, "i32");
            } else if (symbolTable[idx].symbolLocation == 0) {
                needsAlloc = 1;
            }
            symbolTable[idx].size = 4;

            if (needsAlloc || symbolTable[idx].symbolLocation == 0) {
                fprintf(prog, "    %%%d = alloca i32, align 4 ; %s\n", ssaIndex, dstName);
                symbolTable[idx].symbolLocation = ssaIndex;
                ssaIndex++;
            }

            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4 ; init %s\n\n",
                    rightVal, symbolTable[idx].symbolLocation, dstName);
        }

        else if (unOpExpr->UnOpType == DECLWITHOUTASSIGN) {
            const char *name = unOpExpr->target;  // name is stored on the node

            if (!name) {
                fprintf(stderr, "DECLWITHOUTASSIGN, missing id\n");  // debug
                return;
            }

            // Find existing or add new entry
            int idx = -1;
            for (int i = 0; i < symbolTable->totalEntries; ++i) {
                if (!strcmp(symbolTable[i].symbolName, name)) {
                    idx = i;
                    break;
                }
            }
            if (idx == -1) {
 
                idx = symbolTable->totalEntries++;
                strcpy(symbolTable[idx].entryType,  "VAR");
                strcpy(symbolTable[idx].symbolType, "i32");
                strcpy(symbolTable[idx].symbolName, name);
                symbolTable[idx].size = 4;
                symbolTable[idx].symbolLocation = 0;   // will hold pointer SSA
            }

            if (!strcmp(symbolTable[idx].entryType, "ARG")) {
                fprintf(prog, "    %%%d = alloca i32, align 4 ; %s\n", ssaIndex, name);
                fprintf(prog, "    store i32 %%%s, i32* %%%d, align 4 ; init arg %s\n\n",
                        name, ssaIndex, name);
                symbolTable[idx].symbolLocation = ssaIndex; // save pointer SSA for later use
                ssaIndex++;
            } else {
                fprintf(prog, "    %%%d = alloca i32, align 4 ; %s\n", ssaIndex, name);
                fprintf(prog, "    store i32 9999999, i32* %%%d, align 4 ; init %s\n", ssaIndex, name);
                symbolTable[idx].symbolLocation = ssaIndex; // save pointer SSA for later use
                ssaIndex++;
            }
        }



        else if (unOpExpr->UnOpType == STORETOSTACK) {
            const char *dstName = unOpExpr->target;
            ParseTree *src = unOpExpr->rOperand;

            funcCode(prog, src, symbolTable);

            int rightPtr = ssaIndex - 1;
            fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n\n", ssaIndex, rightPtr);
            int rightVal = ssaIndex++;

            int idx = -1;
            for (int i = 0; i < symbolTable->totalEntries; ++i) {
                if (!strcmp(symbolTable[i].symbolName, dstName)) {
                    idx = i;
                    break;
                }
            }

            if (idx < 0 || symbolTable[idx].symbolLocation == 0) {
                fprintf(stderr, "STORETOSTACK, unknown or undeclared id %s\n", dstName); // debug
                return;
            }

            fprintf(prog, "    store i32 %%%d, i32* %%%d, align 4\n\n",
                    rightVal, symbolTable[idx].symbolLocation);
        }

        else if (unOpExpr->UnOpType == RET) {
            ParseTree *val = unOpExpr->rOperand;

            if (val->type == INT) {
                fprintf(prog, "    ret i32 %d\n", val->constantValue);
            } else if (val->type == STRING) {
                int idx = -1;
                for (int i = 0; i < symbolTable->totalEntries; ++i) {
                    if (!strcmp(symbolTable[i].symbolName, val->string)) {
                        idx = i;
                        break;
                    }
                }
                if (idx < 0 || symbolTable[idx].symbolLocation == 0) {
                    fprintf(stderr, "RET, unknown id %s\n", val->string);  // debug
                } else {
                    fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n", ssaIndex, symbolTable[idx].symbolLocation);
                    fprintf(prog, "    ret i32 %%%d\n", ssaIndex);
                    ssaIndex++;
                }
            } 
            else {
                // expression: emit it, then load from temp and return
                funcCode(prog, val, symbolTable);
                int valPtr = ssaIndex - 1; // temp
                fprintf(prog, "    %%%d = load i32, i32* %%%d, align 4\n", ssaIndex, valPtr);
                fprintf(prog, "    ret i32 %%%d\n", ssaIndex);
                ssaIndex++;
            }

            fprintf(prog, "}\n");
            return;
        }



    }
}
