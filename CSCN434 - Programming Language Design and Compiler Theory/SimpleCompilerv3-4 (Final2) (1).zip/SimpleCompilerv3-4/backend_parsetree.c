#include <stdlib.h>
#include <string.h>

#ifndef COMPILER_PARSETREE
#define COMPILER_PARSETREE

typedef enum { FUNC, INT, STRING, BINOP, UNOP, RELOAD, LABEL, BRANCH } ParseTreeType;
typedef enum { ADDITION, SUBTRACTION, MULTIPLICATION, LESS_THAN, GREATER_THAN, LESS_EQUAL, GREATER_EQUAL, EQUAL_TO, NOT_EQUAL_TO } ParseTreeBinOp;
typedef enum { LOGICALNEGATION, DECLASSIGN, RET, STORETOSTACK, DECLWITHOUTASSIGN } ParseTreeUnOp;

typedef struct parseTree ParseTree;

typedef struct BinOpExpr {
    ParseTreeBinOp BinOpType;
    ParseTree *lOperand;
    ParseTree *rOperand;
} BinOpExpr;

typedef struct UnOpExpr {
    ParseTreeUnOp UnOpType;
    ParseTree *rOperand;
} UnOpExpr;

typedef struct BranchExpr {
    int isConditional;
    char *condition;
    char *trueLabel;
    char *falseLabel;
} BranchExpr;

struct parseTree {
    ParseTreeType type;
    union {
        int constantValue;
        char *string;
        BinOpExpr *binExpr;
        UnOpExpr *unExpr;
        BranchExpr *branchExpr;
    };
};


ParseTree *funcType(char *string) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    parseTree->type = FUNC;
    parseTree->string = string;
    return parseTree;
}


ParseTree *intType(int constantValue) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    parseTree->type = INT;
    parseTree->constantValue = constantValue;
    return parseTree;
}

ParseTree *stringType(char *string) {
    
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(parseTree));
    parseTree->type = STRING;
    parseTree->string = string;
    return parseTree;
}

ParseTree *reload(char *string) {
    
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(parseTree));
    parseTree->type = RELOAD;
    parseTree->string = string; /* no leading %, matches lexer */
    return parseTree;
}

ParseTree *add(ParseTree *lOperand, ParseTree *rOperand) {
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = ADDITION;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *subtract(ParseTree *lOperand, ParseTree *rOperand) {
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = SUBTRACTION;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *multiply(ParseTree *lOperand, ParseTree *rOperand) {
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = MULTIPLICATION;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *lessThan(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = LESS_THAN;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *greaterThan(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = GREATER_THAN;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *lessEq(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = LESS_EQUAL;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *greaterEq(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = GREATER_EQUAL;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *equalTo(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = EQUAL_TO;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *notEqualTo(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = NOT_EQUAL_TO;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *logicalNegation(ParseTree *rint) {
    
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(parseTree));
    UnOpExpr *unOpExpr = malloc(sizeof(UnOpExpr));
    unOpExpr->UnOpType = LOGICALNEGATION;
    unOpExpr->rOperand = rint;
    parseTree->type = UNOP;
    parseTree->unExpr = unOpExpr;
    return parseTree;
}

ParseTree *declarationWithAssign(ParseTree *rint) {
    
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(parseTree));
    UnOpExpr *unOpExpr = malloc(sizeof(UnOpExpr));
    unOpExpr->UnOpType = DECLASSIGN;
    unOpExpr->rOperand = rint;
    parseTree->type = UNOP;
    parseTree->unExpr = unOpExpr;
    return parseTree;
}

ParseTree *storeToStack(ParseTree *rint) {
    
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(parseTree));
    UnOpExpr *unOpExpr = malloc(sizeof(UnOpExpr));
    unOpExpr->UnOpType = STORETOSTACK;
    unOpExpr->rOperand = rint;
    parseTree->type = UNOP;
    parseTree->unExpr = unOpExpr;
    return parseTree;
}

ParseTree *ret(ParseTree *rint) {
    
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(parseTree));
    UnOpExpr *unOpExpr = malloc(sizeof(UnOpExpr));
    unOpExpr->UnOpType = RET;
    unOpExpr->rOperand = rint;
    parseTree->type = UNOP;
    parseTree->unExpr = unOpExpr;
    return parseTree;
}

ParseTree *labelStmt(char *name) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    parseTree->type = LABEL;
    parseTree->string = name;
    return parseTree;
}

ParseTree *branchUncond(char *target) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BranchExpr *branchExpr = malloc(sizeof(BranchExpr));
    branchExpr->isConditional = 0;
    branchExpr->condition = NULL;
    branchExpr->trueLabel = target;
    branchExpr->falseLabel = NULL;
    parseTree->type = BRANCH;
    parseTree->branchExpr = branchExpr;
    return parseTree;
}

ParseTree *branchCond(char *condition, char *trueLabel, char *falseLabel) {
    ParseTree *parseTree = malloc(sizeof(parseTree));
    BranchExpr *branchExpr = malloc(sizeof(BranchExpr));
    branchExpr->isConditional = 1;
    branchExpr->condition = condition;
    branchExpr->trueLabel = trueLabel;
    branchExpr->falseLabel = falseLabel;
    parseTree->type = BRANCH;
    parseTree->branchExpr = branchExpr;
    return parseTree;
}


#endif
