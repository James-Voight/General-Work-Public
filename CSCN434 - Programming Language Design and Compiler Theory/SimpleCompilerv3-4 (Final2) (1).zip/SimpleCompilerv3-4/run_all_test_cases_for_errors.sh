#!/bin/bash
# Progress Bar code modified from: https://www.baeldung.com/linux/command-line-progress-bar

bar_size=40
bar_char_done="#"
bar_char_todo="-"
bar_percentage_scale=2

function show_progress {
    current="$1"
    total="$2"

    # calculate the progress in percentage 
    percent=$(bc <<< "scale=$bar_percentage_scale; 100 * $current / $total" )
    # The number of done and todo characters
    done=$(bc <<< "scale=0; $bar_size * $percent / 100" )
    todo=$(bc <<< "scale=0; $bar_size - $done" )

    # build the done and todo sub-bars
    done_sub_bar=$(printf "%${done}s" | tr " " "${bar_char_done}")
    todo_sub_bar=$(printf "%${todo}s" | tr " " "${bar_char_todo}")

    # output the bar
    echo -ne "\rProgress : [${done_sub_bar}${todo_sub_bar}] ${percent}%"

    if [ $total -eq $current ]; then
        echo -e "\nDONE"
    fi
}

# BEGIN DMO SCRIPT 
set -e

return_int_count=$(find "./test-cases/return-int/" -type f | wc -l)
return_int_count=$((return_int_count-2))
pass_int_count=$(find "./test-cases/pass-int/" -type f | wc -l)
pass_int_count=$((pass_int_count-2))
total_test_case_count=$(find "./test-cases/" -type f | wc -l)
total_test_case_count=$((total_test_case_count-4))

for FILE in ./test-cases/return-int/test-case-*.c
do
    make prog=$FILE type=return-int &> most_recent_test_log.txt
    make clean &> /dev/null
    return_int_tests_performed=$((return_int_tests_performed+1))
    tests_performed=$((tests_performed+1))
    echo
    echo
    echo " **** RETURN INT CASE: $return_int_tests_performed of $return_int_count **** "
    echo " $FILE "
    echo " **** TEST CASE: $tests_performed of $total_test_case_count **** "
    echo
    echo
    show_progress $tests_performed $total_test_case_count
    echo
    echo

done

for FILE in ./test-cases/pass-int/test-case-*.c
do
    make prog=$FILE type=pass-int &> most_recent_test_log.txt
    make clean &> /dev/null
    pass_int_tests_performed=$((pass_int_tests_performed+1))
    tests_performed=$((tests_performed+1))
    echo
    echo
    echo " **** PASS INT CASE: $pass_int_tests_performed of $pass_int_count **** "
    echo " $FILE "
    echo " **** TEST CASE: $tests_performed of $total_test_case_count **** "
    echo
    echo
    show_progress $tests_performed $total_test_case_count
    echo
    echo

done

echo
echo
echo " Tests performed: $tests_performed "
echo " ***** ALL TESTS PASSED!! ***** "
echo
echo