int myFunction(int argA) 
{
   return 10;
}