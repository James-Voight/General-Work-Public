int myFunction(int argA) 
{
   int a;
   int x = 10;
   int y = 20;

   return x + argA;
}