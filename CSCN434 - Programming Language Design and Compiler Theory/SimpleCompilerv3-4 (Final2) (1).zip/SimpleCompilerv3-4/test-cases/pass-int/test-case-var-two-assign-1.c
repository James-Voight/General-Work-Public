int myFunction(int argA) 
{
   int x = 40;
   int y = 20;

   return argA;
}