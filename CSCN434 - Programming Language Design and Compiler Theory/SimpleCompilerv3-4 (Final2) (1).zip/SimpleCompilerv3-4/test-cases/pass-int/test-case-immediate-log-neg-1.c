int myFunction(int argA) 
{
   return !argA;
}