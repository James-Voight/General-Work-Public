int myFunction() 
{
   int a = 50;
   a = 75;
   a = 90;
   a = 100;

   return a;
}