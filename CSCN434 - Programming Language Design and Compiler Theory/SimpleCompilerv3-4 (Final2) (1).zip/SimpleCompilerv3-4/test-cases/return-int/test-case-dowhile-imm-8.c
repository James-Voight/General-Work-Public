int myFunction() 
{
   int x = 5;
   int y = 70;
   int alpha;
   int beta;
   int gamma = 200;
   
   do
   {
      x++;
      y++;
      alpha = 100;
      x++;
      y++;
      x++;
   }
   while (x < y);
   
   return alpha;
}