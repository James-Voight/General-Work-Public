int myFunction() 
{
   int a;
   int x = 10;
   int y = 20;

   return x + y;
}