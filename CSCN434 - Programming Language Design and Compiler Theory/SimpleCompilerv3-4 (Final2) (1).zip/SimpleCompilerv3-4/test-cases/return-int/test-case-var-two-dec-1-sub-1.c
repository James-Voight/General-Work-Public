int myFunction() 
{
   int a;
   int x = 30;
   int y = 20;

   return x - y;
}