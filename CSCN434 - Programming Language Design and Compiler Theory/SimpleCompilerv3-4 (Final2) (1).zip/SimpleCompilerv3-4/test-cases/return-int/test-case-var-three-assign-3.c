int myFunction() 
{
   int x;
   int y;
   int z;

   x = 10;
   y = 12;
   z = 15;

   return z;
}