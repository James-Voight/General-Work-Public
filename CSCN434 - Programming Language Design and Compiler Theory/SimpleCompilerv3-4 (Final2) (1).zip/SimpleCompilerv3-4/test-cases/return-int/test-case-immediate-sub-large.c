int myFunction() 
{
   return 10000 - 2000;
}