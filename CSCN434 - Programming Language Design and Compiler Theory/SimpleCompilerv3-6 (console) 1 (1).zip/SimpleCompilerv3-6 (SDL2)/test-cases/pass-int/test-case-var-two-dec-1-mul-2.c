int myFunction(int argA) 
{
   int a;
   int x = 30;
   int y = 20;
   a = 10;

   return argA * a;
}