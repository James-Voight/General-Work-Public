int myFunction(int alpha) 
{
   int x;
   x = 1;

   do{
      x++;

   } while (x < alpha);

   return x;
}