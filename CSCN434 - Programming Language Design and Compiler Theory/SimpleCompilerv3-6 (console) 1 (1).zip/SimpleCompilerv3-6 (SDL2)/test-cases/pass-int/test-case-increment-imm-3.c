int myFunction(int y) 
{
   int a = 50;
   int x;
   a++;
   x = 90;
   y++;
   x = 66;
   y++;

   return y;
}