int myFunction(int b) 
{
   int a = 50;
   b = 75;
   a = 90;
   b = 100;

   return b;
}