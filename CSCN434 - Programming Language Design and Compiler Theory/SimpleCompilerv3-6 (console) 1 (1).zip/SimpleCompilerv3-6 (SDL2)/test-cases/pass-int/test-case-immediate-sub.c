int myFunction(int argA) 
{
   return 50 - argA;
}