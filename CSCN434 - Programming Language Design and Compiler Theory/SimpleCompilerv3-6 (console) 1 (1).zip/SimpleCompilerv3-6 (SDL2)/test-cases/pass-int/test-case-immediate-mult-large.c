int myFunction(int argA) 
{
   return 50000 * argA;
}