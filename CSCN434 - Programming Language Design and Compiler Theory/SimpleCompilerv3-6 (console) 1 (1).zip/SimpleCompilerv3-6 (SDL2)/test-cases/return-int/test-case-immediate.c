int myFunction() 
{
   return 10;
}