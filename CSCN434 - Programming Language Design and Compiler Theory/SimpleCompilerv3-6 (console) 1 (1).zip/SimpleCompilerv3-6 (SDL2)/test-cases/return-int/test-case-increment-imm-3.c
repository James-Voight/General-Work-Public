int myFunction() 
{
   int a = 50;
   int x;
   int y;
   a = 75;
   x = 90;
   y = 100;
   x = 66;
   x++; 
   a++;
   y = 32;
   x++;

   return x;
}