int myFunction() 
{
   int x = 30;
   int y = 20;
   int z = 10;
   int a = 100;

   return x + z;
}