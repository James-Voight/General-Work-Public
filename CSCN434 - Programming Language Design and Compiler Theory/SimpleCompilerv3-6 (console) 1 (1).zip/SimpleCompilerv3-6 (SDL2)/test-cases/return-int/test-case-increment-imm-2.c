int myFunction() 
{
   int a = 50;
   a++;
   a++;
   a++;
   a++;

   return a;
}