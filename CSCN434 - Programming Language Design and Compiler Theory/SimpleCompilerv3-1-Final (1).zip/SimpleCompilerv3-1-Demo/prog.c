int myFunction() 
{
   
   int x=5;
   return x;
}