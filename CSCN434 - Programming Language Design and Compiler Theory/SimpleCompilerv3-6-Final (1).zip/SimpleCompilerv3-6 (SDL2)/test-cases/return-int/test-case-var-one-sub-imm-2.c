int myFunction() 
{
   int x = 10;

   return 15 - x;
}