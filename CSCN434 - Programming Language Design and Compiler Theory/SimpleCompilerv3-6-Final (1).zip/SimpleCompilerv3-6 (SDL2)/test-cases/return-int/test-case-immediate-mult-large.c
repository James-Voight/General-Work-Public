int myFunction() 
{
   return 50000 * 10000;
}