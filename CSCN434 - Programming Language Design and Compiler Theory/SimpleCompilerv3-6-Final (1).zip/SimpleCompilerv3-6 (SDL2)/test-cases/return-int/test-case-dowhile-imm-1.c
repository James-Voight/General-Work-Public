int myFunction() 
{
   int x = 5;
   
   do
   {
      x++;
   }
   while (x < 10);
   
   return x;
}