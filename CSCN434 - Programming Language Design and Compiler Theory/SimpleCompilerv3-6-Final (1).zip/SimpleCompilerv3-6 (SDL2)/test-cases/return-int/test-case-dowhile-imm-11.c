int myFunction() 
{
   int x;
   int alpha = 5;
   x = 1;

   do{
      x++;

   } while (x < alpha);

   return x;
}