int myFunction() 
{
   return 10 * 50;
}