int myFunction(int argA) 
{
   int x = 20;
   int y = 30;

   return y;
}