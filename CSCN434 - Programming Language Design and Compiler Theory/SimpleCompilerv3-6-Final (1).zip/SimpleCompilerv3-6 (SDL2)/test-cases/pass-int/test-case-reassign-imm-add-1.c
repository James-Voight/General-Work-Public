int myFunction(int a) 
{
   int x;
   int y;
   int alpha = 500;
   int z;

   a = 75;
   x = 90;
   y = 100;
   x = 66;
   a = 5;
   z = 20;
   y = 32;

   return y + 1;
}