int myFunction(int a) 
{
   int x;
   int y;
   a = 75;
   x = 90;
   y = 100;
   x = 66;
   y = 32;

   return a * x;
}