int myFunction(int argA) 
{
   return 0;
}