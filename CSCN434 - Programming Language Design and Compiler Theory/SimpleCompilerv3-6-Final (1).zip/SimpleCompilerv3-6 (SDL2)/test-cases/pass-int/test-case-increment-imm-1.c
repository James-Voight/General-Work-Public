int myFunction(int a) 
{
   a++;
   a++;

   return a;
}