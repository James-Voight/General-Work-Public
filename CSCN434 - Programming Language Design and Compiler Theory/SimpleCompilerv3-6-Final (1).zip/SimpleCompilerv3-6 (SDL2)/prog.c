int myFunction(int x) 
{
   x = 15;
   
   do
   {
      x = x - 1;
   }
   while (x >= 10);
   
   return x;
}