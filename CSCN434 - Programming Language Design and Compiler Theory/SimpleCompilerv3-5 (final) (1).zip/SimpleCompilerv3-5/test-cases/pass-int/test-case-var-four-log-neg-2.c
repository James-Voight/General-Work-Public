int myFunction(int argA) 
{
   int x = 30;
   int y = 0;
   int z = 10;
   int a = 100;

   return !argA;
}