int myFunction(int argA) 
{
   int a;
   int x = 10;
   int y = 20;
   a = 5;

   return a + argA;
}