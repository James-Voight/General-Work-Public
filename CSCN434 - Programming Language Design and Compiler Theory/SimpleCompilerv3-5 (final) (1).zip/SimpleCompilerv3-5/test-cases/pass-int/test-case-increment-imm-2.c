int myFunction(int b) 
{
   int a = 50;
   b = 75;
   a++;
   b = 100;
   b++;

   return b;
}