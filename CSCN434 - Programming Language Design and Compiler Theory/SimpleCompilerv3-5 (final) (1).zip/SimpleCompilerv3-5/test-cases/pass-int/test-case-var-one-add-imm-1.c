int myFunction(int argA) 
{
   int x = 10;

   return argA + 5;
}