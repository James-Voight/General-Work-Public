int myFunction(int argA) 
{
   int x = 10;

   return 5 + argA;
}