int myFunction(int argA) 
{
   return 10000 - argA;
}