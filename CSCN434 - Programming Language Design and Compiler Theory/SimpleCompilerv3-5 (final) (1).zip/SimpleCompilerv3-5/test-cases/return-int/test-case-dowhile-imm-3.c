int myFunction() 
{
   int x = 5;
   
   do
   {
      x++;
      x++;
      x++;
   }
   while (x < 67);
   
   return x;
}