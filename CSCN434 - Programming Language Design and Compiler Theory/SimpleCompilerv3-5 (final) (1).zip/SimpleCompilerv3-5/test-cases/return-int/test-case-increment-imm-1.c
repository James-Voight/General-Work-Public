int myFunction() 
{
   int a = 54;
   a++;
   a++;

   return a;
}