int myFunction() 
{
   int x = 10;
   int y = 20;
   int z = 30;

   return y;
}