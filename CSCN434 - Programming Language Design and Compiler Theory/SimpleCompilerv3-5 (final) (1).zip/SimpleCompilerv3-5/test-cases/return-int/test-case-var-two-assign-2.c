int myFunction() 
{
   int x;
   int y;

   x = 10;
   y = 12;

   return y;
}