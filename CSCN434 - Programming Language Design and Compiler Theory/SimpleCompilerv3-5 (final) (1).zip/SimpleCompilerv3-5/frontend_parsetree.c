#include <stdlib.h>
#include <string.h>

#ifndef COMPILER_PARSETREE
#define COMPILER_PARSETREE

typedef enum { FUNC, INT, STRING, BINOP, UNOP, RELOAD, BLOCK, DOWHILE } ParseTreeType;
typedef enum {
    ADDITION,
    SUBTRACTION,
    MULTIPLICATION,
    LESS_THAN,
    GREATER_THAN,
    LESS_EQUAL,
    GREATER_EQUAL,
    EQUAL_TO,
    NOT_EQUAL_TO
} ParseTreeBinOp;
typedef enum { LOGICALNEGATION, DECLASSIGN, DECLWITHOUTASSIGN, STORETOSTACK, RET } ParseTreeUnOp;

typedef struct parseTree ParseTree;
typedef struct BlockStmtList BlockStmtList;
typedef struct BlockExpr BlockExpr;
typedef struct DoWhileExpr DoWhileExpr;

typedef struct BinOpExpr {
    ParseTreeBinOp BinOpType;
    ParseTree *lOperand;
    ParseTree *rOperand;
} BinOpExpr;

typedef struct UnOpExpr {
    ParseTreeUnOp UnOpType;
    ParseTree *rOperand;
    char *target;
} UnOpExpr;

struct parseTree {
    ParseTreeType type;
    union {
        int constantValue;
        char *string;
        BinOpExpr *binExpr;
        UnOpExpr *unExpr;
        BlockExpr *blockExpr;  // for BLOCK
        DoWhileExpr *doWhileExpr; // for DOWHILE
    };
};

typedef struct BlockStmtList {
    ParseTree *stmt;               // this statement node
    struct BlockStmtList *next;    // next in block, or NULL
} BlockStmtList;

// Represents a { ... } block.
typedef struct BlockExpr {
    BlockStmtList *head;           // first statement in the block
    BlockStmtList *tail;           // last node so we can append in O(1)
} BlockExpr;

// Represents a do {body} while (cond);
typedef struct DoWhileExpr {
    ParseTree *body;               // either a BLOCK node or a single stmt node
    ParseTree *cond;               // condition node (your `condition` nonterminal)
} DoWhileExpr;

ParseTree *funcType(char *string) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    parseTree->type = FUNC;
    parseTree->string = string;
    return parseTree;
}


ParseTree *intType(int constantValue) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    parseTree->type = INT;
    parseTree->constantValue = constantValue;
    return parseTree;
}

ParseTree *stringType(char *string) {
    
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    parseTree->type = STRING;
    parseTree->string = string;
    return parseTree;
}

ParseTree *add(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = ADDITION;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *subtract(ParseTree *lint, ParseTree *rint) {
    
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = SUBTRACTION;
    binOpExpr->lOperand = lint;
    binOpExpr->rOperand = rint;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *multiply(ParseTree *lint, ParseTree *rint) {
    
    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = MULTIPLICATION;
    binOpExpr->lOperand = lint;
    binOpExpr->rOperand = rint;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *lessThan(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = LESS_THAN;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *greaterThan(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = GREATER_THAN;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *lessEq(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = LESS_EQUAL;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *greaterEq(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = GREATER_EQUAL;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *equalTo(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = EQUAL_TO;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *notEqualTo(ParseTree *lOperand, ParseTree *rOperand) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    BinOpExpr *binOpExpr = malloc(sizeof(BinOpExpr));
    binOpExpr->BinOpType = NOT_EQUAL_TO;
    binOpExpr->lOperand = lOperand;
    binOpExpr->rOperand = rOperand;
    parseTree->type = BINOP;
    parseTree->binExpr = binOpExpr;
    return parseTree;
}

ParseTree *logicalNegation(ParseTree *rint) {

    // TO DO (and remove the "return 0;")
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    UnOpExpr *unOpExpr = malloc(sizeof(UnOpExpr));
    unOpExpr->UnOpType = LOGICALNEGATION;
    unOpExpr->rOperand = rint;
    unOpExpr->target = NULL;
    parseTree->type = UNOP;
    parseTree->unExpr = unOpExpr;
    return parseTree;
}

ParseTree *declarationWithAssign(const char *dstName, ParseTree *rint) {

    ParseTree *parseTree = malloc(sizeof(ParseTree));
    UnOpExpr *unOpExpr = malloc(sizeof(UnOpExpr));
    unOpExpr->UnOpType = DECLASSIGN;
    unOpExpr->rOperand = rint;
    unOpExpr->target = dstName ? strdup(dstName) : NULL;
    parseTree->type = UNOP;
    parseTree->unExpr = unOpExpr;
    return parseTree;
}

ParseTree *declarationWithoutAssign(char *dstName) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    UnOpExpr *unOpExpr = malloc(sizeof(UnOpExpr));
    unOpExpr->UnOpType = DECLWITHOUTASSIGN;
    unOpExpr->rOperand = NULL;
    unOpExpr->target = dstName ? strdup(dstName) : NULL;
    parseTree->type = UNOP;
    parseTree->unExpr = unOpExpr;
    return parseTree;
}

ParseTree *reload(char *string) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    parseTree->type = RELOAD;
    parseTree->string = string;
    return parseTree;
}


ParseTree *storeToStack(ParseTree *rint) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    UnOpExpr *unOpExpr = malloc(sizeof(UnOpExpr));
    unOpExpr->UnOpType = STORETOSTACK;
    unOpExpr->rOperand = NULL;
    unOpExpr->target = (rint && rint->type == STRING && rint->string) ? strdup(rint->string) : NULL;
    parseTree->type = UNOP;
    parseTree->unExpr = unOpExpr;
    return parseTree;
}

ParseTree *ret(ParseTree *rint) {
    ParseTree *parseTree = malloc(sizeof(ParseTree));
    UnOpExpr *unOpExpr = malloc(sizeof(UnOpExpr));
    unOpExpr->UnOpType = RET;
    unOpExpr->rOperand = rint;
    unOpExpr->target = NULL;
    parseTree->type = UNOP;
    parseTree->unExpr = unOpExpr;
    return parseTree;
}

ParseTree *makeBlock(ParseTree *firstStmt, void *unusedShouldBeNULL) {
    // allocate list node for the first statement
    BlockStmtList *listNode = malloc(sizeof(BlockStmtList));
    listNode->stmt = firstStmt;
    listNode->next = NULL;

    // create the BlockExpr
    BlockExpr *blockExpr = malloc(sizeof(BlockExpr));
    blockExpr->head = listNode;
    blockExpr->tail = listNode;

    // wrap in a ParseTree
    ParseTree *node = malloc(sizeof(ParseTree));
    node->type = BLOCK;
    node->blockExpr = blockExpr;
    return node;
}

void appendToBlock(ParseTree *blockNode, ParseTree *stmtNode) {
    BlockExpr *block = blockNode->blockExpr;

    // allocate a new list node
    BlockStmtList *listNode = malloc(sizeof(BlockStmtList));
    listNode->stmt = stmtNode;
    listNode->next = NULL;

    // attach it to the tail
    if (block->tail) {
        block->tail->next = listNode;
        block->tail = listNode;
    } else {
        // shouldn't really happen, but just in case block was empty
        block->head = listNode;
        block->tail = listNode;
    }
}

ParseTree *doWhileLoop(ParseTree *bodyNode, ParseTree *condNode) {
    DoWhileExpr *dw = malloc(sizeof(DoWhileExpr));
    dw->body = bodyNode;  // bodyNode can be a BLOCK or a single stmt node
    dw->cond = condNode;  // condNode is from `condition`

    ParseTree *node = malloc(sizeof(ParseTree));
    node->type = DOWHILE;
    node->doWhileExpr = dw;
    return node;
}



#endif
