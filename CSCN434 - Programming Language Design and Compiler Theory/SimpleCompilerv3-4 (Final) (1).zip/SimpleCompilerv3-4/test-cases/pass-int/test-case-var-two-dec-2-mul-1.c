int myFunction(int argA) 
{
   int a;
   int b;
   int x = 30;
   int y = 20;

   return argA * y;
}