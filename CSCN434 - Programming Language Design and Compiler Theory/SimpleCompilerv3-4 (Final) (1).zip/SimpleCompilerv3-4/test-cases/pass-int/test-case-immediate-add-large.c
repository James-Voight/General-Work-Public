int myFunction(int argA) 
{
   return argA + 2000;
}