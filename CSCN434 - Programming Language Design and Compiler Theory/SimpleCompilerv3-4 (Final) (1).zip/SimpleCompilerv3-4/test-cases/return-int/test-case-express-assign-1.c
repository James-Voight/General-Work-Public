int myFunction() 
{
   int x;
   int y;
   int z;
   int alpha;
   int a = 0;
   x = 10 + 5;
   x++;
   y = x * 7;
   z = y + 1000;
   z++;
   alpha = z + 45;


   return alpha;
}