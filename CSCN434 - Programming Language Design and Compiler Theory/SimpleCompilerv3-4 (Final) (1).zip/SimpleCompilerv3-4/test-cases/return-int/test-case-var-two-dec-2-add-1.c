int myFunction() 
{
   int a;
   int b;
   int x = 10;
   int y = 20;

   return x + y;
}