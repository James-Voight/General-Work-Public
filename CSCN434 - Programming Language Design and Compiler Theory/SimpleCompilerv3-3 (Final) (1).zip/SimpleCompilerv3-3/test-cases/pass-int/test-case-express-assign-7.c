int myFunction(int alpha) 
{
   int x;
   int y = 2;
   int z = 5;
   int a = 0;
   int b = 1;
   int c;

   y++;
   x = y + z;
   c = !b;
   z++;
   alpha = !a;

   return alpha;
}