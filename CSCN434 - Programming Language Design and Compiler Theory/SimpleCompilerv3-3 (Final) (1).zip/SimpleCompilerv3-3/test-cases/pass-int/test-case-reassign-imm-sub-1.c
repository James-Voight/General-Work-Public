int myFunction(int y) 
{
   int a = 50;
   int x;
   a = 75;
   x = 90;
   y = 100;
   x = 66;
   y = 32;

   return a - y;
}