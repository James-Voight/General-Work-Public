int myFunction() 
{
   int x;

   x = 10;

   return x;
}