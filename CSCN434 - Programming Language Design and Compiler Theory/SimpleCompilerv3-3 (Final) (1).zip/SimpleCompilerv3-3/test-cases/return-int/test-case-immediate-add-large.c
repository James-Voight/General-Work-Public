int myFunction() 
{
   return 1000 + 2000;
}