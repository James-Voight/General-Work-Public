int myFunction() 
{
   int x = 10;

   return x - 5;
}