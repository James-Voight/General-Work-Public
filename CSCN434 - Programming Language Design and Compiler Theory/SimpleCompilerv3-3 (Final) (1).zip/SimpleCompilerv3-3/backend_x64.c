// https://refspecs.linuxbase.org/elf/x86_64-abi-0.99.pdf
// sticking to Intel syntax and will use NASM to assemble

#include "stdio.h"
#include "backend_parsetree.c"
#include <string.h>
#include "symboltable.h"

void insertSymbol(struct SymbolTable *symbolTable,
                  char *entryType,
                  char *symbolType,
                  char *symbolName,
                  int symbolLocation,
                  int size);


int funcCodeSymbolIndex = 0;
int LatestRegCounter = 1;
int secondaryIndexLogicalNegation = 1;
int stackLocation = 1;
int regEBX[1] = {0}; // counter of how many times it was used
int regECX[1] = {0}; // counter of how many times it was used

char * allocateNewRegister() 
{
    if (regEBX[0] <= regECX[0])
    {
        regEBX[0] = LatestRegCounter;
        LatestRegCounter++;
        return (char*)"ebx";
    }
    else if (regEBX[0] >= regECX[0])
    {
        regECX[0]= LatestRegCounter;
        LatestRegCounter++;
        return (char*)"ecx";
    }

    return (char*)"NULL REGISTER RETURNED";
}

char * lastRegisterAllocated()
{
    if (regEBX[0] <= regECX[0])
    {
        return (char*)"ecx";
    }
    else if (regEBX[0] >= regECX[0])
    {
        return (char*)"ebx";
    }

    return (char*)"NULL REGISTER RETURNED";
}

char * secondToLastRegisterAllocated() 
{
    if (regEBX[0] <= regECX[0])
    {
        return (char*)"ebx";
    }
    else if (regEBX[0] >= regECX[0])
    {
        return (char*)"ecx";
    }

    return (char*)"NULL REGISTER RETURNED";
}

void printRegisterAllocation()
{
    printf("\n*********** -> regEBX[%d]\n", regEBX[0]);
    printf("*********** -> regECX[%d]\n\n", regECX[0]);
}

void dataSectionHeader(FILE *prog) {
    fprintf(prog, "section .data\n\n");
}

void textSectionHeader(FILE *prog) {
    fprintf(prog, "section .text\n\n");
}

void functionHeader(FILE *prog, char * funcName) {
    fprintf(prog, "    global %sFinal:\n\n", funcName); 
    fprintf(prog, "%sFinal:\n", funcName); 
}

void funcPrologue(FILE *prog, struct SymbolTable * symbolTable) {
    
    // Find the largest stack location in the symbol table
    int stackLocation = 0;

    for(int x = 0; x < symbolTable->totalEntries; ++x)
    {
        stackLocation = symbolTable[x].symbolLocation;
    }
    
    
    //prepare a dynamic stack frame
    fprintf(prog, "    push rbp\n");
    fprintf(prog, "    mov rbp, rsp\n");
    fprintf(prog, "    sub rsp, %d\n\n", (stackLocation *4)-4);

    for (int x = 0; x < symbolTable->totalEntries; ++x)
    {
        // if the function has an argument, reserve space
        if (!strcmp(symbolTable[x].entryType, "ARG"))
        {
            fprintf(prog, "    mov [rbp-%d], edi\n\n", symbolTable[x].symbolLocation * 4);
            break;
        }
    }
}

void returnValue(FILE *prog) {
    fprintf(prog, "    mov eax, edi\n");
    fprintf(prog, "    leave\n"); // This moves base pointer to stack pointer for the return
    fprintf(prog, "    ret\n");
}

void funcCode(FILE *prog, ParseTree *parseTree, struct SymbolTable * symbolTable) {

    if (parseTree->type == INT) {
        printf("backend_x64.c constantValue: %d\n", parseTree->constantValue);
        fprintf(prog, "    mov edi, %d\n", parseTree->constantValue);

    }  
    else if (parseTree->type == STRING) {
        printf("backend_x64.c stringValue: %s\n", parseTree->string);

        for(int x = 0; x < symbolTable->totalEntries; ++x)
        {
                if(!strcmp(symbolTable[x].symbolName, parseTree->string))
                {
                    printf("backend_x64.c found variable in symbol table: %d\n", x);
                    printf("backend_x64.c symbol location: %d\n", symbolTable[x].symbolLocation);
                    fprintf(prog, "    mov edi, [rbp-%d]\n", symbolTable[x].symbolLocation * 4);
                    break;
                }
        }

    }  
    else if (parseTree->type == RELOAD) {
        printf("backend_x64.c stringValue: %s\n", parseTree->string);

        for(int x = 0; x < symbolTable->totalEntries; ++x)
        {
            if(!strcmp(symbolTable[x].symbolName, parseTree->string))
            {
                // TO DO
                fprintf(prog, "    mov %s, [rbp-%d]\n", allocateNewRegister(), symbolTable[x].symbolLocation * 4);
                fprintf(prog, "    mov edi, %s\n", lastRegisterAllocated());
                break;
            }
        }

    } 
    else if (parseTree->type == BINOP) {
        BinOpExpr *binOpExpr = parseTree->binExpr;

        if (binOpExpr->BinOpType == ADDITION) {
            // TO DO
            // left value into edi and stash in register
            funcCode(prog, binOpExpr->lOperand, symbolTable);
            fprintf(prog, "    mov %s, edi\n", allocateNewRegister());

            // right value into edi and stash in register
            funcCode(prog, binOpExpr->rOperand, symbolTable);
            fprintf(prog, "    mov %s, edi\n", allocateNewRegister());

            // add
            fprintf(prog, "    add %s, %s\n", secondToLastRegisterAllocated(), lastRegisterAllocated());
            fprintf(prog, "    mov edi, %s\n\n", secondToLastRegisterAllocated());
                       
        }
        else if (binOpExpr->BinOpType == SUBTRACTION) {
            
            // TO DO
            // left value into edi and stash in register
            funcCode(prog, binOpExpr->lOperand, symbolTable);
            fprintf(prog, "    mov %s, edi\n", allocateNewRegister());

            // right value into edi and stash in register
            funcCode(prog, binOpExpr->rOperand, symbolTable);
            fprintf(prog, "    mov %s, edi\n", allocateNewRegister());

            // subtract
            fprintf(prog, "    sub %s, %s\n", secondToLastRegisterAllocated(), lastRegisterAllocated());
            fprintf(prog, "    mov edi, %s\n\n", secondToLastRegisterAllocated());
            
        }
        else if (binOpExpr->BinOpType == MULTIPLICATION) {
            
            // TO DO
            // left value into edi and stash in register
            funcCode(prog, binOpExpr->lOperand, symbolTable);
            fprintf(prog, "    mov %s, edi\n", allocateNewRegister());

            // right value into edi and stash in register
            funcCode(prog, binOpExpr->rOperand, symbolTable);
            fprintf(prog, "    mov %s, edi\n", allocateNewRegister());

            // multiply
            fprintf(prog, "    imul %s, %s\n", secondToLastRegisterAllocated(), lastRegisterAllocated());
            fprintf(prog, "    mov edi, %s\n\n", secondToLastRegisterAllocated());
        }

    } else if (parseTree->type == UNOP) {
        UnOpExpr *unOpExpr = parseTree->unExpr;

        if (unOpExpr->UnOpType == LOGICALNEGATION) {
            
            // TO DO
            funcCode(prog, unOpExpr->rOperand, symbolTable);

            // 0 to 1, 1 to 0
            fprintf(prog, "    cmp   edi, 0\n");   // is edi = 0
            fprintf(prog, "    sete al\n");
            fprintf(prog, "    movzx edi, al\n\n");
        }

        else if (unOpExpr->UnOpType == DECLASSIGN) {
            
            // TO DO
                ParseTree *dst = unOpExpr->rOperand->binExpr->lOperand; // STRING("%n") or RELOAD("x.reload.4")
                ParseTree *src = unOpExpr->rOperand->binExpr->rOperand;

                funcCode(prog, src, symbolTable);

                // store EDI into dst slot
                    int found = 0;
                    for (int x = 0; x < symbolTable->totalEntries; ++x) {
                        if (!strcmp(symbolTable[x].symbolName, dst->string)) {
                            fprintf(prog, "    mov [rbp-%d], edi\n", symbolTable[x].symbolLocation * 4);
                            found = 1;
                            break;
                        }
                    }

                    if (!found) {
                        // compute next free slot from current table
                        int maxSlot = 0;
                        for (int i = 0; i < symbolTable->totalEntries; ++i) {
                            if (symbolTable[i].symbolLocation > maxSlot)
                                maxSlot = symbolTable[i].symbolLocation;
                        }
                        int newSlot = maxSlot + 1;              //next slot index
                        
                        insertSymbol(symbolTable, (char *)"SSA", (char *)"i32", dst->string, newSlot, 4);
                        fprintf(prog, "    mov [rbp-%d], edi\n", newSlot * 4);
                    }

        }

        else if (unOpExpr->UnOpType == STORETOSTACK) {
            
            // TO DO
                ParseTree *dst = unOpExpr->rOperand->binExpr->lOperand;  // STRING or RELOAD
                ParseTree *src = unOpExpr->rOperand->binExpr->rOperand;

                funcCode(prog, src, symbolTable);

                // store edi into destination slot (allocate if missing)
                    int found = 0;
                    for (int x = 0; x < symbolTable->totalEntries; ++x) {
                        if (!strcmp(symbolTable[x].symbolName, dst->string)) {
                            fprintf(prog, "    mov [rbp-%d], edi\n", symbolTable[x].symbolLocation * 4);
                            if (src && src->type == STRING) {
                                for (int j = 0; j < symbolTable->totalEntries; ++j) {
                                    if (!strcmp(symbolTable[j].symbolName, src->string) &&
                                        !strcmp(symbolTable[j].entryType, "ARG")) {
                                        symbolTable[j].symbolLocation = symbolTable[x].symbolLocation;
                                        break;
                                    }
                                }
                            }
                            found = 1;
                            break;
                        }
                    }

                    if (!found) {
                        int maxSlot = 0;
                        for (int i = 0; i < symbolTable->totalEntries; ++i) {
                            if (symbolTable[i].symbolLocation > maxSlot)
                                maxSlot = symbolTable[i].symbolLocation;
                        }
                        int newSlot = maxSlot + 1;   // next slot index
                        
                        insertSymbol(symbolTable, (char *)"SSA", (char *)"i32", dst->string, newSlot, 4);
                        fprintf(prog, "    mov [rbp-%d], edi\n", newSlot * 4);
                    }
        }

        else if (unOpExpr->UnOpType == RET) {
            
            // TO DO
            ParseTree *val = unOpExpr->rOperand;

            // Evaluate the return expression
            funcCode(prog, val, symbolTable);

            // Move to the i32 return register and exit
            fprintf(prog, "    mov eax, edi\n");

            fprintf(prog, "    leave\n");
            fprintf(prog, "    ret\n");
            return;
        }

       


    }
}
