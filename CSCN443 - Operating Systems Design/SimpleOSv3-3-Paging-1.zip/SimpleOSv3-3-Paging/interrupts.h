/** The interrupt descriptor structure. This is the layout of teh entries in the interrupt descriptor table. */
struct interruptDescriptor {
    short lsbOffset;
    short selector;
    char zero;
    char attributes;
    short msbOffset;
};

/** Remaps the programmable interrupt controller (PIC) due to an Intel flaw. See: https://wiki.osdev.org/8259_PIC
 * \param masterPICMask The mask to use to enable/disable certain interrupts for master PIC.
 * \param slavePICMask The mask to use to enable/disable certain interrupts for slave PIC.
 */
void remapPIC(unsigned char masterPICMask, unsigned char slavePICMask);

/** Populates the interrupt descriptor table given a starting location.
 * \param idtMemory The pointer to the start of the interrupt descriptor table.
*/
void loadIDT(char *idtMemory);

/** Creates the Intel-prescribed format of the entry to be loaded into the interrupt descriptor table register.
 * \param idtMemory The pointer to the start of the interrupt descriptor table.
 * \param idtrMemory The pointer where the interrupt descriptor table register entry should be stored. 
 */
void loadIDTR(char *idtMemory, char *idtrMemory);

/** Sets the system timer to determine the number of interrupts per second.
 * \param frequency The number of interrupts per second. Determined by constant: SYSTEM_INTERRUPTS_PER_SECOND
 */
void setSystemTimer(int frequency);

/** Turns on system interrupts. */
void enableInterrupts();

/** Turns off system interrupts. This is usually done to avoid race conditions or corruption during critical operations. */
void disableInterrupts();

/** There are several ways to get the Intel processor to move from Ring 0 to Ring 3. I am using an interrupt return method here. See: https://wiki.osdev.org/Getting_to_Ring_3
 * \param binaryEntryAddress The ELF entry address of the binary you want to run as Ring 3.
 */
void switchToRing3LaunchBinary(char *binaryEntryAddress);