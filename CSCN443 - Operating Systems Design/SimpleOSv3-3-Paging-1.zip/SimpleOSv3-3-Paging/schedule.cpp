#include "schedule.h"
#include "kernel.h"
#include "constants.h"
#include "exceptions.h"
#include "vm.h"
#include "x86.h"
#include "syscalls.h"
#include "screen.h"


void scheduler(int currentPid)
{
    // ASSIGNMENT 6 TO DO

}