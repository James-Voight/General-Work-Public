#include "simpleOSlibc.h"

void main()
{   
    for (int x=0; x <10; x++)
    {
        systemShowProcesses();
        wait(1);
    }

    systemExit();
}