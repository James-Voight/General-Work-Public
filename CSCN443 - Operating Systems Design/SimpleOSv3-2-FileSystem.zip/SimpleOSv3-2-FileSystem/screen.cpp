 // https://wiki.osdev.org/Printing_To_Screen

#include "screen.h"
#include "x86.h"
#include "constants.h"

void clearScreen()
{       
    // ASSIGNMENT 1 TO DO
    for (int i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
         //set both the character and attribute(color, etc) to 0 (which is null aka black space character)
        ((unsigned short*)VIDEO_RAM)[i] = 0;
    }
}


void printCharacter(int color, int row, int column, char *message)
{
    // ASSIGNMENT 1 TO DO
    unsigned short* vgaBuffer = (unsigned short*)VIDEO_RAM;
    int index = ((row) * SCREEN_WIDTH + (column));
    switch (message[0]) {
            case '\n':  // New line
                row++;
                column = 0;
                index = row * SCREEN_WIDTH + column;
                break;
            case '\r':  // Carriage return (Ignore)
                break;
            case '\t':  
                column += 4;
                
                // Tab alignment if needed.
                // column += (4 - (column % 4));
                // if (column >= SCREEN_WIDTH) { // Prevent overflow
                //     column = 0;
                //     row++;
                // }
                index = row * SCREEN_WIDTH + column;
                break;
            default:
                vgaBuffer[index] = message[0] | (color << 8);
                column++;
                index = row * SCREEN_WIDTH + column;
        }
    
}

void printString(int color, int row, int column, char *message)
{
    // ASSIGNMENT 1 TO DO
    unsigned short* vgaBuffer = (unsigned short*)VIDEO_RAM;
    int index = row * SCREEN_WIDTH + column;

    for (int i = 0; message[i] != '\0'; i++) {
        char character = message[i];

        switch (character) {
            case '\n':  // New line
                row++;
                column = 0;
                index = row * SCREEN_WIDTH + column;
                break;
            case '\r':  // Carriage return (move to start of a new line)
                row++;
                column = 0;
                index = row * SCREEN_WIDTH + column;
                break;
            case '\t':
                column += 4;
                
                // Tab alignment if needed.
                // column += (4 - (column % 4));
                // if (column >= SCREEN_WIDTH) { // Prevent overflow
                //     column = 0;
                //     row++;
                // }
                index = row * SCREEN_WIDTH + column;
                break;
            default:
                vgaBuffer[index] = (color << 8) | character;
                column++;
                index = row * SCREEN_WIDTH + column;
        }
    }
}


void printHexNumber(int color, int row, int column, unsigned char number)
{
    // Array called hexString to hold the two hex digits as characters
    char hexString[3];
    hexString[2] = '\0';  // Null-terminate the string

    // High nibble
    unsigned char highNibble = number / 16;  // Integer division by 16
    if (highNibble < 10) {
        hexString[0] = '0' + highNibble;  // Convert to '0'-'9'
    } else {
        hexString[0] = 'a' + (highNibble - 10);  // Convert to 'a'-'f'
    }

    // Low nibble
    unsigned char lowNibble = number % 16;  // Modulo 16
    if (lowNibble < 10) {
        hexString[1] = '0' + lowNibble;  // Convert to '0'-'9'
    } else {
        hexString[1] = 'a' + (lowNibble - 10);  // Convert to 'a'-'f'
    }

    // Print the hex string at the specified location an color
    printString(color, row, column, hexString);

}


void printLogo(int lineNumber)
{
        printString(12, lineNumber++, 0,(char *)"                                                __                      _   __");
        printString(12, lineNumber++, 0,(char *)"                                               (_  o ._ _  ._  |  _    / \\ (_ ");
        printString(12, lineNumber++, 0,(char *)"                                               __) | | | | |_) | (/_   \\_/ __)");
        printString(12, lineNumber, 0,(char *)"                                                           |                  ");
        printString(9, lineNumber, 65, (char *)"version 3.0");
}

void enableCursor()
{
    outputIOPort(0x3D4, 0x0A);
    outputIOPort(0x3D5, (inputIOPort(0x3D5) & 0xC0) | 0xD); //scan line start

    outputIOPort(0x3D4, 0x0B);
    outputIOPort(0x3D5, (inputIOPort(0x3D5) & 0xE0) | 0xF); //scan line stop
}

void disableCursor()
{
    outputIOPort(0x3D4, 0x0A);
    outputIOPort(0x3D5, 0x20);
}

void moveCursor(int row, int column)
{
    unsigned short cursorPosition = row * 80 + column;

    outputIOPort(0x3D4, 0x0F);
	outputIOPort(0x3D5, (unsigned char)((unsigned short)cursorPosition & 0xFF));
    outputIOPort(0x3D4, 0x0E);
	outputIOPort(0x3D5, (unsigned char)(((unsigned short)cursorPosition >> 8) & 0xFF));

}