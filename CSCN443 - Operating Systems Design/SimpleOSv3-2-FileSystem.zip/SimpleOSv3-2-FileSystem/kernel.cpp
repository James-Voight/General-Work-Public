#include "kernel.h"
#include "screen.h"
#include "fs.h"
#include "x86.h"
#include "vm.h"
#include "keyboard.h"
#include "interrupts.h"
#include "syscalls.h"
#include "simpleOSlibc.h"
#include "constants.h"
#include "frame-allocator.h"
#include "exceptions.h"
#include "vmmonitor.h"
#include "file.h"



void main()
{
    clearScreen();
    printString(COLOR_WHITE, 8, 5, (char *)"Welcome to the kernel!");

    while (true) {}
}