#include "simpleOSlibc.h"
#include "constants.h"
#include "vm.h"
#include "x86.h"
#include "sound.h"
#include "file.h"
#include "screen.h"
#include "keyboard.h"

void wait(int timeToWait)
{
    // Each syscall to SYS_WAIT waits one second. timeToWait is how many seconds to wait
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    for (int x = 0; x < timeToWait; x++)
    {
        sysCall(SYS_WAIT, 0x0, myPid);
    }

}

int strcmp(char *firstString, char *secondString)
{
    // Implementation from "The C Programming Language" (C) 1978
    // Brian Kernighan and Dennis Ritchie
    // Page 102
    
    // return < 0 if firstString < secondString
    // return 0 if firstString == secondString
    // return > 0 if secondString > firstString

    for ( ; *firstString == *secondString; firstString++, secondString++)
    {
        if (*firstString == '\0')
        {
            return 0;
        }
    }

    return (*firstString - *secondString);
}

int strlen(char *targetString)
{
    // Implementation from "The C Programming Language" (C) 1978
    // Brian Kernighan and Dennis Ritchie
    // Page 98
    
    char *p = targetString;

    while (*p != '\0')
    {
        p++;
    }

    return (p-targetString);
}

void strcpy(char *destinationString, char *sourceString)
{
    // Implementation from "The C Programming Language" (C) 1978
    // Brian Kernighan and Dennis Ritchie
    // Page 100

    while ((*destinationString = *sourceString) != '\0')
    {
        destinationString++;
        sourceString++;
    }    
}

void strcpyRemoveNewline(char *destinationString, char *sourceString)
{
    // Implementation from "The C Programming Language" (C) 1978
    // Brian Kernighan and Dennis Ritchie
    // Based on strcpy, modified by DMO

    while ((*sourceString) != 0xa)
    {
        *destinationString = *sourceString;
        
        destinationString++;
        sourceString++;
    }    
}

void bytecpy(char *destinationMemory, char *sourceMemory, int numberOfBytes)
{
    for (int x = 0; x < numberOfBytes; x++)
    {
        *destinationMemory = *sourceMemory;
        destinationMemory++;
        sourceMemory++;
    }
}

void reverseString(char *targetString)
{
    // Implementation from "The C Programming Language" (C) 1978
    // Brian Kernighan and Dennis Ritchie
    // Page 59

    int c, i, j;
    for (i = 0, j = strlen(targetString)-1; i < j; i++, j--)
    {
        c = targetString[i];
        targetString[i] = targetString[j];
        targetString[j] = c;
    }
}

unsigned int power(int number, int exponent)
{
    // Implementation from "The C Programming Language" (C) 1978
    // Brian Kernighan and Dennis Ritchie
    // Page 24

    int p;

    for (p = 1; exponent > 0; --exponent)
    {
        p = p * number;
    }
    return (unsigned int)p;
}

void itoa(int number, char *destinationMemory)
{
    // Implementation from "The C Programming Language" (C) 1978
    // Brian Kernighan and Dennis Ritchie
    // Page 60
    // Modified by DMO for ASCII

    int i, sign;

    if ((sign = number) < 0) // record sign
    {
        number = -number; // make number positive
    }
    i = 0;

    do { // generate digits in reverse order
        destinationMemory[i++] = number % 10 + '\0' + 0x30; // get next digit, align to ASCII
    } while ((number /= 10) > 0); // delete it

    if (sign < 0)
    {
        destinationMemory[i++] = '-';
    }
    destinationMemory[i] = '\0';
    reverseString(destinationMemory);

}

int atoi(char *sourceString)
{
    // Implementation from "The C Programming Language" (C) 1978
    // Brian Kernighan and Dennis Ritchie
    // Page 58

    int i, n, sign;

    for (i = 0; sourceString[i]== ' ' || sourceString[i] == '\n' || sourceString[i] == '\t'; i++)
    {
        //skip whitespace
    }
    sign = 1;
    if (sourceString[i] == '+' || sourceString[i] == '-')
    {
        sign = (sourceString[i++] == '+') ? 1 : -1;
    }
    for (n = 0; sourceString[i] >= '0' && sourceString[i] <= '9'; i++)
    {
        n = 10 * n + sourceString[i] - '0';
    }
    return(sign * n);

}

int ceiling(int number, int base)
{
    return ((number + base - 1) / base);
}

char* malloc(int currentPid, int objectSize)
{  
    // Heap entries take up 16 bytes each, but 1 byte is the PID that owns it.
    // So, heap items cannot exceed 15 bytes (including null byte for strings)
    // If you need more than this, use mmap to get 4,096 bytes
    unsigned char heapObjectNumber = 0;
    struct heapObject *HeapObject = (struct heapObject*)USER_HEAP;

    if (objectSize > HEAP_OBJ_USABLE_SIZE)
    {
        return 0;
    }

    while (heapObjectNumber < MAX_HEAP_OBJECTS)
    {
        if (HeapObject->pid == 0)
        {
            HeapObject->pid = (unsigned char)currentPid;
            return &HeapObject->heapUseable[0];    
        }
        heapObjectNumber++;
        HeapObject++;
    }
    // return null pointer if unable to find object
    return 0;    
}

void free(char *heapObject)
{
    fillMemory((heapObject - 1), 0x0, HEAP_OBJ_SIZE); // minus 1 to remove the entire entry, including pid
}


void freeAll(int currentPid)
{
    int heapObjectNumber = 0;
    int heapObjectPid = 0;

    while (heapObjectNumber < MAX_HEAP_OBJECTS)
    {

        heapObjectPid = *(int *)(USER_HEAP + (HEAP_OBJ_SIZE * heapObjectNumber));

        if (heapObjectPid == currentPid)
        {
            fillMemory((char *)(USER_HEAP + (HEAP_OBJ_SIZE * heapObjectNumber)), 0x0, HEAP_OBJ_SIZE);
        }

        heapObjectNumber++;
    }
}


char* kMalloc(int currentPid, int objectSize)
{
    // Heap entries take up 16 bytes each, but 1 byte is the PID that owns it.
    // So, heap items cannot exceed 15 bytes (including null byte for strings)
    // If you need more than this, use mmap to get 4,096 bytes
    unsigned char heapObjectNumber = 0;
    struct heapObject *HeapObject = (struct heapObject*)KERNEL_HEAP;

    if (objectSize > HEAP_OBJ_USABLE_SIZE)
    {
        return 0;
    }

    while (heapObjectNumber < MAX_HEAP_OBJECTS)
    {
        if (HeapObject->pid == 0)
        {
            HeapObject->pid = (unsigned char)currentPid;
            return &HeapObject->heapUseable[0];    
        }
        heapObjectNumber++;
        HeapObject++;
    }
    // return null pointer if unable to find object
    return 0;
}

void kFree(char *heapObject)
{
    fillMemory((heapObject - 1), 0x0, HEAP_OBJ_SIZE); // minus 4 to remove the entire entry, including pid
}

void kFreeAll(int currentPid)
{
    int heapObjectNumber = 0;
    int heapObjectPid = 0;

    while (heapObjectNumber < MAX_HEAP_OBJECTS)
    {

        heapObjectPid = *(int *)(KERNEL_HEAP + (HEAP_OBJ_SIZE * heapObjectNumber));

        if (heapObjectPid == currentPid)
        {
            fillMemory((char *)(KERNEL_HEAP + (HEAP_OBJ_SIZE * heapObjectNumber)), 0x0, HEAP_OBJ_SIZE);
        }

        heapObjectNumber++;
    }
}

unsigned int stringHash(char *messagetoHash)
{
    int sum = 0;

    while (*messagetoHash != 0x0)
    { 
        sum += *messagetoHash;
        messagetoHash++;
    } 

    return sum;
}

void makeSound(int frequency, int duration)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    
    struct soundParameter *SoundParameter = (struct soundParameter *)(malloc(myPid, sizeof(soundParameter)));

    SoundParameter->frequency = frequency;
    SoundParameter->duration = duration;
    sysCall(SYS_SOUND, (unsigned int)SoundParameter, myPid); 

    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    free((char *)SoundParameter);
}

void systemUptime()
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_UPTIME, 0x0, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}

void systemExit()
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_EXIT, 0x0, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}

void systemFree()
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_FREE, 0x0, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}

char * systemMMap()
{
    int returnedPage;
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_MMAP, 0x0, myPid);
    returnedPage = readValueFromMemLoc(RETURNED_MMAP_PAGE_LOC);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    return (char *)returnedPage;
}

void systemSwitchToParent()
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    if (myPid == 1)
    {
        return; // There is no parent of PID 1
    }

    sysCall(SYS_SWITCH_TASK_TO_PARENT, 0x0, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}

void systemBeep()
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_BEEP, 1000, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}

void systemShowProcesses()
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_PS, 0x0, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}

void systemListDirectory()
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_DIR, 0x0, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}

void systemSchedulerToggle()
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_TOGGLE_SCHEDULER, 0x0, myPid);
    printString(COLOR_WHITE, 2, 5, (char*)"Scheduler toggled.");
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}

void systemForkExec(char* fileName, int requestedRunPriority)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    struct fileParameter *FileParameter = (struct fileParameter *)(malloc(myPid, sizeof(fileParameter)));
    FileParameter->fileNameLength = strlen(fileName);
    FileParameter->fileName = fileName;
    FileParameter->requestedRunPriority = requestedRunPriority;

    sysCall(SYS_FORK_EXEC, (unsigned int)FileParameter, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    free((char *)FileParameter);
}

void systemKill(char* pidToKill)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    char *pidToKillMem = malloc(myPid, sizeof(int));
    bytecpy(pidToKillMem, pidToKill, 1);

    if (atoi(pidToKillMem) == myPid)
    {
        printString(COLOR_RED, 1, 2, (char *)"You cannot kill yourself!");
        systemBeep();

        free(pidToKillMem);
        return;
    }

    sysCall(SYS_KILL, atoi(pidToKillMem), myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    free(pidToKillMem);
}

void systemTaskSwitch(char* pidToSwitchTo)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    char *pidToSwitch = malloc(myPid, sizeof(int));
    bytecpy(pidToSwitch, pidToSwitchTo, 1);

    if (atoi(pidToSwitch) == myPid)
    { 
        printString(COLOR_RED, 1, 2, (char *)"You cannot switch to yourself!");
        systemBeep();

        return;
    }

    sysCall(SYS_SWITCH_TASK, atoi(pidToSwitch), myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    free(pidToSwitch);
}

void systemShowMemory(char* memoryLocation)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    char *memLocationToDump = malloc(myPid, sizeof(int));
    bytecpy(memLocationToDump, memoryLocation, 15);

    sysCall(SYS_MEM_DUMP, atoi(memLocationToDump), myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    free(memLocationToDump);
}

void systemShowOpenFiles()
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_SHOW_OPEN_FILES, 0x0, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}


void systemOpenFile(char* fileName, int requestedPermissions)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    struct fileParameter *FileParameter = (struct fileParameter *)(malloc(myPid, sizeof(fileParameter)));
    FileParameter->fileNameLength = strlen(fileName);
    FileParameter->requestedPermissions = requestedPermissions;
    FileParameter->fileName = fileName;
    sysCall(SYS_OPEN, (unsigned int)FileParameter, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    free((char *)FileParameter);
}

void systemOpenEmptyFile(char* fileName, int requestedSizeInPages)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    struct fileParameter *FileParameter = (struct fileParameter *)(malloc(myPid, sizeof(fileParameter)));
    FileParameter->fileNameLength = strlen(fileName);
    FileParameter->requestedPermissions = RDWRITE;
    FileParameter->requestedSizeInPages = requestedSizeInPages;
    FileParameter->fileName = fileName;
    sysCall(SYS_OPEN_EMPTY, (unsigned int)FileParameter, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    free((char *)FileParameter);
}

void systemCreateFile(char* fileName, int fileDescriptor)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    struct fileParameter *FileParameter = (struct fileParameter *)(malloc(myPid, sizeof(fileParameter)));
    FileParameter->fileNameLength = strlen(fileName);
    FileParameter->fileDescriptor = fileDescriptor;
    FileParameter->fileName = fileName;
    sysCall(SYS_CREATE, (unsigned int)FileParameter, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    free((char *)FileParameter);
}

void systemDeleteFile(char* fileName)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    struct fileParameter *FileParameter = (struct fileParameter *)(malloc(myPid, sizeof(fileParameter)));
    FileParameter->fileNameLength = strlen(fileName);
    FileParameter->fileName = fileName;
    sysCall(SYS_DELETE, (unsigned int)FileParameter, myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    free((char *)FileParameter);
}

void systemCloseFile(char* fileDescriptor)
{
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    sysCall(SYS_CLOSE, atoi(fileDescriptor), myPid);
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
}

char* octalTranslation(unsigned char permissions)
{
    if (permissions == 0x0) { return (char*)"---"; }
    else if (permissions == 0x1) { return (char*)"--X"; }
    else if (permissions == 0x2) { return (char*)"-W-"; }
    else if (permissions == 0x3) { return (char*)"-WX"; }
    else if (permissions == 0x4) { return (char*)"R--"; }
    else if (permissions == 0x5) { return (char*)"R-X"; }
    else if (permissions == 0x6) { return (char*)"RW-"; }
    else if (permissions == 0x7) { return (char*)"RWX"; }
    else { return (char*)"UNK"; }
}

char* directoryEntryTypeTranslation(unsigned char type)
{
    if (type == EXT2_DIRECTORY_ENTRY_FILE) { return (char*)"FILE"; }
    else if (type == EXT2_DIRECTORY_ENTRY_DIR) { return (char*)"DIR"; }
    else { return (char*)"UNK"; }
}

int countHeapObjects(char* heapLoc)
{
    int heapObjectNumber = 0;
    unsigned char lastUsedObj = *(char *)(heapLoc + (HEAP_OBJ_SIZE * heapObjectNumber));
    int objectCount = 0;

    while (heapObjectNumber < MAX_HEAP_OBJECTS)
    {      
        lastUsedObj = *(char *)(heapLoc + (HEAP_OBJ_SIZE * heapObjectNumber));

        if ((unsigned char)lastUsedObj != 0)
        {
            objectCount++;
            
        }
        heapObjectNumber++;

    } 

    return objectCount;
}

int convertToUnixTime(struct time* Time)
{
    // https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap04.html#tag_04_15

    int sec, min, hour, dayOfYear, year;

    sec = Time->sec;
    min = Time->min;
    hour = Time->hour;
    dayOfYear = Time->dayOfYear;
    year = Time->year;

    return (int)(sec + min*SECONDS_IN_MIN + hour*SECONDS_IN_HOUR + dayOfYear*SECONDS_IN_DAY + 
    (year-1970)*SECONDS_IN_YEAR + ((year-1969)/4)*SECONDS_IN_DAY - ((year-1)/100)*SECONDS_IN_DAY + ((year+299)/400)*SECONDS_IN_DAY);
}

time* convertFromUnixTime(int unixTime)
{
    struct time* Time;

    unsigned int year = (unsigned int)((unixTime / SECONDS_IN_YEAR) + 1970);
    unsigned int day = (unsigned int)((unixTime - (((year-1970) * SECONDS_IN_YEAR)) - ((year-1969)/4)*SECONDS_IN_DAY)/SECONDS_IN_DAY);

    Time->year = year;
    Time->dayOfYear = day;
    return Time;
}