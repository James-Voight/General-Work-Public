#include "vm.h"
#include "constants.h"
#include "simpleOSlibc.h"

void createPageFrameMap(char *pageFrameMap, int numberOfFrames)
{
    // ASSIGNMENT 3 TO DO
}


int allocateFrame(int pid, char *pageFrameMap)
{
    
    // ASSIGNMENT 3 TO DO

    return 0; // Remove me when doing the assignment

}

void freeFrame(int frameNumber)
{
    while (!acquireLock(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE)) {}
    
    *(char *)(PAGEFRAME_MAP_BASE + frameNumber) = (unsigned char)0x0;

    while (!releaseLock(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE)) {}
}


void freeAllFrames(int pid, char *pageFrameMap)
{

    // ASSIGNMENT 3 TO DO

}

unsigned int processFramesUsed(int pid, char *pageFrameMap)
{
    unsigned char lastUsedFrame = PAGEFRAME_AVAILABLE;
    int framesUsed = 0;

    for (int frameNumber = 0; frameNumber < (KERNEL_BASE / PAGE_SIZE); frameNumber++)
    {
        lastUsedFrame = *(char *)(pageFrameMap + frameNumber);

        if (lastUsedFrame == pid)
        {
            framesUsed++;      
        }

    }
    return (unsigned int)framesUsed;

}

unsigned int totalFramesUsed(char *pageFrameMap)
{
    unsigned char lastUsedFrame = PAGEFRAME_AVAILABLE;
    int framesUsed = 0;

    for (int frameNumber = 0; frameNumber < PAGEFRAME_MAP_SIZE; frameNumber++)
    {
        lastUsedFrame = *(char *)(pageFrameMap + frameNumber);

        if (lastUsedFrame != PAGEFRAME_AVAILABLE)
        {
            framesUsed++;
            
        }

    }
    return (unsigned int)framesUsed;

}