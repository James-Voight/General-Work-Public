#include "syscalls.h"
#include "kernel.h"
#include "screen.h"
#include "fs.h"
#include "x86.h"
#include "vm.h"
#include "simpleOSlibc.h"
#include "interrupts.h"
#include "constants.h"
#include "frame-allocator.h"
#include "exceptions.h"
#include "keyboard.h"
#include "file.h"
#include "trap.h"
#include "schedule.h"

void pageFault()
{
    unsigned int cr2Value;
    asm volatile ("movl %0, %%cr2\n\t" : : "r" (cr2Value));

    // CR2 holds the virtual address that caused the page fault.
    // Printing the string representation of decimal value of the virtual address
    // in the panic message.
    strcpy((char*)0x3FFF00, (char*)"Page Fault:           ");
    itoa(cr2Value, (char*)0x3FFF0c);
    disableCursor();
    panic((char*)0x3FFF00);
}

void generalProtectionFault()
{
    disableCursor();
    panic((char*)"General Protection Fault!");
}