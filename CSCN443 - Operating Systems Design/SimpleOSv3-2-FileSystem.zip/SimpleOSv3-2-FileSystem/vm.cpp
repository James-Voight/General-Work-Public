#include "vm.h"
#include "fs.h"
#include "constants.h"
#include "simpleOSlibc.h"
#include "frame-allocator.h"
#include "exceptions.h"
#include "file.h"
#include "screen.h"


void initializePageTables(int pid)
{     

    // ASSIGNMENT 3 TO DO

} 


void fillMemory(char *memLocation, unsigned char byteToFill, int numberOfBytes)
{
    for (int currentByte = 0; currentByte < numberOfBytes; currentByte++)
    {
        *memLocation = byteToFill;
        memLocation++;
    }
}


void contextSwitch(int pid)
{
    int pgdLocation = ((pid - 1) * MAX_PGTABLES_SIZE) + PAGE_DIR_BASE;
    
    asm volatile ("movl %0, %%eax\n\t" : : "r" (pgdLocation));
    asm volatile ("movl %eax, %cr3\n\t");
    asm volatile ("movl %cr0, %ebx\n\t");
    asm volatile ("or $0x80000000, %ebx\n\t");
    asm volatile ("movl %ebx, %cr0\n\t");
}

int initializeTask(int ppid, short state, int stack, char *binaryName, int priority)
{
    while (!acquireLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
    
    int lastUsedPid = 0;
    int nextAvailPid = 0;
    int taskStructNumber = 0;

    if (ppid == 0) { ppid = KERNEL_OWNED; }

    while (nextAvailPid == 0 && taskStructNumber < MAX_PROCESSES)
    {
        lastUsedPid = *(int *)(PROCESS_TABLE_LOC + (TASK_STRUCT_SIZE * taskStructNumber));

        if ((unsigned int)lastUsedPid == 0)
        {
            nextAvailPid = (taskStructNumber + 1);
        }

        if (taskStructNumber == (MAX_PROCESSES - 1))
        {
            while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
            panic((char*)"vm.cpp:initializeTask() -> reached max process number");
        }

        taskStructNumber++;
    }
    
    int physMemStart = (MAX_PROCESS_SIZE * (nextAvailPid - 1));
    int taskStructLocation = PROCESS_TABLE_LOC + (TASK_STRUCT_SIZE * (nextAvailPid - 1));
    int pgd = ((nextAvailPid - 1) * MAX_PGTABLES_SIZE) + PAGE_DIR_BASE;
    
    struct task *Task = (struct task*)taskStructLocation;

    Task->pid = nextAvailPid;
    Task->ppid = ppid;
    Task->state = state;
    Task->pgd = pgd;
    Task->stack = stack;
    Task->physMemStart = physMemStart;
    Task->fileDescriptor[1] = (openFileTableEntry *)(OPEN_FILE_TABLE + (sizeof(openFileTableEntry)));
    Task->nextAvailableFileDescriptor = 3;
    Task->priority = priority;
    Task->runtime = 0;
    Task->binaryName = binaryName;

    while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}

    return nextAvailPid;
}

void updateTaskState(int pid, short state)
{
    while (!acquireLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
    
    int taskStructLocation = PROCESS_TABLE_LOC + (TASK_STRUCT_SIZE * (pid - 1));
    
    struct task *Task = (struct task*)taskStructLocation;
    Task->state = state;

    while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
}

int requestSpecificPage(int pid, char *pageMemoryLocation, char perms)
{

    // ASSIGNMENT 3 TO DO

    return 0; // Remove me when doing the assignment
    
}

char* findBuffer(int pid, int numberOfPages, char perms)
{

    // ASSIGNMENT 3 TO DO

    return 0; // Remove me when doing the assignment

}


char* requestAvailablePage(int pid, char perms)
{
    
    // ASSIGNMENT 3 TO DO

    return 0; // Remove me when doing the assignment
    
}

void freePage(int pid, char *pageToFree)
{
    while (!acquireLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}

    int ptLocation = ((pid - 1) * MAX_PGTABLES_SIZE) + PAGE_TABLE_BASE;
    int pageNumberToFree = (int)pageToFree / PAGE_SIZE;
    int physicalAddressToFree = *(int *)((int)ptLocation + (pageNumberToFree * 4));

    freeFrame((physicalAddressToFree / PAGE_SIZE));
    *(int *)((int)ptLocation + (pageNumberToFree * 4)) = 0x0;

    while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
}

bool acquireLock(int currentPid, char *memoryLocation)
{
    int semaphoreNumber = 0;
    struct semaphore *Semaphore = (struct semaphore*)KERNEL_SEMAPHORE_TABLE;

    while (semaphoreNumber < MAX_SEMAPHORE_OBJECTS)
    {
        if (Semaphore->pid == currentPid && Semaphore->memoryLocationToLock == memoryLocation)
        {
            if (Semaphore->currentValue == 0)
            {
                return false; // Cannot acquire lock
            }
            
            asm volatile ("movl %0, %%ecx\n\t" : : "r" (Semaphore->currentValue - 1));
            asm volatile ("movl %0, %%edx\n\t" : : "r" (&Semaphore->currentValue));
            asm volatile ("xchg %ecx, (%edx)\n\t");
            return true;
        }

        semaphoreNumber++;
        Semaphore++;
    }

    return false;
}

bool releaseLock(int currentPid, char *memoryLocation)
{
    int semaphoreNumber = 0;
    struct semaphore *Semaphore = (struct semaphore*)KERNEL_SEMAPHORE_TABLE;

    while (semaphoreNumber < MAX_SEMAPHORE_OBJECTS)
    {
        if (Semaphore->pid == currentPid && Semaphore->memoryLocationToLock == memoryLocation)
        {
            if (Semaphore->currentValue == Semaphore->maxValue)
            {
                return false; // At max amount
            }
            
            asm volatile ("movl %0, %%ecx\n\t" : : "r" (Semaphore->currentValue + 1));
            asm volatile ("movl %0, %%edx\n\t" : : "r" (&Semaphore->currentValue));
            asm volatile ("xchg %ecx, (%edx)\n\t");
            return true;
        }

        semaphoreNumber++;
        Semaphore++;
    }

    return false;
}

bool createSemaphore(int currentPid, char *memoryLocation, int currentValue, int maxValue)
{
    int semaphoreNumber = 0;
    struct semaphore *Semaphore = (struct semaphore*)KERNEL_SEMAPHORE_TABLE;

    while (semaphoreNumber < MAX_SEMAPHORE_OBJECTS)
    {
        if (Semaphore->pid == 0)
        {
            Semaphore->pid = currentPid;
            Semaphore->memoryLocationToLock = memoryLocation;
            Semaphore->currentValue = currentValue;
            Semaphore->maxValue = maxValue;
            return true;  
        }

        semaphoreNumber++;
        Semaphore++;
    }
    // return false if unable to create
    return false;
}