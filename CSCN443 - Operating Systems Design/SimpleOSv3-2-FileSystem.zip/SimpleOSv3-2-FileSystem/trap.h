/** The function referenced in the interrupt descriptor table when a page fault is detected. */
void pageFault();

/** The function referenced in the interrupt descriptor table when a general protection fault is detected. */
void generalProtectionFault();