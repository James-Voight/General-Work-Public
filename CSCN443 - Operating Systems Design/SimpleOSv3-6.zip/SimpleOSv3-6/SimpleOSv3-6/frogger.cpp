#include "screen.h"
#include "keyboard.h"
#include "vm.h"
#include "simpleOSlibc.h"
#include "constants.h"
#include "x86.h"
#include "file.h"
#include "sound.h"

#define PLAYER_START_ROW 20
#define PLAYER_START_COL 40
#define SCREEN_WIDTH 80
#define SCREEN_HEIGHT 25
#define MAX_OBSTACLES 60
#define MAX_WATER_ROWS 5

// Obstacle types: bush. car, etc
typedef enum { OBSTACLE_BUSH, OBSTACLE_CAR, OBSTACLE_LILYPAD, OBSTACLE_LOG } ObstacleType;


// Player structure
typedef struct {
    int row;
    int col;
    const char* icon;
} Player;

// Obstacle structure
typedef struct {
    int row;
    int col;
    int speed;
    int direction;
    const char* icon;            // string icon: "O", "<=" , "=>"
    ObstacleType type;
} Obstacle;

// Game functions
void microDelay(int ms);
int keyAvailable();
int checkForKeyPress(unsigned char* scanCode);
void drawBorder();
void drawPlayer(const Player* frog);
void erasePlayer(const Player* frog);
void drawObstacles(const Obstacle* obstacles, int count);
void eraseObstacles(const Obstacle* obstacles, int count);
void moveObstacles(Obstacle* obstacles, int count, unsigned int tickCount);
int handleCollision(const Player* frog, const Obstacle* obstacles, int count);
int createLane(Obstacle* obstacles, int count,
                int row, int speed, int direction,
                int tickCount, ObstacleType type);
void addWaterLane(int row, int *waterRows, int *waterRowCount);
bool checkDrowning(Player frog, Obstacle obstacles[], int obstacleCount, int waterRows[], int waterRowCount);
unsigned char getUserInput();
bool drawEndScreen(int win);
bool gameLoop(int level);
int level_select_screen();
void load_level(int level);
void draw_title_screen();

// Create a lane of obstacles
int createLane(Obstacle *obstacles, int max, int count, int row, int speed, int direction, int tick, ObstacleType type) {
    if (count > max) count = max;

    int maxCol = SCREEN_WIDTH - 1;

    for (int i = 0; i < count; i++) {
        obstacles[i].row = row;
        obstacles[i].col = (i * (maxCol / count)) % (maxCol + 1);
        obstacles[i].speed = speed;
        obstacles[i].direction = direction;
        obstacles[i].type = type;

        const char *icon;

        if (type == OBSTACLE_CAR) {
            int pseudoRand = (tick + row + i) % 4;  // Simulates 1 in 4 long cars
            if (pseudoRand == 0) {
                icon = (direction > 0) ? "===>" : "<===";
            } else {
                icon = (direction > 0) ? "=>" : "<=";
            }
        } else if (type == OBSTACLE_BUSH || type == OBSTACLE_LILYPAD) {
            icon = "O";
        } else if (type == OBSTACLE_LOG) {
            icon = "====";
        } else {
            icon = "?";
        }

        obstacles[i].icon = icon;
    }

    return count;
}

void addWaterLane(int row, int *waterRows, int *waterRowCount) {
    if (*waterRowCount < MAX_WATER_ROWS) {
        waterRows[*waterRowCount] = row;
        (*waterRowCount)++;
    }


    for (int col = 0; col < SCREEN_WIDTH; col++) {
        printCharacter(COLOR_LIGHT_BLUE, row, col, "~"); // Light blue background for water
    }
}

bool checkDrowning(Player frog, Obstacle obstacles[], int obstacleCount, int waterRows[], int waterRowCount) {
    bool isWater = false;
    for (int i = 0; i < waterRowCount; i++) {
        if (frog.row == waterRows[i]) {
            isWater = true;
            break;
        }
    }

    if (!isWater) return false;

    for (int i = 0; i < obstacleCount; i++) {
        if ((obstacles[i].type == OBSTACLE_LILYPAD || obstacles[i].type == OBSTACLE_LOG) &&
        frog.row == obstacles[i].row) {
        
            int start = obstacles[i].col;
            int len = strlen((char*)obstacles[i].icon);

            for (int j = 0; j < len; j++) {
                int col = (start + j) % SCREEN_WIDTH;
                if (frog.col == col) {
                    return false; // Safe on log or lilypad
                }
            }
        }
    }

    return true; // In water and not on a lily pad or log
}



// Draw level selection screen
void draw_level_select(int selected) {
    clearScreen();
    printString(COLOR_GREEN, 1, 0,(char *)"      __                        ");
    printString(COLOR_GREEN, 2, 0,(char *)"     |__ .__  _   _.  _.  _  .__");
    printString(COLOR_GREEN, 3, 0,(char *)"     |   |   (_) (_| (_| (/_ |  ");
    printString(COLOR_GREEN, 4, 0,(char *)"                  _)  _)        ");

    const char* levels[] = {"Level 1", "Level 2", "Level 3"};
    for (int i = 0; i < 3; ++i) {
        int y = 10 + i * 2;
        printString(COLOR_WHITE, y, 8, (char *)levels[i]);
    }

    printString(COLOR_WHITE, (10 + ((selected-1) * 2)), 4, "--7"); // Arrow

    printString(COLOR_LIGHT_BLUE, 20, 12, "Use W/S to navigate. Press SPACE to select.");
    printString(COLOR_LIGHT_BLUE, 22, 12, "\tPress 'Q' to return to Title Screen.");
}

// Updated for scan code input
int level_select_screen() {
    int selected = 1;
    draw_level_select(selected);

    while (1) {
        unsigned char key = getUserInput();
        key &= 0x7F; // strip break bit

        if (key == 0x11 && selected > 1) { // W
            selected--;
            draw_level_select(selected);
        } else if (key == 0x1F && selected < 3) { // S
            selected++;
            draw_level_select(selected);
        } else if (key == 0x39) { // SPACE
            return selected;
        } else if (key == 0x10) { // Q
            return 0;  // Sentinel to indicate "go back to title"
        }
    }
}

void microDelay(int ms) {
    for (volatile int i = 0; i < ms * 1000; i++) {
        asm volatile("nop");
    }
}

int keyAvailable() {
    return (inputIOPort(KEYBOARD_STATUS_PORT) & 0x1);
}

int checkForKeyPress(unsigned char* scanCode) {
    if (keyAvailable()) {
        inputIOPort(KEYBOARD_DATA_PORT); // Discard first
        while (!keyAvailable()) {}
        *scanCode = inputIOPort(KEYBOARD_DATA_PORT);
        return 1;
    }
    return 0;
}

void drawBorder() {
    for (int col = 0; col < SCREEN_WIDTH; col++) {
        printCharacter(COLOR_WHITE, 0, col, (char *)"-");
        printCharacter(COLOR_WHITE, SCREEN_HEIGHT - 1, col, (char *)"-");
    }
}

void drawPlayer(Player* frog) {
    printCharacter(COLOR_LIGHT_GREEN, frog->row, frog->col, (char *)frog->icon);
}

void erasePlayer(Player* frog) {
    printCharacter(COLOR_BLACK, frog->row, frog->col, (char *)" ");
}

// Draw obstacles using string icons
void drawObstacles(const Obstacle* obstacles, int count) {
    for (int i = 0; i < count; i++) {
        int color;
        switch (obstacles[i].type) {
            case OBSTACLE_BUSH: color = COLOR_YELLOW; break;
            case OBSTACLE_CAR: color = COLOR_WHITE; break;
            case OBSTACLE_LILYPAD: color = COLOR_GREEN; break;
            case OBSTACLE_LOG: color = COLOR_BROWN; break; // You can use COLOR_LIGHT_RED or similar for brown
            default: color = COLOR_WHITE; break;
        }

        printString(color,
                    obstacles[i].row,
                    obstacles[i].col,
                    (char*)obstacles[i].icon);
    }
}

// Erase only car obstacles by overwriting spaces
void eraseObstacles(const Obstacle* obstacles, int count) {
    for (int i = 0; i < count; i++) {
        if (obstacles[i].type == OBSTACLE_BUSH || obstacles[i].type == OBSTACLE_LILYPAD)
            continue;

        int len = strlen((char*)obstacles[i].icon);
        for (int k = 0; k < len; k++) {
            printCharacter(COLOR_BLACK,
                           obstacles[i].row,
                           obstacles[i].col + k,
                           " ");
        }
    }
}

// Move only cars (bushes are static)
void moveObstacles(Obstacle* obstacles, int count, unsigned int tickCount) {
    for (int i = 0; i < count; i++) {
        if ((obstacles[i].type == OBSTACLE_CAR || obstacles[i].type == OBSTACLE_LOG) &&
            obstacles[i].speed > 0 && (tickCount % obstacles[i].speed) == 0) {
            obstacles[i].col += obstacles[i].direction;
            int len = strlen((char*)obstacles[i].icon);
            if (obstacles[i].col > SCREEN_WIDTH - len) obstacles[i].col = 0;
            if (obstacles[i].col < 0) obstacles[i].col = SCREEN_WIDTH - len;
        }
    }
}


// Check collision and end game on hit
int handleCollision(Player* frog, Obstacle* obstacles, int count) {
    for (int i = 0; i < count; i++) {
        // Skip lilypads and logs - they're safe surfaces
        if (obstacles[i].type == OBSTACLE_LILYPAD ||
            obstacles[i].type == OBSTACLE_LOG) {
            continue;
        }

        int obsLen = strlen((char*)obstacles[i].icon);

        // Check if player's row matches the obstacle's row
        if (frog->row == obstacles[i].row) {
            // Check if player's column is within the range of the obstacle's icon
            if (frog->col >= obstacles[i].col && frog->col < obstacles[i].col + obsLen) {
                return 1;  // Collision detected
            }
        }
    }
    return 0;  // No collision
}

// SCAN CODE–based input
unsigned char getUserInput() {
    unsigned char key = 0;
    while (1) {
        readKeyboard((char *)&key);
        if (key != 0) return key;
    }
}

// Updated for scan code input
bool gameLoop(int level) {
    Player frog = { PLAYER_START_ROW, PLAYER_START_COL, "X" };
    Obstacle obstacles[MAX_OBSTACLES];
    int obstacleCount = 0;
    int waterRows[MAX_WATER_ROWS];
    int waterRowCount = 0;
    unsigned int tickCount = 0;

    clearScreen();

    // Level setup
    if (level == 1) {
        obstacleCount = createLane(obstacles, MAX_OBSTACLES, 12, 12, 0, 0, tickCount, OBSTACLE_BUSH);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 8, 400, -1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 9, 400,  1, tickCount, OBSTACLE_CAR);

    } else if (level == 2) {
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 8, 400, -1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 9, 400,  1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 10, 400, -1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 14, 13, 160, 1, tickCount, OBSTACLE_CAR);

        // Add lilypads to row 6 (stationary)
        obstacleCount += createLane(obstacles + obstacleCount,
                                    MAX_OBSTACLES - obstacleCount,
                                    5,    // count
                                    7,    // row
                                    0,    // speed (0 = static)
                                    0,    // direction (no movement)
                                    tickCount,
                                    OBSTACLE_LILYPAD);
        
        obstacleCount += createLane(obstacles + obstacleCount, MAX_OBSTACLES - obstacleCount, 14, 11, 0, 0, tickCount, OBSTACLE_BUSH);
        obstacleCount += createLane(obstacles + obstacleCount, MAX_OBSTACLES - obstacleCount, 14, 12, 0, 0, tickCount, OBSTACLE_BUSH);

        // Set water rows
        waterRowCount = 0;
        waterRows[waterRowCount++] = 7;
    } else {
        obstacleCount += createLane(obstacles, 6, 12, 7, 160, 1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 8, 400, -1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 9, 450, -1, tickCount, OBSTACLE_CAR);

        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 11, 400, 1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 12, 400, -1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 13, 400, -1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 5, 12, 14, 400, 1, tickCount, OBSTACLE_CAR);
        obstacleCount += createLane(obstacles + obstacleCount, 12, 12, 15, 0, 0, tickCount, OBSTACLE_BUSH);

        // Add logs to row 5 and 4
        obstacleCount += createLane(obstacles + obstacleCount,
                                    MAX_OBSTACLES - obstacleCount,
                                    3,    // count
                                    5,    // row
                                    500,    // speed (ticks between moves)
                                    -1,   // direction (left)
                                    tickCount,
                                    OBSTACLE_LOG);
        obstacleCount += createLane(obstacles + obstacleCount,
                                    MAX_OBSTACLES - obstacleCount,
                                    3,    // count
                                    4,    // row
                                    500,    // speed (ticks between moves)
                                    1,   // direction (left)
                                    tickCount,
                                    OBSTACLE_LOG);

        // Add lilypads to row 6 (stationary)
        obstacleCount += createLane(obstacles + obstacleCount,
                                    MAX_OBSTACLES - obstacleCount,
                                    3,    // count
                                    6,    // row
                                    0,    // speed (0 = static)
                                    0,    // direction (no movement)
                                    tickCount,
                                    OBSTACLE_LILYPAD);

        // Set water rows
        waterRowCount = 0;
        waterRows[waterRowCount++] = 4;
        waterRows[waterRowCount++] = 5;
        waterRows[waterRowCount++] = 6;
    }

    drawBorder();
    drawPlayer(&frog);
    drawObstacles(obstacles, obstacleCount);

    // Cooldown vars
    unsigned char lastKey = 0;
    unsigned int lastKeyTick = 0;
    const unsigned int inputCooldown = 5; // adjust as needed

    while (1) {
        unsigned char scan = 0;
        int keyPressed = checkForKeyPress(&scan);
        int moved = 0;

        if (keyPressed) {
            unsigned char key = scan & 0x7F;

            // Check cooldown logic
            if (key != lastKey || tickCount - lastKeyTick >= inputCooldown) {
                erasePlayer(&frog);
                if (key == 0x11 && frog.row > 1) { frog.row--; moved = 1; }
                if (key == 0x1F && frog.row < SCREEN_HEIGHT - 2) { frog.row++; moved = 1; }
                if (key == 0x1E && frog.col > 1) { frog.col--; moved = 1; }
                if (key == 0x20 && frog.col < SCREEN_WIDTH - 2) { frog.col++; moved = 1; }
                if (key == 0x10) break;
                if (moved) {
                    lastKey = key;
                    lastKeyTick = tickCount;
                }
                drawPlayer(&frog);
            }
        }

        // Game logic advances every tick, not just on keypress
        eraseObstacles(obstacles, obstacleCount);
        moveObstacles(obstacles, obstacleCount, tickCount);

        // Draw water lanes only where there is no log
        for (int i = 0; i < waterRowCount; i++) {
            int row = waterRows[i];
            for (int col = 0; col < SCREEN_WIDTH; col++) {
                int hasLog = 0;
                for (int j = 0; j < obstacleCount; j++) {
                    if (obstacles[j].type == OBSTACLE_LOG &&
                        obstacles[j].row == row) {
                        int logLen = strlen((char*)obstacles[j].icon);
                        if (col >= obstacles[j].col && col < obstacles[j].col + logLen) {
                            hasLog = 1;
                            break;
                        }
                    }
                }

                if (!hasLog) {
                    printCharacter(COLOR_LIGHT_BLUE, row, col, "~");
                }
            }
        }

        drawObstacles(obstacles, obstacleCount);
        drawPlayer(&frog);

             // Carry the frog only when its log has just moved
        for (int i = 0; i < obstacleCount; i++) {
            if (obstacles[i].type == OBSTACLE_LOG &&
                frog.row == obstacles[i].row &&
                obstacles[i].speed > 0 &&
                (tickCount % obstacles[i].speed) == 0 &&
                frog.col >= obstacles[i].col - 1 &&
                frog.col <= obstacles[i].col + strlen((char*)obstacles[i].icon)) 
            {
                // log is under the frog and has just shifted this tick
                erasePlayer(&frog);

                if (obstacles[i].direction > 0) { // moving RIGHT
                    frog.col++;
                    if (frog.col >= SCREEN_WIDTH) frog.col = 0;
                } else {                          // moving LEFT
                    frog.col--;
                    if (frog.col < 0) frog.col = SCREEN_WIDTH - 1;
                }

                drawPlayer(&frog);
                break;
            }
        }


        // Check collisions/drowning every frame
        if (checkDrowning(frog, obstacles, obstacleCount, waterRows, waterRowCount)) {
            return 0;
        }

        if (handleCollision(&frog, obstacles, obstacleCount)) {
            return 0;
        }

        // Win condition check
        if (frog.row == 1) return 1;

        // Increment tick counter and delay
        tickCount++;
        microDelay(50);  // Maintain consistent frame rate
    }
}

// Level loading logic (customize per level)
void load_level(int level) {
    if (level == 1) {
        printString(COLOR_LIGHT_BLUE, 18, 5, "Loading Level 1...");
    } else if (level == 2) {
        printString(COLOR_LIGHT_BLUE, 18, 5, "Loading Level 2...");
    } else {
        printString(COLOR_LIGHT_BLUE, 18, 5, "Loading Level 3...");
    }
    wait(2);

    makeSound(500, 10);
    makeSound(400, 5);
    makeSound(300, 5);
}

void draw_title_screen() {
    clearScreen();

    printString(COLOR_GREEN, 2, 0,  (char *)"                ______ ____   ____   ______ ______ ______ ____ ");
    printString(COLOR_GREEN, 3, 0,  (char *)"               / ____// __ \\ / __ \\ / ____// ____// ____// __ \\");
    printString(COLOR_GREEN, 4, 0, (char *)"              / /_   / /_/ // / / // / __ / / __ / __/  / /_/ /");
    printString(COLOR_GREEN, 5, 0, (char *)"             / __/  / _, _// /_/ // /_/ // /_/ // /___ / _, _/ ");
    printString(COLOR_GREEN, 6, 0, (char *)"            /_/    /_/ |_| \\____/ \\____/ \\____//_____//_/ |_|  ");

    
    printString(COLOR_WHITE, 18, 18, "Press 'S' to Start the Game or 'Q' to Quit.");
}

// Draw end screen: win=1 for You Win!, win=0 for Game Over
bool drawEndScreen(int win) {
    clearScreen();
    if (win) {

        printString(COLOR_YELLOW, 8, 0,  (char *)"    _             _  _  _  _  _           _    ");
        printString(COLOR_YELLOW, 9, 0,  (char *)"   (_)           (_)(_)(_)(_)(_) _       (_)   ");
        printString(COLOR_YELLOW, 10, 0,  (char *)"   (_)           (_)   (_)   (_)(_)_     (_)   ");
        printString(COLOR_YELLOW, 11, 0,  (char *)"   (_)     _     (_)   (_)   (_)  (_)_   (_)   ");
        printString(COLOR_YELLOW, 12, 0,  (char *)"   (_)   _(_)_   (_)   (_)   (_)    (_)_ (_)   ");
        printString(COLOR_YELLOW, 13, 0,  (char *)"   (_)  (_) (_)  (_)   (_)   (_)      (_)(_)   ");
        printString(COLOR_YELLOW, 14, 0,  (char *)"   (_)_(_)   (_)_(_) _ (_) _ (_)         (_)   ");
        printString(COLOR_YELLOW, 15, 0,  (char *)"     (_)       (_)  (_)(_)(_)(_)         (_)   ");

        printString(COLOR_YELLOW, 2, 50,  (char *)"          o  o   o  o");
        printString(COLOR_YELLOW, 3, 50,  (char *)"          |\\/ \\^/ \\/|");
        printString(COLOR_YELLOW, 4, 50,  (char *)"          |,-------.|");
        printString(COLOR_GREEN, 5, 50,  (char *)"        ,-.(|)   (|),-.");
        printString(COLOR_GREEN, 6, 50,  (char *)"        \\_*._ ' '_.* _/");
        printString(COLOR_GREEN, 7, 50,  (char *)"         /`-.`--' .-'\\");
        printString(COLOR_GREEN, 8, 50,  (char *)"    ,--./    `---'    \\,--.");
        printString(COLOR_GREEN, 9, 50,  (char *)"    \\   |(  )     (  )|   /");
        printString(COLOR_GREEN, 10, 50,  (char *)"     \\  | ||       || |  /");
        printString(COLOR_GREEN, 11, 50,  (char *)"      \\ | /|\\     /|\\ | /");
        printString(COLOR_GREEN, 12, 50,  (char *)"      /  \\-._     _,-/  \\");
        printString(COLOR_GREEN, 13, 50,  (char *)"     //| \\  `---'  // |\\");
        printString(COLOR_GREEN, 14, 50,  (char *)"    /,-.,-.\\       /,-.,-.\\");
        printString(COLOR_GREEN, 15, 50,  (char *)"   o   o   o      o   o    o");
        makeSound(500, 10);
    } else {
        printString(COLOR_RED, 8, 0,  (char *)"         ____    _    __  __ _____    _____     _______ ____  ");
        printString(COLOR_RED, 9, 0,  (char *)"        / ___|  / \\  |  \\/  | ____|  / _ \\ \\   / / ____|  _ \\ ");
        printString(COLOR_RED, 10, 0,  (char *)"       | |  _  / _ \\ | |\\/| |  _|   | | | \\ \\ / /|  _| | |_) |");
        printString(COLOR_RED, 11, 0,  (char *)"       | |_| |/ ___ \\| |  | | |___  | |_| |\\ V / | |___|  _ < ");
        printString(COLOR_RED, 12, 0,  (char *)"        \\____/_/   \\_\\_|  |_|_____|  \\___/  \\_/  |_____|_| \\_\\");

        makeSound(200, 5);
    }
    printString(COLOR_WHITE, 20, SCREEN_WIDTH/2 - 12, "Press 'S' to Restart or 'Q' to Quit.");
    unsigned char key;
    while (1) {
        readKeyboard((char*)&key);
        key &= 0x7F;
        if (key == 0x1F) { // 'S'
            return false;        // back to gameLoop
        }
        if (key == 0x10) { // 'Q'
            clearScreen();
            // systemSwitchToParent();
            return true;
        }
    }
}


void main() {
    // unsigned char myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    disableCursor();
    clearScreen();

    draw_title_screen();

    unsigned char key = 0;
    while (true) {
        readKeyboard((char *)&key);
        key &= 0x7F;
        if (key == 0x1F) break; // 'S' scan code
        if (key == 0x10) {
            clearScreen();
            systemSwitchToParent(); //exit frogger
            main();
        }
    }

    int level = level_select_screen();

    if (level == 0) main();

    load_level(level);
    if (gameLoop(level)) {
        if (drawEndScreen(1) == true) {
            systemSwitchToParent();
            main();
        } else {
            main();
        }
    } else {
        if (drawEndScreen(0) == true) {
            systemSwitchToParent();
            main();
        } else {
            main();
        }
    }

    clearScreen();

    main();
}
