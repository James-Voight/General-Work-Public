// ELF header and Program Headers modified from:
// https://refspecs.linuxfoundation.org/elf/gabi4+/ch4.eheader.html
// https://refspecs.linuxfoundation.org/elf/gabi4+/ch5.pheader.html
//
// https://www.nongnu.org/ext2-doc/ext2.html#inode-table
// https://wiki.osdev.org/Ext2#Inode_Type_and_Permissions

/**
 * The ELF Header structure.
 */
struct elfHeader{
    char e_ident[16];
    short e_type;
    short e_machine;
    int e_version;
    /**Entry point for the initial entry jump. */
    int e_entry; 
    /** Program header offset. */
    int e_phoff;    
    int e_shoff;
    int e_flags;
    short e_ehsize;
    short e_phentsize;
    /** Number of program headers. */
    short e_phnum;    
    short e_shentsize;
    short e_shnum;
    short e_shstrndx;
};

/**
 * Program Header structure.
 */
struct pHeader {
  int p_type;
  int p_offset;
  int p_vaddr;
  int p_paddr;
  int p_filesz;
  int p_memsz;
  int p_flags;
  int p_align;
};

/**
 * The EXT2 Superblock structure.
 */
struct ext2SuperBlock {
  int sb_total_inodes;
  int sb_total_blocks;
  int sb_reserved_blocks;
  int sb_total_unallocated_blocks;
  int sb_total_unallocated_inodes;
  int sb_superblock_block_number;
  int sb_block_size;
  int sb_fragment_size;
  int sb_blocks_per_block_group;
  int sb_fragements_per_block_group;
  int sb_inodes_per_block_group;
  int sb_lastmount_time;
  int sb_lastwritten_time;
  short sb_times_mounted_since_consistency_check;
  short sb_mounts_allows_before_consistency_check;
  short sb_ext2_signature;
  short sb_filesystem_state;
  short sb_error_detection;
  short sb_minor_version;
  int sb_last_consistency_check_time;
  int sb_interval_time;
  int sb_operating_system_id;
  int sb_major_version;
  short sb_userid_for_reserved_blocks;
  short sb_groupid_for_reserved_blocks;
  int sb_first_nonreserved_inode;
  short sb_size_of_inode;
  short sb_block_group_of_superblock;
  int sb_optional_features;
  int sb_required_features;
  char sb_filesystem_id[16];
  char sb_volume_name[16];
  char sb_path_was_last_mounted_to[64];
  int sb_compression_algorithm;
  char sb_number_of_block_to_preallocate_for_files;
  char sb_number_of_block_to_preallocate_for_directories;
  short sb_not_used;
  char sb_journal_id[16];
  int sb_journal_inode;
  int sb_journal_device;
  int sb_head_of_orphan_inode_list;
  // The rest of bytes up to 1023 not used  
};

/**
 * The EXT2 Block Group Descriptor structure.
 */
struct blockGroupDescriptor {
  int bgd_block_address_of_block_usage;
  int bgd_block_address_of_inode_usage;
  int bgd_starting_block_of_inode_table;
  short bgd_number_of_unallocated_blocks_in_group;
  short bgd_number_of_unallocated_inodes_in_group;
  short bgd_number_directories_in_group;
  char bgd_not_used[14];
};

/**
 * The Inode structure.
 */
struct inode {
  short i_mode;
  short i_uid;
  int i_size;
  int i_atime;
  int i_ctime;
  int i_mtime;
  int i_dtime;
  short i_gid;
  short i_links_count;
  int i_blocks;
  int i_flags;
  int i_osd1;
  /** The first 12 blocks are direct blocks, 13 is the first indirect block. */
  int i_block[15]; 
  int i_generation;
  int i_file_acl;
  int i_dir_acl;
  int i_faddr;
  int i_osd2[3];
};

/**
 * The Directory Entry structure.
 */
struct directoryEntry {
  unsigned int directoryInode;
  unsigned short recLength;
  unsigned char nameLength;
  unsigned char fileType;
  char *fileName;
};

/**
 * Checks hard disk status and loops again if not ready.
 */
void diskStatusCheck();

/**
 * Reads a 512-byte sector using LBA format and writes it to the destination memory.
 * \param sectorNumber The sector to read in LBA format.
 * \param destinationMemory The pointer to the destination memory to write the sector.
 */
void diskReadSector(int sectorNumber, char *destinationMemory);

/**
 * Writes 512 bytes of memory to a disk sector. The opposite of diskReadSector(). 
 * \param sectorNumber The sector to write to in LBA format.
 * \param sourceMemory The starting memory address of the 512 bytes to write to the sector.
 */
void diskWriteSector(int sectorNumber, char *sourceMemory);

/**
 * Reads an EXT2 block number and writes 1024 bytes of the block to the destination memory address.
 * \param blockNumber This is the EXT2 block number, not the disk LBA sector. 
 * \param destinationMemory The pointer to the destination memory to write the block.
 */
void readBlock(int blockNumber, char *destinationMemory);

/**
 * Writes 1024 bytes of memory to an EXT2 block number. The opposite of readBlock(). 
 * \param blockNumber This is the EXT2 block number, not the disk LBA sector. 
 * \param sourceMemory This is the starting pointing to write 1024 bytes to the EXT2 block.
 */
void writeBlock(int blockNumber, char *sourceMemory);

/** Finds a free block and returns the block number. */
unsigned int allocateFreeBlock();

/** Returns the next available block number without actually allocating it. */
unsigned int readNextAvailableBlock();

/** Returns the total blocks used on the file system. */
unsigned int readTotalBlocksUsed();

/** Frees a block given a block number.
 * \param blockNumber The block to free.
 */
void freeBlock(unsigned int blockNumber);

/** Frees all blocks associated with an inode.
 * \param inodeStructMemory A pointer to an inode structure for that file.
 */
void freeAllBlocks(char *inodeStructMemory);

/** Deletes a file.
 * \param fileName The file name of the file you want to delete.
 * \param currentPid The pid of the process requesting the delete.
 */
void deleteFile(char *fileName, int currentPid);

/** Allocates a free inode and returns the inode number. */
unsigned int allocateInode();

/** Returns the next available inode number without actually allocating it. */
unsigned int readNextAvailableInode();

/** Deletes the directory entry associated with a file.
 * \param fileName The file name you wish to delete from the directory listing.
 */
void deleteDirectoryEntry(char *fileName);

/** Creates a new file based on an open buffer/file descriptor.
 * \param fileName The name you'd like the new file to be called.
 * \param currentPid The pid of the process requesting the new file.
 * \param fileDescriptor The file descriptor that serves as the basis for the new file's contents.
 */
void createFile(char *fileName, int currentPid, int fileDescriptor);

/** Creates an inode entry on the disk.
 * \param inodeEntry The inode associated with the file you wish to write.
 * \param mode The EXT2 mode value for the permissions/file type, etc.
 * \param openFile The pointer to the open file table entry associated with the buffer/file descriptor.
 */
void writeInodeEntry(unsigned int inodeEntry, unsigned short mode, char* openFile);

/** Given a file name and inode entry, writes the buffer to disk.
 * \param openFile The pointer to the open file table entry associated with the buffer/file descriptor.
 * \param inodeEntry The inode associated with the file.
 */
void writeBufferToDisk(char* openFile, unsigned int inodeEntry);

/**
 * Checks to see if a file name exists in the current directory of the file system. If found, stores the inode to the destinationMemory location.
 * \param fileName The string value of the file you are looking for.
 * \param destinationMemory Stores the inode of the file at this location if found. This value is typically USER_TEMP_INODE_LOC.
 */
bool fsFindFile(char *fileName, char *destinationMemory);

/**
 * Returns the Inode number of a file given its name.
 * \param fileName The string value of the file you are looking for.
 */
int returnInodeofFileName(char *fileName);

/**
 * Parses an ELF header at a given address and loads the text and data sections to their preferred loading locations based on the ELF header and parsing the program headers.
 * \param elfHeaderLocation The pointer to the ELF header.
 */
void loadElfFile(char *elfHeaderLocation);

/**
 * Given a pointer to an Inode structure, load all the EXT2 blocks associated with that file to the fileBuffer parameter.
 * \param inodeStructMemory The pointer to the Inode structure. This value is typically USER_TEMP_INODE_LOC.
 * \param fileBuffer The pointer to the location where you want the blocks loaded. This value is typically USER_TEMP_FILE_LOC.
 */
void loadFileFromInodeStruct(char *inodeStructMemory, char *fileBuffer);