/** The main scheduler and dispatch function.
 * \param currentPid The pid at the time of the interrupt (which also runs the scheduler).
 */
void scheduler(int currentPid);