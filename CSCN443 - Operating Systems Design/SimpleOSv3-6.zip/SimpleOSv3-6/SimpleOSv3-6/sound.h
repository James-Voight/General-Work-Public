/**
 *  Simple API to allow users to set the frequency (in Hz) and duration (in number of interrupts) for sound.
 */
struct soundParameter
{
    /** The frequency in Hz. */
    int frequency; 
    /** The duration in counts of interrupts. */
    int duration;
};


/**
 * This will generate a tone for one interrupt. You should not call this directly. Call makeSound() in SimpleOSLibc instead.
 * \param frequency The frequency in Hz.
 */
void generateTone(int frequency);

/**
 * This will stop a tone that is already playing. You should not call this directly. Call makeSound() in SimpleOSLibc instead.
 */
void stopTone();