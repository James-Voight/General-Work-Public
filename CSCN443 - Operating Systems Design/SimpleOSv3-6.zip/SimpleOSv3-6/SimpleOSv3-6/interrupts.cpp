#include "interrupts.h"
#include "syscalls.h"
#include "x86.h"
#include "constants.h"
#include "trap.h"

// https://wiki.osdev.org/Interrupts
// https://wiki.osdev.org/GDT_Tutorial
// https://wiki.osdev.org/PIC#Programming_the_PIC_chips
// https://wiki.osdev.org/Interrupt_Service_Routines
// https://wiki.osdev.org/Interrupt_Descriptor_Table

void enableInterrupts()
{
    asm volatile ("sti\n\t");
}

void disableInterrupts()
{
    asm volatile ("cli\n\t");
}

void remapPIC(unsigned char masterPICMask, unsigned char slavePICMask)
{
    // This will remap IRQs 0x0 -> 0xF to 0x20 -> 0x2F
    // This is due to a conflict with Intel CPU exceptions
    outputIOPort(MASTER_PIC_COMMAND_PORT, 0x11); // start initialization (cascade mode)
    outputIOPort(SLAVE_PIC_COMMAND_PORT, 0x11);// start initialization (cascade mode)
    outputIOPort(MASTER_PIC_DATA_PORT, 0x20); // offset value of new interrupts
    outputIOPort(SLAVE_PIC_DATA_PORT, 0x28); // offset values of new interrupts
    outputIOPort(MASTER_PIC_DATA_PORT, 0x04); // tell master PIC that there is a slave PIC at IRQ2 (0000 0100)
    outputIOPort(SLAVE_PIC_DATA_PORT, 0x02); // tell slave PIC its cascade identity (0000 0010)
    outputIOPort(MASTER_PIC_DATA_PORT, 0x01); // 8086/88 (MCS-80/85) mode
    outputIOPort(SLAVE_PIC_DATA_PORT, 0x01); // 8086/88 (MCS-80/85) mode
    outputIOPort(MASTER_PIC_DATA_PORT, masterPICMask);
    outputIOPort(SLAVE_PIC_DATA_PORT, slavePICMask);

}

void loadIDT(char *idtMemory)
{  
    int x = 0;

    for (x=0; x < 13; x++)
    {
        *(short *)idtMemory = ((int)(&systemInterruptHandler) & 0xffff); //lsbOffset ->trigger clear screen? 80986
        *(short *)(idtMemory + 2) = (unsigned char)0x8; //selector
        *(idtMemory + 4) = (unsigned char)0x00; //reserved
        *(idtMemory + 5) = (unsigned char)0xee; //attributes (was 0x8e)
        *(short *)(idtMemory + 6) = ((int)(&systemInterruptHandler) >> 16);

        idtMemory = idtMemory + 8;
        
    }

    *(short *)idtMemory = ((int)(&generalProtectionFault) & 0xffff); //lsbOffset ->trigger clear screen? 80986
    *(short *)(idtMemory + 2) = (unsigned char)0x8; //selector
    *(idtMemory + 4) = (unsigned char)0x00; //reserved
    *(idtMemory + 5) = (unsigned char)0xee; //attributes (was 0x8e)
    *(short *)(idtMemory + 6) = ((int)(&generalProtectionFault) >> 16);

    idtMemory = idtMemory + 8;

    *(short *)idtMemory = ((int)(&pageFault) & 0xffff); //lsbOffset ->trigger clear screen? 80986
    *(short *)(idtMemory + 2) = (unsigned char)0x8; //selector
    *(idtMemory + 4) = (unsigned char)0x00; //reserved
    *(idtMemory + 5) = (unsigned char)0xee; //attributes (was 0x8e)
    *(short *)(idtMemory + 6) = ((int)(&pageFault) >> 16);

    idtMemory = idtMemory + 8;


    for (x=15; x < 128; x++)
    {
        *(short *)idtMemory = ((int)(&systemInterruptHandler) & 0xffff); //lsbOffset ->trigger clear screen? 80986
        *(short *)(idtMemory + 2) = (unsigned char)0x8; //selector
        *(idtMemory + 4) = (unsigned char)0x00; //reserved
        *(idtMemory + 5) = (unsigned char)0xee; //attributes (was 0x8e)
        *(short *)(idtMemory + 6) = ((int)(&systemInterruptHandler) >> 16);

        idtMemory = idtMemory + 8;
        
    }

    // This is the interrupt handler for INT 0x80 (which is the 128th handler)
    *(short *)idtMemory = ((int)(&syscallHandler) & 0xffff); //lsbOffset ->trigger clear screen? 80986
    *(short *)(idtMemory + 2) = (unsigned char)0x8; //selector
    *(idtMemory + 4) = (unsigned char)0x00; //reserved
    *(idtMemory + 5) = (unsigned char)0xee; //attributes (was 0x8e)
    *(short *)(idtMemory + 6) = ((int)(&syscallHandler) >> 16);

    idtMemory = idtMemory + 8;


    for (x=129; x < 256; x++)
    {
        *(short *)idtMemory = ((int)(&systemInterruptHandler) & 0xffff); //lsbOffset ->trigger clear screen? 80986
        *(short *)(idtMemory + 2) = (unsigned char)0x8; //selector
        *(idtMemory + 4) = (unsigned char)0x00; //reserved
        *(idtMemory + 5) = (unsigned char)0xee; //attributes (was 0x8e)
        *(short *)(idtMemory + 6) = ((int)(&systemInterruptHandler) >> 16);

        idtMemory = idtMemory + 8;
    }

}

void loadIDTR(char *idtMemory, char *idtrMemory)
{
    *idtrMemory = (unsigned char)0x00; 
    *(idtrMemory + 1) = (unsigned char)0x8; //0x800 in length
    *(idtrMemory + 2) = (unsigned char)0x00; 
    *(idtrMemory + 3) = (int)idtMemory >> 8; 
    *(idtrMemory + 4) = (int)idtMemory >> 16; 

    asm volatile ("lidt (%0)\n\t" : : "r" (idtrMemory));

}

void setSystemTimer(int frequency)
{
    unsigned int divisor = PIT_FREQUENCY / frequency;
    outputIOPort(PIT_COMMAND_PORT, 0x36);
    outputIOPort(PIT_COUNTER_1, (unsigned char)(divisor & 0xFF));
    outputIOPort(PIT_COUNTER_1, (unsigned char)((divisor >> 8) & 0xFF));
}

void switchToRing3LaunchBinary(char *binaryEntryAddress)
{
    asm volatile ("movl $0x23, %eax\n\t"); //this is the ring 3 data segment (requesting DPL=3)
    asm volatile ("mov %ax, %ds\n\t");
    asm volatile ("mov %ax, %es\n\t");
    asm volatile ("mov %ax, %fs\n\t");
    asm volatile ("mov %ax, %gs\n\t");
    asm volatile ("movl %esp, %eax\n\t");
    asm volatile ("pushl $0x23\n\t");
    asm volatile ("pushl $0x2FEFF0\n\t");
    asm volatile ("pushf\n\t");
    asm volatile ("pushl $0x1b\n\t"); //this is the ring 3 code segment
    asm volatile ("movl %0, %%eax\n\t" : : "r" ((unsigned int)(binaryEntryAddress)));
    asm volatile ("pushl %eax\n\t");
    asm volatile ("sti\n\t");

    asm volatile ("iret\n\t");
}