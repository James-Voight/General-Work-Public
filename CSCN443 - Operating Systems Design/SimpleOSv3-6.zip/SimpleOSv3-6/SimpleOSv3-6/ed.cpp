#include "screen.h"
#include "keyboard.h"
#include "vm.h"
#include "simpleOSlibc.h"
#include "constants.h"
#include "x86.h"
#include "file.h"

void printPrompt(unsigned char myPid)
{   
    char *shellHorizontalLine = malloc(myPid, sizeof(char));
    *shellHorizontalLine = ASCII_HORIZONTAL_LINE;
    for (int columnPos = 0; columnPos < 80; columnPos++)
    {
        printString(COLOR_LIGHT_BLUE, 18, columnPos, shellHorizontalLine);
    }

    free(shellHorizontalLine);

    printString(COLOR_GREEN, 18, 3, (char *)"Simple Editor v0.1");
    printString(COLOR_RED, 19, 2, (char *)"#");
    printString(COLOR_GREEN, 18, 62, (char *)"Current PID: ");
    printHexNumber(COLOR_GREEN, 18, 75, (unsigned char)myPid);

}

void printBufferToScreen(char *userSpaceBuffer)
{
    int linearPosition = 0;
    
    if (userSpaceBuffer == 0x0)
    {
        printString(COLOR_RED, 21, 3,(char *)"No such buffer!");
        return; //null pointer
    }
    
    
    int row = 0;
    int column = 0;

    while (row <= 15)
    {
        if (column > 79) { column = 0; row++; }
        if (*(char *)((int)userSpaceBuffer + linearPosition) == (unsigned char)0x0a) { row++; column=0; }
        if (*(char *)((int)userSpaceBuffer + linearPosition) == (unsigned char)0x0d) { column++; }
        if (*(char *)((int)userSpaceBuffer + linearPosition) == (unsigned char)0x09) { column=column+4; }

        if (row <= 15)
        {
            printCharacter(COLOR_WHITE, row, column, (char *)((int)userSpaceBuffer + linearPosition));
        }

        column++;
        linearPosition++;
    }

}

void screenEditor(int myPid, int currentFileDescriptor)
{
    int row = 0;
    int column = 0;
    int rowBasedOnBuffer = 0;
    int columnBasedOnBuffer = 0;
    struct openBufferTable *openBufferTable = (struct openBufferTable*)OPEN_BUFFER_TABLE;

    int bufferPosition = (int)(char *)openBufferTable->buffers[currentFileDescriptor];
    int bufferPositionStart = bufferPosition;

    char *bufferPositionMem = malloc(myPid, sizeof(char *));
    char *rowPositionMem = malloc(myPid, sizeof(char *));
    char *columnPositionMem = malloc(myPid, sizeof(char *));

    while ((unsigned char)*(char *)KEYBOARD_BUFFER != 0x81) //esc
    {       
        moveCursor(row + rowBasedOnBuffer, column + columnBasedOnBuffer);

        readKeyboard((char *)KEYBOARD_BUFFER);

        if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x90) {
            *(char*)bufferPosition = 0x71;
            bufferPosition++;
            } //q
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x91) {
             *(char*)bufferPosition = 0x77;
             bufferPosition++;
             } //w
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x92) {
            *(char*)bufferPosition = 0x65;
            bufferPosition++;
            } //e
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x93) {
            *(char*)bufferPosition = 0x72;
            bufferPosition++;
            } //r
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x94) {
            *(char*)bufferPosition = 0x74;
            bufferPosition++;
            } //t
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x95) {
            *(char*)bufferPosition = 0x79;
            bufferPosition++;
            } //y
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x96) {
            *(char*)bufferPosition = 0x75;
            bufferPosition++;
            } //u
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x97) {
            *(char*)bufferPosition = 0x69;
            bufferPosition++;
            } //i
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x98) {
            *(char*)bufferPosition = 0x6f;
            bufferPosition++;
            } //o
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x99) {
            *(char*)bufferPosition = 0x70;
            bufferPosition++;
            } //p
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x9e) {
            *(char*)bufferPosition = 0x61;
            bufferPosition++;
            } //a
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x9f) {
            *(char*)bufferPosition = 0x73;
            bufferPosition++;
            } //s
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xa0) {
            *(char*)bufferPosition = 0x64;
            bufferPosition++;
            } //d
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xa1) {
            *(char*)bufferPosition = 0x66;
            bufferPosition++;
            } //f
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xa2) {
            *(char*)bufferPosition = 0x67;
            bufferPosition++;
            } //g
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xa3) {
            *(char*)bufferPosition = 0x68;
            bufferPosition++;
            } //h
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xa4) {
            *(char*)bufferPosition = 0x6a;
            bufferPosition++;
            } //j
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xa5) {
            *(char*)bufferPosition = 0x6b;
            bufferPosition++;
            } //k
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xa6) {
            *(char*)bufferPosition = 0x6c;
            bufferPosition++;
            } //l
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xac) {
            *(char*)bufferPosition = 0x7a;
            bufferPosition++;
            } //z
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xad) {
            *(char*)bufferPosition = 0x78;
            bufferPosition++;
            } //x
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xae) {
            *(char*)bufferPosition = 0x63;
            bufferPosition++;
            } //c
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xaf) {
            *(char*)bufferPosition = 0x76;
            bufferPosition++;
            } //v
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xb0) {
            *(char*)bufferPosition = 0x62;
            bufferPosition++;
            } //b
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xb1) {
            *(char*)bufferPosition = 0x6e;
            bufferPosition++;
            } //n
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xb2) {
            *(char*)bufferPosition = 0x6d;
            bufferPosition++;
            } //m
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x82) {
            *(char*)bufferPosition = 0x31;
            bufferPosition++;
            } //1
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x83) {
            *(char*)bufferPosition = 0x32;
            bufferPosition++;
            } //2
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x84) {
            *(char*)bufferPosition = 0x33;
            bufferPosition++;
            } //3
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x85) {
            *(char*)bufferPosition = 0x34;
            bufferPosition++;
            } //4
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x86) {
            *(char*)bufferPosition = 0x35;
            bufferPosition++;
            } //5
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x87) {
            *(char*)bufferPosition = 0x36;
            bufferPosition++;
            } //6
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x88) {
            *(char*)bufferPosition = 0x37;
            bufferPosition++;
            } //7
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x89) {
            *(char*)bufferPosition = 0x38;
            bufferPosition++;
            } //8
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x8a) {
            *(char*)bufferPosition = 0x39;
            bufferPosition++;
            } //9
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x8b) {
            *(char*)bufferPosition = 0x30;
            bufferPosition++;
            } //0
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x9c) {
            //*(char*)bufferPosition = 0x0a;
            //bufferPosition++;
            } // enter
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xb9) {
            *(char*)bufferPosition = 0x20;
            bufferPosition++;
            } // space
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0xb4) {
            *(char*)bufferPosition = 0x2e;
            bufferPosition++;
            } // period
        else if ((unsigned char)(*(char *)KEYBOARD_BUFFER) == (unsigned char)0x8e) {
            *(char*)bufferPosition = 0x20;

            if (bufferPosition <= bufferPositionStart)
            {
                bufferPosition = bufferPositionStart;
            }
            else
            {
                bufferPosition--;
            }
            } // backspace

        
        rowBasedOnBuffer = (bufferPosition - bufferPositionStart) / 80;
        columnBasedOnBuffer = (bufferPosition - bufferPositionStart) % 80;

        if ( (unsigned char)*(char *)KEYBOARD_BUFFER == 0xCD ) //right
        { 
            if (column >= 79)
            {
                column = 0;
                row++;
            }
            else
            {
                column++;
            } 
        }
        else if ( (unsigned char)*(char *)KEYBOARD_BUFFER == 0xCB ) //left
        { 
            if (column <= 0)
            {
                if (row == 0)
                {
                    row = 0;
                    column = 0;
                }
                else
                {
                    column = 79;
                    row--;
                }
            }
            else
            {
                column--;
            }

        }
        else if ( (unsigned char)*(char *)KEYBOARD_BUFFER == 0xD0 ) //down
        { 
            row++; 
        }
        else if ( (unsigned char)*(char *)KEYBOARD_BUFFER == 0xC8 ) //up
        { 
            if (row <= 0)
            {
                row = 0;
            }
            else
            {
                row--;
            }
        }


        if (row <= 1)
        {
            fillMemory(VIDEO_RAM, 0x0, 2720);
            
            if ((bufferPosition - 160) < bufferPosition)
            {
                printBufferToScreen((char *)(bufferPositionStart));
                moveCursor(row, column);
            }

        }

        if (row >= 2 && row < 15)
        {
            fillMemory(VIDEO_RAM, 0x0, 2720);
            printBufferToScreen((char *)(bufferPositionStart + (80 * row)));
            moveCursor(row, column);
        }

        if (row >= 15)
        {
            fillMemory(VIDEO_RAM, 0x0, 2720);
            printBufferToScreen((char *)(bufferPositionStart + (80 * row)));
            moveCursor(15, column);

        }

        printString(COLOR_WHITE, 22, 13, (char*)"        ");
        itoa((unsigned int)bufferPosition, bufferPositionMem);
        printString(COLOR_RED, 22, 1, (char*)"Buffer Pos:");
        printString(COLOR_WHITE, 22, 13, bufferPositionMem);

        printString(COLOR_WHITE, 21, 13, (char*)"        ");
        itoa((unsigned int)row + rowBasedOnBuffer, rowPositionMem);
        printString(COLOR_RED, 21, 1, (char*)"Row Pos:");
        printString(COLOR_WHITE, 21, 13, rowPositionMem);

        printString(COLOR_WHITE, 21, 43, (char*)"        ");
        itoa((unsigned int)column + columnBasedOnBuffer, columnPositionMem);
        printString(COLOR_RED, 21, 31, (char*)"Col Pos:");
        printString(COLOR_WHITE, 21, 43, columnPositionMem);

    }

    free(bufferPositionMem);
    free(rowPositionMem);
    free(columnPositionMem);

}


void main()
{
    int myPid;
    bool fileContentsOnScreen = false;

    disableCursor();
    clearScreen();

    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    // clearing shared buffer area
    fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));

    systemShowOpenFiles();
    myPid = readValueFromMemLoc(RUNNING_PID_LOC);
    char *commandArgument1 = malloc(myPid, 10);
    char *commandArgument2 = malloc(myPid, 10);

    while (true)
    {

        char *bufferMem = (char *)KEYBOARD_BUFFER;
        char *cursorMemory = (char *)SHELL_CURSOR_POS;

        myPid = readValueFromMemLoc(RUNNING_PID_LOC);     
        
        fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));

        printPrompt(myPid);       
        readCommand(bufferMem, cursorMemory);

        char *command = (char *)COMMAND_BUFFER;
        commandArgument1 = (char*)(COMMAND_BUFFER + strlen(COMMAND_BUFFER) + 1);
        commandArgument2 = (char*)(commandArgument1 + strlen(commandArgument1) + 1);

        // Any commands that don't take an argument, add "\n" to the end
        char *clearScreenCommand = (char *)"cls\n";
        char *openFileCommand = (char *)"open";
        char *saveFileCommand = (char *)"save";
        char *closeFileCommand = (char *)"close";
        char *viewFileCommand = (char *)"view";
        char *helpCommand = (char *)"help\n";
        char *psCommand = (char *)"ps\n";
        char *exitCommand = (char *)"exit\n";
        char *dirCommand = (char *)"ls\n";
        char *editFileCommand = (char *)"edit";
        char *switchCommand = (char *)"switch";
        char *insertCommand = (char *)"ins\n";

        if (strcmp(command, clearScreenCommand) == 0)
        {
            disableCursor();
            clearScreen();

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
        }
        else if (strcmp(command, insertCommand) == 0)
        {
            printString(COLOR_WHITE, 19, 3,(char *)"                                ");
            fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));
            
            int currentFileDescriptor;
            currentFileDescriptor = readValueFromMemLoc(CURRENT_FILE_DESCRIPTOR);

            if (fileContentsOnScreen)
            {
                screenEditor(myPid, currentFileDescriptor);
            }

        }
        else if (strcmp(command, openFileCommand) == 0)
        {
            disableCursor();
            clearScreen();
            printPrompt(myPid);    
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            clearScreen();

            systemOpenFile(commandArgument1, RDONLY);

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            int currentFileDescriptor;
            currentFileDescriptor = readValueFromMemLoc(CURRENT_FILE_DESCRIPTOR);

            struct openBufferTable *openBufferTable = (struct openBufferTable*)OPEN_BUFFER_TABLE;
            printBufferToScreen((char *)openBufferTable->buffers[currentFileDescriptor]);

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            currentFileDescriptor = readValueFromMemLoc(CURRENT_FILE_DESCRIPTOR);
        }
        else if (strcmp(command, saveFileCommand) == 0)
        {
            disableCursor();
            clearScreen();
            printPrompt(myPid);    
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            clearScreen();

            systemCreateFile(commandArgument1, atoi(commandArgument2));

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            int currentFileDescriptor;
            currentFileDescriptor = readValueFromMemLoc(CURRENT_FILE_DESCRIPTOR);

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            currentFileDescriptor = readValueFromMemLoc(CURRENT_FILE_DESCRIPTOR);
        }
        else if (strcmp(command, viewFileCommand) == 0)
        {
            disableCursor();
            clearScreen();
            printPrompt(myPid);           

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            struct openBufferTable *openBufferTable = (struct openBufferTable*)OPEN_BUFFER_TABLE;
            printBufferToScreen((char *)openBufferTable->buffers[atoi(commandArgument1)]);

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            fileContentsOnScreen = true;
        }
        else if (strcmp(command, editFileCommand) == 0)
        {
            clearScreen();
            enableCursor();

            moveCursor(1, 1);

            printPrompt(myPid);    

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            systemOpenFile(commandArgument1, RDWRITE);

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            int currentFileDescriptor;
            currentFileDescriptor = readValueFromMemLoc(CURRENT_FILE_DESCRIPTOR);

            struct openBufferTable *openBufferTable = (struct openBufferTable*)OPEN_BUFFER_TABLE;
            printBufferToScreen((char *)openBufferTable->buffers[currentFileDescriptor]);

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            fileContentsOnScreen = true;

        }
        else if (strcmp(command, closeFileCommand) == 0)
        {
            disableCursor();
            clearScreen();

            fileContentsOnScreen = false;

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            printPrompt(myPid);           

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            systemCloseFile(commandArgument1);
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            clearScreen();

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else if (strcmp(command, switchCommand) == 0)
        {
            disableCursor();
            clearScreen();
            printPrompt(myPid);            

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            
            clearScreen();

            systemTaskSwitch(commandArgument1);
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else if (strcmp(command, exitCommand) == 0)
        {
            disableCursor();
            clearScreen();
            printPrompt(myPid);  

            systemExit();       
        }
        else if (strcmp(command, helpCommand) == 0)
        {
            disableCursor();
            clearScreen();
            printString(COLOR_LIGHT_BLUE, 1, 0, (char *)"Commands available:");
            printString(COLOR_WHITE, 3, 3, (char *)"cls = Clear screen");
            printString(COLOR_WHITE, 4, 3, (char *)"open = Open a file as read-only"); 
            printString(COLOR_WHITE, 5, 3, (char *)"close = Close file"); 
            printString(COLOR_WHITE, 6, 3, (char *)"view = View a file");
            printString(COLOR_WHITE, 7, 3, (char *)"help = This menu"); 
            printString(COLOR_WHITE, 8, 3, (char *)"ps = Show processes");
            printString(COLOR_WHITE, 9, 3, (char *)"exit = Exit the Editor");
            printString(COLOR_WHITE, 10, 3, (char *)"ls = Show root directory");
            printString(COLOR_WHITE, 11, 3, (char *)"edit = Edit a file");
            printString(COLOR_WHITE, 12, 3, (char *)"switch = Switch processes");
            printString(COLOR_WHITE, 13, 3, (char *)"ins = Insert in the screen editor");
            printString(COLOR_WHITE, 14, 3, (char *)"save = Save an open file to disk");
            
        }
        else if (strcmp(command, psCommand) == 0)
        {
            disableCursor();
            clearScreen();
            printPrompt(myPid);  
            systemShowProcesses();

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else if (strcmp(command, dirCommand) == 0)
        {
            disableCursor();
            clearScreen();
            printPrompt(myPid);  
            systemListDirectory();

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else
        {
            printPrompt(myPid);             
            printString(COLOR_RED, 21, 3,(char *)"Command not recognized!");
            systemBeep();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));
            fillMemory((char *)SHELL_CURSOR_POS, (unsigned char)0x0, 40);
            wait(1);
            printString(COLOR_WHITE, 21, 3,(char *)"                                ");

            systemShowOpenFiles();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            freeAll(myPid);
            main();

        }    
    }


}