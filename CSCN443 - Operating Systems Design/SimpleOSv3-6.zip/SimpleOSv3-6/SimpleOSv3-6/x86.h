/** Send a byte to an I/O port
 * \param port The port number.
 * \param data The byte you want to send.
 */
void outputIOPort(unsigned short port, unsigned char data);

/** Reads a byte from an I/O port. Returns the byte.
 * \param port The port number you want to read.
 */
unsigned char inputIOPort(unsigned short port);

/** Allows you to read and transfer multiple words from a port to a memory location.
 * \param port The port number to read.
 * \param destinationMemory The memory address you want to store the words from the I/O port.
 * \param numberOfWords The number of words you want to read from the I/O port.
 */
void ioPortWordToMem(unsigned short port, char *destinationMemory, int numberOfWords);

/** Sends words of memory to an I/O port.
 * \param destinationPort The port number to send information to.
 * \param sourceMemory The memory address of the source to send to the I/O port.
 * \param numberOfWords The number of words you want to send to the I/O port. 
 */
void memToIoPortWord(unsigned short destinationPort, char *sourceMemory, int numberOfWords);

/** Copies memory from one location to another, in 16-bit words.
 * \param startingMemory The pointer to the beginning point to copy.
 * \param destinationMemory The destination pointer that words will be copied to.
 * \param numberOfWords The number of 16-bit words to copy from source to destination.
 */
void memoryCopy(char *startingMemory, char *destinationMemory, int numberOfWords);

/** Stores a 32-bit value to a memory location.
 * \param destinationMemory The target destination.
 * \param value The 32-bit value you want to store.
 */
void storeValueAtMemLoc(char *destinationMemory, int value);

/** Reads and returns a 32-bit value from a memory location.
 * \param sourceMemory The memory address to read.
 */
int readValueFromMemLoc(char *sourceMemory);

/** The primary sysCall function. This is used by LibC function to trigger system calls from ring 3.
 * \param sysCallNumber The system call number.
 * \param arg1 An argument to pass to the kernel, if necessary. This may be an blank, an integer, a memory location, or a pointer to a certain type of structure, depending on the system call.
 * \param currentPid The pid requesting the system call.
 */
unsigned int sysCall(unsigned int sysCallNumber, unsigned int arg1, unsigned int currentPid);

/** Loads the Intel task register. This is used during kernel initialization just prior to the jump to shell in ring 3.
 * \param taskRegisterValue Used to load the tss_kernel_descriptor from bootloader-stage 1.
 */
void loadTaskRegister(unsigned short taskRegisterValue);