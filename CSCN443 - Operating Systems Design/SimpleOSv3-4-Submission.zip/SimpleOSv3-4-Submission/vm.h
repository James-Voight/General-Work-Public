#include "constants.h"

/**
 * The task structure. This holds all of the process-specific information to successfully context switch.
 */
struct task {
    int pid;
    int ppid;
    int uid;
    int state;
    int exitCode;
    int pgd;
    int stack;
    int priority;
    int nice;
    int runtime;
    int sleepTime;
    int recentRuntime;
    int waitChannel;
    int signal;
    int physMemStart;
    int nextAvailableFileDescriptor;
    int eip;
    int esp;
    int eax;
    int ebx;
    int ecx;
    int edx;
    int edi;
    int esi;
    int ebp;
    short cs;
    short ds;
	void *fileDescriptor[MAX_FILE_DESCRIPTORS];
    char *binaryName;
	//struct is 168 bytes in total
};

/** The structure of the semaphore. */
struct semaphore
{
    int pid;
    char *memoryLocationToLock;
    int currentValue;
    int maxValue;
};

/** Fills memory with a certain byte value.
 * \param memLocation The pointer to start the fill.
 * \param byteToFill The byte value used to fill.
 * \param numberOfBytes The number of bytes to fill starting at memLocation.
 */
void fillMemory(char *memLocation, unsigned char byteToFill, int numberOfBytes);

/** Creates the page directory and single page table structures for a particular pid.
 * \param pid The pid associated with the page directory and table you'd like to create.
 */
void initializePageTables(int pid);

/** Performs a context switch to the given pid.
 * \param pid The pid you'd like to switch to.
 */
void contextSwitch(int pid);

/** Creates the task structure values for a new process.
 * \param ppid The parent pid of the new process.
 * \param state The state value of the new process.
 * \param stack The stack location for the new process.
 * \param binaryName The string value of the process name.
 * \param priority The running priority of the new process.
 */
int initializeTask(int ppid, short state, int stack, char *binaryName, int priority);

/** Updates a pid's state.
 * \param pid The pid you'd like to update.
 * \param state The new state value.
 */
void updateTaskState(int pid, short state);

/** Requests allocation of a particular page in a pid's address space. Returns 0 if unsuccessful. Returns 1 if successful. 
 * \param pid The pid associated with the process space you are interested in.
 * \param pageMemoryLocation The virtual address you are interested in allocating.
 * \param perms The requested permissions of the new page.
*/
int requestSpecificPage(int pid, char *pageMemoryLocation, char perms);

/** Requests allocation of any available page in a pid's address space. Returns pointer to the allocated page if successful. 
 * \param pid The pid associated with the process space you are interested in.
 * \param perms The requested permissions of the new page.
*/
char* requestAvailablePage(int pid, char perms);

/** Finds an open buffer using a first-fit algorithm for the number of pages requested in the pid's address space.
 * \param pid The pid you are interested in.
 * \param numberOfPages The number of contiguous pages you are looking for.
 * \param perms The requested permissions of the new pages.
 */
char* findBuffer(int pid, int numberOfPages, char perms);

/** Frees a particular page in a pid's address space.
 * \param pid The pid you are interested in.
 * \param pageToFree The virtual address of the page you want to free.
 */
void freePage(int pid, char *pageToFree);

/** Used to acquire mutual exclusivity to a data structure.
 * \param currentPid The pid requesting the action.
 * \param memoryLocation The memory location you want to secure, stored in KERNEL_SEMAPHORE_TABLE
 */
bool acquireLock(int currentPid, char *memoryLocation);

/** Used to release mutual exclusivity to a data structure. This assumes a semaphore has already been created for the data structure you wish to control. 
 * \param currentPid The pid requesting the action.
 * \param memoryLocation The memory location you want to release, stored in KERNEL_SEMAPHORE_TABLE
 */
bool releaseLock(int currentPid, char *memoryLocation);

/** Creates a semaphore to protect some memory location.
 * \param currentPid The pid requesting the action.
 * \param memoryLocation The memory address you want to protect by creating a semaphore.
 * \param currentValue The initial/current value of the semaphore.
 * \param maxValue The max value of the semaphore. If you want mutual exclusivity, set this to 1.
 */
bool createSemaphore(int currentPid, char *memoryLocation, int currentValue, int maxValue);