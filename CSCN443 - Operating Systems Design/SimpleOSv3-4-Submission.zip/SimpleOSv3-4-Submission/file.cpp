#include "constants.h"
#include "file.h"
#include "exceptions.h"
#include "vm.h"

void createOpenFileTable(char *openFileTable)
{
    while (!acquireLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}
    
    struct openFileTableEntry *OpenFileTableEntry = (struct openFileTableEntry*)openFileTable;

    OpenFileTableEntry->openedByPid = KERNEL_OWNED; //STDIN
    OpenFileTableEntry->userspaceBuffer = 0; //undefined
    OpenFileTableEntry++;

    OpenFileTableEntry->openedByPid = KERNEL_OWNED; //STDOUT
    OpenFileTableEntry->userspaceBuffer = VIDEO_RAM;
    OpenFileTableEntry++;

    OpenFileTableEntry->openedByPid = KERNEL_OWNED; //STDERR
    OpenFileTableEntry->userspaceBuffer = 0; //undefined

    while (!releaseLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}

}

openFileTableEntry *insertOpenFileTableEntry(char *openFileTable, int inode, int pid, char *userspaceBuffer, int numberOfPagesForBuffer, char *fileName, int lockedForWriting, int offset)
{
    while (!acquireLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}
    
    int lastUsedEntry = 0;
    int nextAvailEntry = 0;
    int openFileTableEntryNumber = 0;

    while (nextAvailEntry == 0 && openFileTableEntryNumber < MAX_SYSTEM_OPEN_FILES)
    {
        lastUsedEntry = *(int *)(OPEN_FILE_TABLE + (sizeof(openFileTableEntry) * openFileTableEntryNumber));

        if ((unsigned int)lastUsedEntry == 0)
        {
            nextAvailEntry = (openFileTableEntryNumber + 1);
        }

        if (openFileTableEntryNumber == (MAX_SYSTEM_OPEN_FILES - 1))
        {
            while (!releaseLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}
            panic((char*)"file.cpp:insertOpenFileTableEntry() -> reached max system open files");
        }

        openFileTableEntryNumber++;
    }

    int availableOpenFileTableLocation = OPEN_FILE_TABLE + (sizeof(openFileTableEntry) * (nextAvailEntry - 1));
    struct openFileTableEntry *OpenFileTableEntry = (struct openFileTableEntry*)availableOpenFileTableLocation;

    OpenFileTableEntry->openedByPid = pid;
    OpenFileTableEntry->inode = inode;
    OpenFileTableEntry->userspaceBuffer = userspaceBuffer;
    OpenFileTableEntry->numberOfPagesForBuffer = numberOfPagesForBuffer;
    OpenFileTableEntry->fileName = fileName;
    OpenFileTableEntry->offset = offset;
    OpenFileTableEntry->lockedForWriting = lockedForWriting;

    while (!releaseLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}

    return OpenFileTableEntry;
}

int totalOpenFiles(char *openFileTable)
{
    int lastUsedEntry = 0;
    int totalSystemOpenFiles = 0;
    int openFileTableEntryNumber = 0;

    while (openFileTableEntryNumber < MAX_SYSTEM_OPEN_FILES)
    {
        lastUsedEntry = *(int *)(OPEN_FILE_TABLE + (sizeof(openFileTableEntry) * openFileTableEntryNumber));

        if ((unsigned int)lastUsedEntry != 0)
        {
            totalSystemOpenFiles++;
        }

        openFileTableEntryNumber++;
    }

    return totalSystemOpenFiles;

}

void closeAllFiles(char *openFileTable, int pid)
{
    while (!acquireLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}
    
    struct openFileTableEntry *OpenFileTableEntry = (struct openFileTableEntry*)openFileTable;
    int openFileTableEntryNumber = 0;

    while (openFileTableEntryNumber < MAX_SYSTEM_OPEN_FILES)
    {
        if (OpenFileTableEntry->openedByPid == pid)
        {
            fillMemory((char *)OpenFileTableEntry, 0x0, sizeof(openFileTableEntry));
        }
        
        OpenFileTableEntry++;
        openFileTableEntryNumber++;
    }

    while (!releaseLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}
}

bool fileAvailableToBeLocked(char *openFileTable, int inode)
{
    struct openFileTableEntry *OpenFileTableEntry = (struct openFileTableEntry*)openFileTable;
    int openFileTableEntryNumber = 0;

    while (openFileTableEntryNumber < MAX_SYSTEM_OPEN_FILES)
    {
        if (OpenFileTableEntry->inode == inode)
        {
            if (OpenFileTableEntry->lockedForWriting == FILE_LOCKED)
            {
                return false; // File already locked
            }

        }
        
        OpenFileTableEntry++;
        openFileTableEntryNumber++;
    }

    return true;
}

bool lockFile(char *openFileTable, int pid, int inode)
{
    while (!acquireLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}
    
    struct openFileTableEntry *OpenFileTableEntry = (struct openFileTableEntry*)openFileTable;
    int openFileTableEntryNumber = 0;

    // Do complete scan of table to make sure no one else has it locked
    while (openFileTableEntryNumber < MAX_SYSTEM_OPEN_FILES)
    {
        if (OpenFileTableEntry->inode == inode)
        {
            if (OpenFileTableEntry->lockedForWriting == FILE_LOCKED)
            {
                while (!releaseLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}
                return false; // File already locked
            }

        }
        
        OpenFileTableEntry++;
        openFileTableEntryNumber++;
    }

    // Do another scan of the table to lock the file for the requesting pid.
    OpenFileTableEntry = (struct openFileTableEntry*)openFileTable;
    openFileTableEntryNumber = 0;
    while (openFileTableEntryNumber < MAX_SYSTEM_OPEN_FILES)
    {
        if (OpenFileTableEntry->inode == inode && OpenFileTableEntry->openedByPid == pid)
        {
            OpenFileTableEntry->lockedForWriting = FILE_LOCKED;
            while (!releaseLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}
            return true;
        }
        
        OpenFileTableEntry++;
        openFileTableEntryNumber++;
    }

    while (!releaseLock(KERNEL_OWNED, (char *)OPEN_FILE_TABLE)) {}
    return false;
}