#include "vm.h"
#include "fs.h"
#include "constants.h"
#include "simpleOSlibc.h"
#include "frame-allocator.h"
#include "exceptions.h"
#include "file.h"
#include "screen.h"


void initializePageTables(int pid)
{     

    // // ASSIGNMENT 3 TO DO
    int* pgdLocation = (int*)(PAGE_DIR_BASE + (pid - 1) * MAX_PGTABLES_SIZE);
    int* ptLocation = (int*)(PAGE_TABLE_BASE + (pid - 1) * MAX_PGTABLES_SIZE);

    ptLocation[KEYBOARD_BUFFER / PAGE_SIZE] = KEYBOARD_BUFFER | PG_USER_PRESENT_RW;
    ptLocation[USER_PID_INFO / PAGE_SIZE] = USER_PID_INFO | PG_USER_PRESENT_RO;
    ptLocation[GDT_LOC / PAGE_SIZE] = GDT_LOC | PG_USER_PRESENT_RO;
    ptLocation[(int)VIDEO_RAM / PAGE_SIZE] = (int)VIDEO_RAM | PG_USER_PRESENT_RW;
    
    // Assign all of kernel space as PG_KERNEL_PRESENT_RW
    for (int i = KERNEL_BASE / PAGE_SIZE; i < KERNEL_LIMIT / PAGE_SIZE; i++)
    {
        // *(int *)(ptLocation + i) |= PG_KERNEL_PRESENT_RW;
        ptLocation[i] = (i * PAGE_SIZE) | PG_KERNEL_PRESENT_RW;
    }

    // Initialize page table
    ptLocation[0] = PG_USER_PRESENT_RW;
    // Initialize page directory
    pgdLocation[0] = (int)ptLocation | PG_USER_PRESENT_RW;
} 


void fillMemory(char *memLocation, unsigned char byteToFill, int numberOfBytes)
{
    for (int currentByte = 0; currentByte < numberOfBytes; currentByte++)
    {
        *memLocation = byteToFill;
        memLocation++;
    }
}


void contextSwitch(int pid)
{
    int pgdLocation = ((pid - 1) * MAX_PGTABLES_SIZE) + PAGE_DIR_BASE;
    
    asm volatile ("movl %0, %%eax\n\t" : : "r" (pgdLocation));
    asm volatile ("movl %eax, %cr3\n\t");
    asm volatile ("movl %cr0, %ebx\n\t");
    asm volatile ("or $0x80000000, %ebx\n\t");
    asm volatile ("movl %ebx, %cr0\n\t");
}

int initializeTask(int ppid, short state, int stack, char *binaryName, int priority)
{
    while (!acquireLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
    
    int lastUsedPid = 0;
    int nextAvailPid = 0;
    int taskStructNumber = 0;

    if (ppid == 0) { ppid = KERNEL_OWNED; }

    while (nextAvailPid == 0 && taskStructNumber < MAX_PROCESSES)
    {
        lastUsedPid = *(int *)(PROCESS_TABLE_LOC + (TASK_STRUCT_SIZE * taskStructNumber));

        if ((unsigned int)lastUsedPid == 0)
        {
            nextAvailPid = (taskStructNumber + 1);
        }

        if (taskStructNumber == (MAX_PROCESSES - 1))
        {
            while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
            panic((char*)"vm.cpp:initializeTask() -> reached max process number");
        }

        taskStructNumber++;
    }
    
    int physMemStart = (MAX_PROCESS_SIZE * (nextAvailPid - 1));
    int taskStructLocation = PROCESS_TABLE_LOC + (TASK_STRUCT_SIZE * (nextAvailPid - 1));
    int pgd = ((nextAvailPid - 1) * MAX_PGTABLES_SIZE) + PAGE_DIR_BASE;
    
    struct task *Task = (struct task*)taskStructLocation;

    Task->pid = nextAvailPid;
    Task->ppid = ppid;
    Task->state = state;
    Task->pgd = pgd;
    Task->stack = stack;
    Task->physMemStart = physMemStart;
    Task->fileDescriptor[1] = (openFileTableEntry *)(OPEN_FILE_TABLE + (sizeof(openFileTableEntry)));
    Task->nextAvailableFileDescriptor = 3;
    Task->priority = priority;
    Task->runtime = 0;
    Task->binaryName = binaryName;

    while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}

    return nextAvailPid;
}

void updateTaskState(int pid, short state)
{
    while (!acquireLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
    
    int taskStructLocation = PROCESS_TABLE_LOC + (TASK_STRUCT_SIZE * (pid - 1));
    
    struct task *Task = (struct task*)taskStructLocation;
    Task->state = state;

    while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
}

int requestSpecificPage(int pid, char *pageMemoryLocation, char perms)
{

    // ASSIGNMENT 3 TO DO
    while (!acquireLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
    
    int* ptLocation = (int*)(PAGE_TABLE_BASE + (pid - 1) * MAX_PGTABLES_SIZE);
    int pageIndex = (int)pageMemoryLocation / PAGE_SIZE;
    int frame = allocateFrame(pid, (char *)PAGEFRAME_MAP_BASE);
    
    if (frame == -1)
    {
        while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
        return 0; // No available frames
    }
    
    //Insert the page frame address into the process’s page table at the provided virtual address using the provided permissions
    ptLocation[pageIndex] = (frame * PAGE_SIZE) | perms;

    while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
    return 1; // Success
    
}

char* findBuffer(int pid, int numberOfPages, char perms)
{

    // ASSIGNMENT 3 TO DO
    int* ptLocation = (int*)(PAGE_TABLE_BASE + (pid - 1) * MAX_PGTABLES_SIZE);
    
    // Start searching from TEMP_FILE_START_LOC
    for (int i = TEMP_FILE_START_LOC / PAGE_SIZE; i < KERNEL_BASE; i++)
    {
        int found = 1;

        // Check if a contiguous range of `numberOfPages` is available
        for (int j = 0; j < numberOfPages; j++)
        {
            if (ptLocation[i + j] != 0)  // Check if page is in use
            {
                found = 0;
                break;
            }
        }

        // If a hole is found, allocate each page using requestSpecificPage()
        if (found)
        {
            return (char *)(i * PAGE_SIZE);  // Return the starting address of allocated buffer
        }
    }

    return 0; // No suitable buffer found

}


char* requestAvailablePage(int pid, char perms)
{
    
    // ASSIGNMENT 3 TO DO
    while (!acquireLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
    
    int* ptLocation = (int*)(PAGE_TABLE_BASE + (pid - 1) * MAX_PGTABLES_SIZE);
    int frame = allocateFrame(pid, (char *)PAGEFRAME_MAP_BASE);
    
    if (frame == -1)
    {
        while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
        return 0; // No available frames
    }
    
    for (int i = TEMP_FILE_START_LOC / PAGE_SIZE; i < PAGE_TABLE_ENTRIES; i++)
    {
        if (ptLocation[i] == 0)
        {
            ptLocation[i] = (frame * PAGE_SIZE) | perms;
            while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
            return (char *)(i * PAGE_SIZE);
        }
    }
    
    while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
    return 0; // No available pages
    
}

void freePage(int pid, char *pageToFree)
{
    while (!acquireLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}

    int ptLocation = ((pid - 1) * MAX_PGTABLES_SIZE) + PAGE_TABLE_BASE;
    int pageNumberToFree = (int)pageToFree / PAGE_SIZE;
    int physicalAddressToFree = *(int *)((int)ptLocation + (pageNumberToFree * 4));

    freeFrame((physicalAddressToFree / PAGE_SIZE));
    *(int *)((int)ptLocation + (pageNumberToFree * 4)) = 0x0;

    while (!releaseLock(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC)) {}
}

bool acquireLock(int currentPid, char *memoryLocation)
{
    int semaphoreNumber = 0;
    struct semaphore *Semaphore = (struct semaphore*)KERNEL_SEMAPHORE_TABLE;

    while (semaphoreNumber < MAX_SEMAPHORE_OBJECTS)
    {
        if (Semaphore->pid == currentPid && Semaphore->memoryLocationToLock == memoryLocation)
        {
            if (Semaphore->currentValue == 0)
            {
                return false; // Cannot acquire lock
            }
            
            asm volatile ("movl %0, %%ecx\n\t" : : "r" (Semaphore->currentValue - 1));
            asm volatile ("movl %0, %%edx\n\t" : : "r" (&Semaphore->currentValue));
            asm volatile ("xchg %ecx, (%edx)\n\t");
            return true;
        }

        semaphoreNumber++;
        Semaphore++;
    }

    return false;
}

bool releaseLock(int currentPid, char *memoryLocation)
{
    int semaphoreNumber = 0;
    struct semaphore *Semaphore = (struct semaphore*)KERNEL_SEMAPHORE_TABLE;

    while (semaphoreNumber < MAX_SEMAPHORE_OBJECTS)
    {
        if (Semaphore->pid == currentPid && Semaphore->memoryLocationToLock == memoryLocation)
        {
            if (Semaphore->currentValue == Semaphore->maxValue)
            {
                return false; // At max amount
            }
            
            asm volatile ("movl %0, %%ecx\n\t" : : "r" (Semaphore->currentValue + 1));
            asm volatile ("movl %0, %%edx\n\t" : : "r" (&Semaphore->currentValue));
            asm volatile ("xchg %ecx, (%edx)\n\t");
            return true;
        }

        semaphoreNumber++;
        Semaphore++;
    }

    return false;
}

bool createSemaphore(int currentPid, char *memoryLocation, int currentValue, int maxValue)
{
    int semaphoreNumber = 0;
    struct semaphore *Semaphore = (struct semaphore*)KERNEL_SEMAPHORE_TABLE;

    while (semaphoreNumber < MAX_SEMAPHORE_OBJECTS)
    {
        if (Semaphore->pid == 0)
        {
            Semaphore->pid = currentPid;
            Semaphore->memoryLocationToLock = memoryLocation;
            Semaphore->currentValue = currentValue;
            Semaphore->maxValue = maxValue;
            return true;  
        }

        semaphoreNumber++;
        Semaphore++;
    }
    // return false if unable to create
    return false;
}