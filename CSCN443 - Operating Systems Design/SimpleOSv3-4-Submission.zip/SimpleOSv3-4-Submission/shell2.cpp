#include "screen.h"
#include "keyboard.h"
#include "vm.h"
#include "simpleOSlibc.h"
#include "constants.h"
#include "x86.h"
#include "file.h"
#include "sound.h"

void printPrompt(unsigned char myPid)
{
    printLogo(20);
    
    char *shellHorizontalLine = malloc(myPid, sizeof(char));
    *shellHorizontalLine = ASCII_HORIZONTAL_LINE;
    for (int columnPos = 0; columnPos < 80; columnPos++)
    {
        printString(COLOR_LIGHT_BLUE, 18, columnPos, shellHorizontalLine);
    }

    free(shellHorizontalLine);

    printString(COLOR_GREEN, 18, 3, (char *)"Simple OS Shell v2.0");
    printString(COLOR_LIGHT_BLUE, 19, 1, (char *)"/$");
    printString(COLOR_GREEN, 18, 62, (char *)"Current PID: ");
    printHexNumber(COLOR_GREEN, 18, 75, (unsigned char)myPid);

}



void main()
{
    int myPid;

    disableCursor();

    myPid = readValueFromMemLoc(RUNNING_PID_LOC);

    clearScreen();

    // clearing shared buffer area
    fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));
    char *commandArgument1 = malloc(myPid, 10);
    char *commandArgument2 = malloc(myPid, 10);

    while (true)
    {

        char *bufferMem = (char *)KEYBOARD_BUFFER;
        char *cursorMemory = (char *)SHELL_CURSOR_POS;

        myPid = readValueFromMemLoc(RUNNING_PID_LOC);     
        
        fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));

        printPrompt(myPid);     
        readCommand(bufferMem, cursorMemory);

        char* command = COMMAND_BUFFER;

        commandArgument1 = (char*)(COMMAND_BUFFER + strlen(COMMAND_BUFFER) + 1);
        commandArgument2 = (char*)(commandArgument1 + strlen(commandArgument1) + 1);

        // Any commands that don't take an argument, add "\n" to the end
        char *clearScreenCommand = (char *)"cls\n"; 
        char *uptimeCommand = (char *)"uptime\n";
        char *panicCommand = (char *)"panic\n";
        char *helpCommand = (char *)"help\n";
        char *musicCommand = (char *)"music\n";
        char *psCommand = (char *)"ps\n";
        char *runCommand = (char *)"run";
        char *deleteCommand = (char *)"rm";
        char *newCommand = (char *)"new";
        char *exitCommand = (char *)"exit\n";
        char *freeCommand = (char *)"free\n";
        char *mmapCommand = (char *)"mmap\n";
        char *killCommand = (char *)"kill";
        char *switchCommand = (char *)"switch";
        char *memCommand = (char *)"mem";
        char *parentCommand = (char *)"parent\n";
        char *dirCommand = (char *)"ls\n";
        char *schedCommand = (char *)"sched\n";

        if (strcmp(command, clearScreenCommand) == 0)
        {
            clearScreen();
        }
        else if (strcmp(command, uptimeCommand) == 0)
        {
            clearScreen();
            systemUptime();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else if (strcmp(command, panicCommand) == 0)
        {
            asm volatile ("jmp $0x50,$0x0\n\t"); //picking a random far jump to cause a triple fault

        }
        else if (strcmp(command, musicCommand) == 0)
        {
            for (int x=0; x < 3; x++)
            {
                makeSound(262,6); // This is a libc function 
                makeSound(294,3);
                makeSound(262,3);
                makeSound(349,3);
                makeSound(330,3); // Makes no sound
                makeSound(262,6);
                makeSound(294,6);
                makeSound(330,18); // Makes no sound
            }

            clearScreen();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
            printPrompt(myPid);

        }
        else if (strcmp(command, exitCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);  
            systemExit();            
        }
        else if (strcmp(command, helpCommand) == 0)
        {
            clearScreen();
            printString(COLOR_LIGHT_BLUE, 1, 0, (char *)"Commands available:");
            printString(COLOR_WHITE, 3, 3, (char *)"cls = Clear screen");
            printString(COLOR_WHITE, 4, 3, (char *)"uptime = System uptime"); 
            printString(COLOR_WHITE, 5, 3, (char *)"reboot = Reboot the system");
            printString(COLOR_WHITE, 6, 3, (char *)"music = Play a simple song"); 
            printString(COLOR_WHITE, 7, 3, (char *)"ps = Show processes");
            printString(COLOR_WHITE, 8, 3, (char *)"run = Launch new binary, with priority");
            printString(COLOR_WHITE, 9, 3, (char *)"exit = Exit the Shell");
            printString(COLOR_WHITE, 10, 3, (char *)"free = Free all zombie processes");
            printString(COLOR_WHITE, 11, 3, (char *)"mmap = Request a page of memory");
            printString(COLOR_WHITE, 12, 3, (char *)"kill = Kill a process");
            printString(COLOR_WHITE, 13, 3, (char *)"switch = Switch processes");
            printString(COLOR_WHITE, 3, 47, (char *)"mem = Show memory");
            printString(COLOR_WHITE, 4, 47, (char *)"parent = Switch to parent");
            printString(COLOR_WHITE, 5, 47, (char *)"ls = Show root directory");
            printString(COLOR_WHITE, 6, 47, (char *)"sched = Toggle kernel scheduler");
            printString(COLOR_WHITE, 7, 47, (char *)"rm = delete a file");
            printString(COLOR_WHITE, 8, 47, (char *)"new = create a new empty file");
            
        }
        else if (strcmp(command, freeCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);  

            systemFree();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            clearScreen();
            printString(COLOR_WHITE, 1, 5, (char *)"All zombie processes freed, along with their page frames...");

        }
        else if (strcmp(command, mmapCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);  

            systemMMap();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
        }
        else if (strcmp(command, killCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);             
            systemKill(commandArgument1);
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);
        }
        else if (strcmp(command, switchCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);            

            systemTaskSwitch(commandArgument1);
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else if (strcmp(command, parentCommand) == 0)
        {
            clearScreen();
            systemSwitchToParent();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else if (strcmp(command, memCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);            
            printString(COLOR_WHITE, 1, 2, (char *)"Type the memory location (in decimal) you wish to see and press <Enter>...");
            fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));

            readCommand(bufferMem, cursorMemory);
            clearScreen();

            systemShowMemory(COMMAND_BUFFER);
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else if (strcmp(command, psCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);  
            systemShowProcesses();

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else if (strcmp(command, runCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);         
            
            if (atoi(commandArgument2) == 0x0)
            {
                clearScreen();
                printPrompt(myPid);             
                printString(COLOR_RED, 1, 3,(char *)"Please specify the run priority...");
                printString(COLOR_RED, 3, 3,(char *)"Ex: run myprog 30");
                myPid = readValueFromMemLoc(RUNNING_PID_LOC);

                fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));
                wait(3);

                clearScreen();

                freeAll(myPid);
                main();
            }  
            else if (atoi(commandArgument2) > 255)
            {
                clearScreen();
                printPrompt(myPid);             
                printString(COLOR_RED, 1, 3,(char *)"Run priority too high...must be <= 255.");
                myPid = readValueFromMemLoc(RUNNING_PID_LOC);

                fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));
                wait(2);

                clearScreen();

                freeAll(myPid);
                main();
            }

            systemForkExec(commandArgument1, atoi(commandArgument2));

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            freeAll(myPid);
            main(); // Seems to page fault when returning back from launched process without this

        }
        else if (strcmp(command, deleteCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);      

            char *commandArgument1NoNewLine = malloc(myPid, sizeof(int));
            strcpyRemoveNewline(commandArgument1NoNewLine, commandArgument1);

            systemDeleteFile(commandArgument1NoNewLine);

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            freeAll(myPid);
            main(); // Seems to page fault when returning back from launched process without this

        }
        else if (strcmp(command, newCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);       

            if (atoi(commandArgument2) == 0x0)
            {
                clearScreen();
                printPrompt(myPid);             
                printString(COLOR_RED, 1, 3,(char *)"Please specify size of the file in pages...");
                myPid = readValueFromMemLoc(RUNNING_PID_LOC);

                fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));
                wait(2);

                clearScreen();

                freeAll(myPid);
                main();
            }

            systemOpenEmptyFile(commandArgument1, atoi(commandArgument2));

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            freeAll(myPid);
            main(); // Seems to page fault when returning back from launched process without this

        }
        else if (strcmp(command, dirCommand) == 0)
        {
            clearScreen();
            printPrompt(myPid);  
            systemListDirectory();

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else if (strcmp(command, schedCommand) == 0)
        {
            clearScreen();
            systemSchedulerToggle();

            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

        }
        else
        {
            clearScreen();
            printPrompt(myPid);             
            printString(COLOR_RED, 1, 3,(char *)"Command not recognized!");
            systemBeep();
            myPid = readValueFromMemLoc(RUNNING_PID_LOC);

            fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, (KEYBOARD_BUFFER_SIZE * 2));
            wait(1);

            clearScreen();

            freeAll(myPid);
            main();
        }    

    }


}