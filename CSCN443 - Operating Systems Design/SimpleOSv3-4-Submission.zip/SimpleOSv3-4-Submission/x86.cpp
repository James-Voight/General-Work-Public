#include "x86.h"
#include "constants.h"


void outputIOPort(unsigned short port, unsigned char data)
{
    asm volatile("out %0,%1" : : "a" (data), "d" (port));
}

unsigned char inputIOPort(unsigned short port)
{
    unsigned char data;
    
    asm volatile("in %1,%0" : "=a" (data) : "d" (port));
    
    return data;
}

void ioPortWordToMem(unsigned short port, char *destinationMemory, int numberOfWords)
{
    asm volatile ("mov %0, %%dx\n\t" : : "r" (port));
    asm volatile ("movl %0, %%edi\n\t" : : "r" (destinationMemory));
    asm volatile ("cld\n\t");
    asm volatile ("movl %0, %%ecx\n\t" : : "r" (numberOfWords));
    asm volatile ("rep insw");
}

void memToIoPortWord(unsigned short destinationPort, char *sourceMemory, int numberOfWords)
{
    asm volatile ("mov %0, %%dx\n\t" : : "r" (destinationPort));
    asm volatile ("movl %0, %%esi\n\t" : : "r" (sourceMemory));
    asm volatile ("cld\n\t");
    asm volatile ("movl %0, %%ecx\n\t" : : "r" (numberOfWords));
    asm volatile ("rep outsw");
}

void memoryCopy(char *startingMemory, char *destinationMemory, int numberOfWords)
{
    asm volatile ("movl %0, %%esi\n\t" : : "r" (startingMemory));
    asm volatile ("movl %0, %%edi\n\t" : : "r" (destinationMemory));
    asm volatile ("cld\n\t");
    asm volatile ("movl %0, %%ecx\n\t" : : "r" (numberOfWords));                  
    asm volatile ("rep movsw\n\t");
}

void loadTaskRegister(unsigned short taskRegisterValue)
{
    asm volatile ("mov %0, %%ax\n\t" : : "r" (taskRegisterValue));
    asm volatile ("ltr %ax\n\t");
}

void storeValueAtMemLoc(char *destinationMemory, int value)
{
    asm volatile ("movl %0, %%ebx\n\t" : : "r" (destinationMemory));
    asm volatile ("movl %0, %%eax\n\t" : : "r" (value));
    asm volatile ("movl %eax, (%ebx)\n\t");
}

int readValueFromMemLoc(char *sourceMemory)
{
    int value;
    
    asm volatile ("movl %0, %%ebx\n\t" : : "r" (sourceMemory));
    asm volatile ("movl (%ebx), %eax\n\t");
    asm volatile ("movl %%eax, %0\n\t" : "=r" (value) : );

    return value;
}

unsigned int sysCall(unsigned int sysCallNumber, unsigned int arg1, unsigned int currentPid)
{
    unsigned int returnValue;
    
    asm volatile ("movl %0, %%ecx\n\t" : : "r" (currentPid)); //current pid
    asm volatile ("movl %0, %%ebx\n\t" : : "r" (arg1)); //file name
    asm volatile ("movl %0, %%eax\n\t" : : "r" (sysCallNumber)); // sysopen
    asm volatile ("pusha\n\t");
    asm volatile ("int $0x80\n\t");
    asm volatile ("popa\n\t"); //this allows user to run, but breaks sysexit on pid 1 (but works when PID > 1)
    asm volatile ("movl %%eax, %0\n\t" : "=r" (returnValue) : );

    return returnValue;
}