#include "schedule.h"
#include "kernel.h"
#include "constants.h"
#include "exceptions.h"
#include "vm.h"
#include "x86.h"
#include "syscalls.h"
#include "screen.h"


void scheduler(int currentPid)
{
    // ASSIGNMENT 6 TO DO    
    
    struct kernelConfiguration* KernelConfig = (struct kernelConfiguration*)KERNEL_CONFIGURATION;
    if (KernelConfig->runScheduler == 0) {
        return;
    }

    int selectedPid = currentPid;
    float lowestRatio;

    struct task* proc = (struct task*)(PROCESS_TABLE_LOC + (TASK_STRUCT_SIZE * (currentPid - 1)));
    lowestRatio = (float)proc->runtime / proc->priority; //float value to allow for decimal comparison

    for (int i = 0; i < MAX_PROCESSES; i++) {  //loop through all processes
        proc = (struct task*)(PROCESS_TABLE_LOC + (TASK_STRUCT_SIZE * i));

        if (proc->state == PROC_RUNNING || proc->state == PROC_SLEEPING) {
            float ratio = (float)proc->runtime / proc->priority;  //float value to allow for decimal comparison
            if (ratio < lowestRatio) {
                lowestRatio = ratio;
                selectedPid = proc->pid;  // if becomes the lowest ratio, select that pid
            }
        }
    }

    if (selectedPid != currentPid) {
        sysSwitch(selectedPid, currentPid);
    }
}