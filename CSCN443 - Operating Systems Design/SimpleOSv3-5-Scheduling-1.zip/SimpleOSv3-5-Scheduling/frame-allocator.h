
/** Creates the initial structure of the page frame map.
 * \param pageFrameMap The pointer to the beginning of the map.
 * \param numberOfFrame How many frames to create. 
 */
void createPageFrameMap(char *pageFrameMap, int numberOfFrames);

/** Allocates a frame in the page frame map and returns the frame number.
 * \param pid The pid who is requesting the frame.
 * \param pageFrameMap The pointer to the beginning of the map.
 */
int allocateFrame(int pid, char *pageFrameMap);

/** Frees a frame in the page frame map.
 * \param frameNumber The frame to free.
 */
void freeFrame(int frameNumber);

/** Frees all frames for a particular pid.
 * \param pid The pid associated with the frames we are want freed.
 * \param pageFrameMap The pointer to the beginning of the map.
 */
void freeAllFrames(int pid, char *pageFrameMap);

/** Counts the number of frames used by a particular process. Returns the number of frames used by that pid.
 * \param pid The pid you are interested in.
 * \param pageFrameMap The pointer to the beginning of the map.
 */
unsigned int processFramesUsed(int pid, char *pageFrameMap);

/** Counts the total frames used in the system. Returns that value.
 * \param pageFrameMap The pointer to the beginning of the map.
 */
unsigned int totalFramesUsed(char *pageFrameMap);