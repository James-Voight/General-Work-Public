#include "vmmonitor.h"

void parseVM()
{
    
}