#include "vm.h"
#include "constants.h"
#include "simpleOSlibc.h"

void createPageFrameMap(char *pageFrameMap, int numberOfFrames)
{
    // ASSIGNMENT 3 TO DO

    // Mark kernel-reserved regions as KERNEL_OWNED
    pageFrameMap[0] = KERNEL_OWNED;
    pageFrameMap[KEYBOARD_BUFFER / PAGE_SIZE] = KERNEL_OWNED;
    pageFrameMap[USER_PID_INFO / PAGE_SIZE] = KERNEL_OWNED;
    pageFrameMap[GDT_LOC / PAGE_SIZE] = KERNEL_OWNED;
    
    //VIDEO_AND_BIOS_RESERVED_START to VIDEO_AND_BIOS_RESERVED_END should be KERNEL_OWNED
    for (int i = VIDEO_AND_BIOS_RESERVED_START / PAGE_SIZE; i <= VIDEO_AND_BIOS_RESERVED_END / PAGE_SIZE; i++) {
        pageFrameMap[i] = KERNEL_OWNED;
    }

    //KERNEL_BASE to KERNEL_LIMIT should be KERNEL_OWNED
    for (int i = KERNEL_BASE / PAGE_SIZE; i < KERNEL_LIMIT / PAGE_SIZE; i++) {
        pageFrameMap[i] = KERNEL_OWNED;
    }

    // All else for the size of RAM should be PAGEFRAME_AVAILABLE
    for (int i = KERNEL_LIMIT / PAGE_SIZE; i < numberOfFrames; i++) {
        pageFrameMap[i] = PAGEFRAME_AVAILABLE;
    }
}


int allocateFrame(int pid, char *pageFrameMap)
{
    
    // ASSIGNMENT 3 TO DO
    // Acquire lock on PAGEFRAME_MAP_BASE
    while (!acquireLock(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE)) {}

    // Find first available page frame
    for (int i = 0; i < TOTAL_PAGES; i++) {
        if (pageFrameMap[i] == PAGEFRAME_AVAILABLE) {
            pageFrameMap[i] = pid; // Allocate to PID
            
            // Release lock on PAGEFRAME_MAP_BASE
            while (!releaseLock(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE)) {}

            return i; // Return frame number
        }
    }

    // Release lock if no available frame is found
    while (!releaseLock(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE)) {}

    return -1; // No available frame found

}

void freeFrame(int frameNumber)
{
    while (!acquireLock(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE)) {}
    
    *(char *)(PAGEFRAME_MAP_BASE + frameNumber) = (unsigned char)0x0;

    while (!releaseLock(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE)) {}
}


void freeAllFrames(int pid, char *pageFrameMap)
{

    // ASSIGNMENT 3 TO DO
    while (!acquireLock(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE)) {}
    
    // Loop through and free all frames (marking them as PAGEFRAME_AVAILABLE) for a given PID
    for (int i = 0; i < TOTAL_PAGES; i++) {
        if (pageFrameMap[i] == pid) {
            pageFrameMap[i] = PAGEFRAME_AVAILABLE;
        }
    }
    
    while (!releaseLock(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE)) {}
}

unsigned int processFramesUsed(int pid, char *pageFrameMap)
{
    unsigned char lastUsedFrame = PAGEFRAME_AVAILABLE;
    int framesUsed = 0;

    for (int frameNumber = 0; frameNumber < (KERNEL_BASE / PAGE_SIZE); frameNumber++)
    {
        lastUsedFrame = *(char *)(pageFrameMap + frameNumber);

        if (lastUsedFrame == pid)
        {
            framesUsed++;      
        }

    }
    return (unsigned int)framesUsed;

}

unsigned int totalFramesUsed(char *pageFrameMap)
{
    unsigned char lastUsedFrame = PAGEFRAME_AVAILABLE;
    int framesUsed = 0;

    for (int frameNumber = 0; frameNumber < PAGEFRAME_MAP_SIZE; frameNumber++)
    {
        lastUsedFrame = *(char *)(pageFrameMap + frameNumber);

        if (lastUsedFrame != PAGEFRAME_AVAILABLE)
        {
            framesUsed++;
            
        }

    }
    return (unsigned int)framesUsed;

}