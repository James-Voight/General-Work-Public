/**
 * Panics the kernel with a blue screen and enters an infinite loop.
 * \param message The message to display in the blue screen.
 */
void panic(char *message);