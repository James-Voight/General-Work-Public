#include "screen.h"
#include "fs.h"
#include "constants.h"
#include "exceptions.h"
#include "vm.h"


void main()
{
    //clear all upper memory areas for warm reboot
    fillMemory((char *)0x100000, 0x0, 0x29E000); 
    fillMemory((char *)KERNEL_SEMAPHORE_TABLE, 0x0, PAGE_SIZE); 
    fillMemory((char *)OPEN_FILE_TABLE, 0x0, PAGE_SIZE);

    //load the superblock and block group descriptor table
    fillMemory(SUPERBLOCK_LOC, 0x0, PAGE_SIZE);
    readBlock(SUPERBLOCK, SUPERBLOCK_LOC);
    readBlock(GROUP_DESCRIPTOR_BLOCK, BLOCK_GROUP_DESCRIPTOR_TABLE);

    int cursorRow = 0;

    clearScreen();
    printString(COLOR_WHITE, cursorRow++, 0, (char *)"Bootloader stage 2...");
    printString(COLOR_WHITE, cursorRow++, 0, (char *)"Reading kernel binary from file system...");

    if (!fsFindFile((char *)"kernel", KERNEL_TEMP_INODE_LOC))
    {
        panic((char *)"Bootloader-stage2.cpp -> Cannot find kernel in root directory");
    }
    loadFileFromInodeStruct(KERNEL_TEMP_INODE_LOC, KERNEL_TEMP_FILE_LOC);
    loadElfFile(KERNEL_TEMP_FILE_LOC);

    printString(COLOR_WHITE, cursorRow++, 0, (char *)"Kernel binary loaded...jumping to kernel main...");  

    struct elfHeader *ELFHeader = (struct elfHeader*)KERNEL_TEMP_FILE_LOC;
    // while(true);
    (*(void(*)())ELFHeader->e_entry)(); 

    panic((char *)"bootloader-stage2.cpp -> Error launching kernel binary");

}