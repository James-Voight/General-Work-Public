#include "screen.h"
#include "constants.h"
#include "vm.h"

void panic(char *message)
{
    clearScreen();
    disableCursor();

    for (int x=1; x<4000; x++)
    {
        fillMemory((char*)(VIDEO_RAM + x), 0x10, 1);
        x++;
    }
    printString(0x1F, 1, 8, (char*)"AWESOME WORK! You triggered a kernel panic (that takes skill)!");
    printString(0x1F, 3, 9, (char*)"O'Malley would be proud. (He has done it hundreds of times...)");
    
    printString(0x1C, 5, 2, (char *)"Kernel panic!");
    printString(0x1F, 7, 2, (char *)"From: ");
    printString(0x1F, 7, 10, message);

    while (true) {}
}