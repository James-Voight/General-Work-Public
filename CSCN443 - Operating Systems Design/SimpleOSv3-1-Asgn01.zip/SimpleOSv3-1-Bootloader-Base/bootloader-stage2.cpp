#include "screen.h"
#include "constants.h"
#include "x86.h"


void main()
{
    clearScreen();
    printString(COLOR_WHITE, 5, 5, (char *)"Welcome to CSCN-443!");
    printString(COLOR_LIGHT_BLUE, 7, 5, (char *)"Bootloader-Stage2");
    
    int numberToPrint = 0;
    int row = 11;
    int column = 0;

    while (numberToPrint <= 255)
    {
        if (column >= 75) { column = 0; row++; }
        
        printHexNumber(COLOR_RED, row, (column = column + 3), (unsigned char)numberToPrint);
        numberToPrint++;

    }

    while (true) {}
}