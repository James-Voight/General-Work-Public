#include "simpleOSlibc.h"
#include "constants.h"
#include "x86.h"
#include "screen.h"

void main()
{   
    int myPid = readValueFromMemLoc(RUNNING_PID_LOC); 

    int initialValue = 0;
    int *valueToCalculate = (int *)malloc(myPid, sizeof(int));

    while ((unsigned int)*valueToCalculate < 40000000)
    {
        *valueToCalculate = initialValue++;
    }

    free((char *)valueToCalculate);
    systemSwitchToParent();

    main();

}