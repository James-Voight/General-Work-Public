/** Reads a scan code from the keyboard device and places it at the location parameter.
 * \param ioMemory The pointer where you'd like the scan code written.
 */
void readKeyboard(char *ioMemory);

/** This is the main keyboard routine and converts scan code to ASCII value and prints it to the screen.
 * \param ioMemory The pointer where the scan code is located.
 * \param vgaMemory The pointer to the portion of the screen where you want the character printed.
 */
void readCommand(char *ioMemory, char *vgaMemory);