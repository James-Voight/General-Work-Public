#include "kernel.h"
#include "screen.h"
#include "fs.h"
#include "x86.h"
#include "vm.h"
#include "keyboard.h"
#include "interrupts.h"
#include "syscalls.h"
#include "simpleOSlibc.h"
#include "constants.h"
#include "frame-allocator.h"
#include "exceptions.h"
#include "vmmonitor.h"
#include "file.h"

int currentPid = 0;
int cursorRow = 0;
char *bufferMem = (char *)KEYBOARD_BUFFER;
char *cursorMemory = (char *)SHELL_CURSOR_POS;


void kInit()
{
    disableCursor();

    createSemaphore(KERNEL_OWNED, (char *)OPEN_FILE_TABLE, 1, 1);
    createSemaphore(KERNEL_OWNED, (char *)PROCESS_TABLE_LOC, 1, 1);
    createSemaphore(KERNEL_OWNED, (char *)PAGEFRAME_MAP_BASE, 1, 1);

    clearScreen();

    printString(COLOR_LIGHT_BLUE, cursorRow++, 0, (char *)"Starting Kernel Initialization:");

    // zero out process table memory, kernel heap and user heap
    fillMemory((char *)(PROCESS_TABLE_LOC) , (unsigned char)0x0, PAGE_SIZE);
    fillMemory((char *)(KERNEL_HEAP) , (unsigned char)0x0, PAGE_SIZE);
    fillMemory((char *)(USER_HEAP) , (unsigned char)0x0, PAGE_SIZE);

    struct blockGroupDescriptor *BlockGroupDescriptor = (blockGroupDescriptor*)(BLOCK_GROUP_DESCRIPTOR_TABLE);
    readBlock(BlockGroupDescriptor->bgd_block_address_of_block_usage, (char*)EXT2_BLOCK_USAGE_MAP);
    readBlock(BlockGroupDescriptor->bgd_block_address_of_inode_usage, (char*)EXT2_INODE_USAGE_MAP);

    currentPid = initializeTask(currentPid, PROC_SLEEPING, STACK_START_LOC, (char *)"shell2", 100);
    createPageFrameMap((char*)PAGEFRAME_MAP_BASE, 0x400);

    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Initialized Task Struct -> PID: ");
    printHexNumber(COLOR_GREEN, (cursorRow - 1), 38, currentPid);
    
    initializePageTables(currentPid);
    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Initialized Page Directory and Page Table -> PID: ");
    printHexNumber(COLOR_GREEN, (cursorRow - 1), 56, currentPid);
    
    contextSwitch(currentPid); 
    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Paging Enabled");

    remapPIC(INTERRUPT_MASK_ALL_ENABLED, INTERRUPT_MASK_ALL_ENABLED);
    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Programmable Interrupt Controller (PIC) Remapping Complete");

    //zero memory for the new IDT
    fillMemory((char *)INTERRUPT_DESC_TABLE, (unsigned char)0x0, PAGE_SIZE);
    fillMemory((char *)(INTERRUPT_DESC_TABLE + PAGE_SIZE), (unsigned char)0x0, PAGE_SIZE);
    loadIDT((char *)INTERRUPT_DESC_TABLE);
    loadIDTR((char *)INTERRUPT_DESC_TABLE, (char *)INTERRUPT_DESC_TABLE_REG);
    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Interrupt Descriptor Table (IDT) Setup Complete");
        
    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Kernel Initialization Complete");
    cursorRow++;

    createOpenFileTable((char *)OPEN_FILE_TABLE);
    storeValueAtMemLoc(RUNNING_PID_LOC, currentPid);
    
    enableInterrupts();

    printLogo(20);

    printString(COLOR_LIGHT_BLUE, cursorRow++, 0, (char *)"Ready to load Shell into PID:   ....");
    printHexNumber(COLOR_GREEN, (cursorRow - 1), 30, currentPid);
}

void logonPrompt()
{    
    if (!fsFindFile((char *)"mpass", (char *)((int)KERNEL_HASH_LOC + 0x500)))
    {
        panic((char *)"kernel.cpp -> Cannot find mpass file");
    }

    loadFileFromInodeStruct((KERNEL_HASH_LOC + 0x500), KERNEL_HASH_LOC);
    cursorRow = 17;
    printString(COLOR_WHITE, cursorRow++, 0, (char *)"Type Root password and press <enter> to launch shell:");    
    printString(COLOR_LIGHT_BLUE, cursorRow+1, 2, (char *)"$");

    readCommand(bufferMem, cursorMemory);

    while (*(int *)KERNEL_HASH_LOC != stringHash((char *)COMMAND_BUFFER))
    {
        cursorRow++;
        printString(COLOR_RED, 12, 0, (char *)"Wrong Password!");
        printString(COLOR_RED, 13, 0, (char *)"Press <enter> to try again....");  
        fillMemory((char *)KEYBOARD_BUFFER, (unsigned char)0x0, 0x200);   
        readCommand(bufferMem, cursorMemory);
    
    }
}

void loadShell()
{
    if (!requestSpecificPage(currentPid, (char *)(STACK_PAGE - PAGE_SIZE), PG_USER_PRESENT_RW))
    {
        clearScreen();
        printString(COLOR_RED, 2, 2, (char *)"Requested page is not available");
        panic((char *)"kernel.cpp -> STACK_PAGE - PAGE_SIZE page request");
    }

    if (!requestSpecificPage(currentPid, (char *)(STACK_PAGE), PG_USER_PRESENT_RW))
    {
        clearScreen();
        printString(COLOR_RED, 2, 2, (char *)"Requested page is not available");
        panic((char *)"kernel.cpp -> STACK_PAGE page request");
    }

    if (!requestSpecificPage(currentPid, (char *)(USER_HEAP), PG_USER_PRESENT_RW))
    {
        clearScreen();
        printString(COLOR_RED, 2, 2, (char *)"Requested page is not available");
        panic((char *)"kernel.cpp -> USER_HEAP page request");
    }

    cursorRow++;
    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Loading binary to Temp File Storage");

    if (!requestSpecificPage(currentPid, USER_TEMP_INODE_LOC, PG_USER_PRESENT_RW))
    {
        clearScreen();
        printString(COLOR_RED, 2, 2, (char *)"Requested page is not available");
        panic((char *)"kernel.cpp -> USER_TEMP_INODE_LOC page request");
    }

    if (!fsFindFile((char *)"shell2", USER_TEMP_INODE_LOC))
    {
        panic((char *)"kernel.cpp -> Cannot find shell in root directory");
    }

    struct inode *Inode = (struct inode*)USER_TEMP_INODE_LOC;
    int pagesNeedForTmpBinary = ceiling(Inode->i_size, PAGE_SIZE);

    //request pages for temporary file storage to load raw ELF file
    for (int tempFileLoc = 0; tempFileLoc < (pagesNeedForTmpBinary * PAGE_SIZE); tempFileLoc = tempFileLoc + PAGE_SIZE)
    {
        if (!requestSpecificPage(currentPid, (USER_TEMP_FILE_LOC + tempFileLoc), PG_USER_PRESENT_RW))
        {
            clearScreen();
            printString(COLOR_RED, 2, 2, (char *)"Requested page is not available");
            panic((char *)"kernel.cpp -> USER_TEMP_FILE_LOC page request");
        }
    }
    
    loadFileFromInodeStruct(USER_TEMP_INODE_LOC, USER_TEMP_FILE_LOC); 
    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Raw binary loaded to 0x31000");
    
    struct elfHeader *ELFHeader = (struct elfHeader*)USER_TEMP_FILE_LOC;
    struct pHeader *ProgHeaderTextSegment, *ProgHeaderDataSegment;
    ProgHeaderTextSegment = (struct pHeader*)((char * )(int)ELFHeader + ELFHeader->e_phoff + ELF_PROGRAM_HEADER_SIZE);
    ProgHeaderDataSegment = (struct pHeader*)((char * )(int)ELFHeader + (ELFHeader->e_phoff + (ELF_PROGRAM_HEADER_SIZE * 2)));

    int totalTextSegmentPagesNeeded = ceiling(ProgHeaderTextSegment->p_memsz, PAGE_SIZE);
    int totalDataSegmentPagesNeeded = ceiling(ProgHeaderDataSegment->p_memsz, PAGE_SIZE);

    // request enough pages at the required virtual address to load and run binary
    for (int tempFileLoc = 0; tempFileLoc < ((totalTextSegmentPagesNeeded + totalDataSegmentPagesNeeded) * PAGE_SIZE); tempFileLoc = tempFileLoc + PAGE_SIZE)
    {
        if (!requestSpecificPage(currentPid, (char *)(ProgHeaderTextSegment->p_vaddr + tempFileLoc), PG_USER_PRESENT_RW))
        {
            clearScreen();
            printString(COLOR_RED, 2, 2, (char *)"Requested page is not available");
            panic((char *)"kernel.cpp -> USERPROG TEXT and DATA VADDR page requests");
        }

    }
    
    loadElfFile(USER_TEMP_FILE_LOC);
    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Binary loaded from 0x31000 to desired location");
}

void launchShell()
{
    struct elfHeader *ELFHeaderLaunch = (struct elfHeader*)USER_TEMP_FILE_LOC;

    // RUNNING_PID_LOC will store some information for the currently running process, such as
    // what its PID is
    storeValueAtMemLoc(RUNNING_PID_LOC, currentPid);
    printString(COLOR_GREEN, cursorRow++, 0, (char *)"   -> Switching to Ring 3 and launching binary");

    // setting current process state to running
    updateTaskState(currentPid, PROC_RUNNING);
    setSystemTimer(SYSTEM_INTERRUPTS_PER_SECOND);

    loadTaskRegister(0x28);
    switchToRing3LaunchBinary((char *)ELFHeaderLaunch->e_entry);
}


void main()
{
    kInit();

    // Disabling logon prompt to save time while iterating through code.
    // logonPrompt();
    
    loadShell();
    launchShell();

    panic((char *)"kernel.cpp -> Unable to launch shell, returned to kernel.cpp");
}